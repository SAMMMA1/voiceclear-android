package com.example.voiceenhancement

import com.example.settings.ProcessingSettings
import kotlin.math.*

/**
 * Real-time Voice Enhancement & Intelligibility DSP Module.
 *
 * Full Broadcast & Speech Clarity Chain:
 * 1. Low Rumble Cut (80 Hz 2nd-Order Butterworth High-Pass Filter)
 * 2. 4-Band Parametric Equalizer:
 *    - Warmth Peaking Filter (220 Hz vocal resonance)
 *    - Mid Presence Peaking Filter (2.8 kHz speech intelligibility)
 *    - Air High-Shelf / Peaking Filter (8.0 kHz broadcast sheen)
 * 3. Dynamic De-Esser (5.5 kHz - 7.5 kHz sibilance suppression for harsh S / SH sounds)
 * 4. Voice Focus & Non-vocal formant attenuation
 * 5. Automatic Gain Control (AGC) with RMS Speech Leveler
 * 6. Master Output Gain Stage
 * 7. Zero-Overshoot True Soft-Knee Peak Limiter (Hyperbolic Tangent Compression)
 */
class VoiceEnhancerDsp(private var sampleRate: Int = 48000) {

    // Low Rumble High-Pass Filter (80 Hz Butterworth Biquad)
    private var hpB0 = 1f; private var hpB1 = -2f; private var hpB2 = 1f
    private var hpA1 = 0f; private var hpA2 = 0f
    private var hpX1 = 0f; private var hpX2 = 0f; private var hpY1 = 0f; private var hpY2 = 0f

    // Warmth Peaking Filter (f0 = 220 Hz, Q = 1.0)
    private var warmB0 = 1f; private var warmB1 = 0f; private var warmB2 = 0f
    private var warmA1 = 0f; private var warmA2 = 0f
    private var warmX1 = 0f; private var warmX2 = 0f; private var warmY1 = 0f; private var warmY2 = 0f

    // Presence Peaking Biquad Filter (f0 = 2800 Hz, Q = 1.2)
    private var presB0 = 1f; private var presB1 = 0f; private var presB2 = 0f
    private var presA1 = 0f; private var presA2 = 0f
    private var presX1 = 0f; private var presX2 = 0f; private var presY1 = 0f; private var presY2 = 0f

    // Air Peaking/Shelf Filter (f0 = 8000 Hz, Q = 0.8)
    private var airB0 = 1f; private var airB1 = 0f; private var airB2 = 0f
    private var airA1 = 0f; private var airA2 = 0f
    private var airX1 = 0f; private var airX2 = 0f; private var airY1 = 0f; private var airY2 = 0f

    // De-Esser Bandpass Filter (f0 = 6500 Hz, Q = 2.0)
    private var deEssB0 = 1f; private var deEssB1 = 0f; private var deEssB2 = 0f
    private var deEssA1 = 0f; private var deEssA2 = 0f
    private var deEssX1 = 0f; private var deEssX2 = 0f; private var deEssY1 = 0f; private var deEssY2 = 0f
    private var deEsserGain = 1.0f

    // AGC & Leveler envelope
    private var agcGain = 1.0f
    private var peakEnvelope = 0.0f
    private val targetRms = 0.22f // ~ -13 dBFS broadcast target

    private var currentWarmthDb = 1.8f
    private var currentPresenceDb = 4.5f
    private var currentAirDb = 2.0f

    init {
        updateAllCoefficients(currentWarmthDb, currentPresenceDb, currentAirDb)
    }

    fun setSampleRate(newRate: Int) {
        if (sampleRate != newRate) {
            sampleRate = newRate
            updateAllCoefficients(currentWarmthDb, currentPresenceDb, currentAirDb)
            reset()
        }
    }

    fun reset() {
        hpX1 = 0f; hpX2 = 0f; hpY1 = 0f; hpY2 = 0f
        warmX1 = 0f; warmX2 = 0f; warmY1 = 0f; warmY2 = 0f
        presX1 = 0f; presX2 = 0f; presY1 = 0f; presY2 = 0f
        airX1 = 0f; airX2 = 0f; airY1 = 0f; airY2 = 0f
        deEssX1 = 0f; deEssX2 = 0f; deEssY1 = 0f; deEssY2 = 0f
        deEsserGain = 1.0f
        agcGain = 1.0f
        peakEnvelope = 0.0f
    }

    fun updateAllCoefficients(warmthDb: Float, presenceDb: Float, airDb: Float) {
        currentWarmthDb = warmthDb
        currentPresenceDb = presenceDb
        currentAirDb = airDb

        val fs = sampleRate.toDouble()

        // 1. High Pass 80Hz Butterworth Biquad
        val fHp = 80.0.coerceAtMost(fs * 0.40)
        val w0Hp = 2.0 * Math.PI * fHp / fs
        val cosW0Hp = cos(w0Hp)
        val alphaHp = sin(w0Hp) / (2.0 * 0.7071)
        val a0Hp = 1.0 + alphaHp
        hpB0 = ((1.0 + cosW0Hp) / 2.0 / a0Hp).toFloat()
        hpB1 = (-(1.0 + cosW0Hp) / a0Hp).toFloat()
        hpB2 = ((1.0 + cosW0Hp) / 2.0 / a0Hp).toFloat()
        hpA1 = (-2.0 * cosW0Hp / a0Hp).toFloat()
        hpA2 = ((1.0 - alphaHp) / a0Hp).toFloat()

        // 2. Warmth Peaking (220 Hz)
        val fWarmth = 220.0.coerceAtMost(fs * 0.40)
        val aWarm = 10.0.pow(warmthDb.toDouble() / 40.0)
        val w0Warm = 2.0 * Math.PI * fWarmth / fs
        val alphaWarm = sin(w0Warm) / (2.0 * 1.0)
        val a0W = 1.0 + alphaWarm / aWarm
        warmB0 = ((1.0 + alphaWarm * aWarm) / a0W).toFloat()
        warmB1 = ((-2.0 * cos(w0Warm)) / a0W).toFloat()
        warmB2 = ((1.0 - alphaWarm * aWarm) / a0W).toFloat()
        warmA1 = ((-2.0 * cos(w0Warm)) / a0W).toFloat()
        warmA2 = ((1.0 - alphaWarm / aWarm) / a0W).toFloat()

        // 3. Presence Peaking (2800 Hz)
        val fPres = 2800.0.coerceAtMost(fs * 0.40)
        val aPres = 10.0.pow(presenceDb.toDouble() / 40.0)
        val w0Pres = 2.0 * Math.PI * fPres / fs
        val alphaPres = sin(w0Pres) / (2.0 * 1.2)
        val a0P = 1.0 + alphaPres / aPres
        presB0 = ((1.0 + alphaPres * aPres) / a0P).toFloat()
        presB1 = ((-2.0 * cos(w0Pres)) / a0P).toFloat()
        presB2 = ((1.0 - alphaPres * aPres) / a0P).toFloat()
        presA1 = ((-2.0 * cos(w0Pres)) / a0P).toFloat()
        presA2 = ((1.0 - alphaPres / aPres) / a0P).toFloat()

        // 4. Air High Peaking (8000 Hz)
        val fAir = 8000.0.coerceAtMost(fs * 0.45)
        val aAir = 10.0.pow(airDb.toDouble() / 40.0)
        val w0Air = 2.0 * Math.PI * fAir / fs
        val alphaAir = sin(w0Air) / (2.0 * 0.8)
        val a0A = 1.0 + alphaAir / aAir
        airB0 = ((1.0 + alphaAir * aAir) / a0A).toFloat()
        airB1 = ((-2.0 * cos(w0Air)) / a0A).toFloat()
        airB2 = ((1.0 - alphaAir * aAir) / a0A).toFloat()
        airA1 = ((-2.0 * cos(w0Air)) / a0A).toFloat()
        airA2 = ((1.0 - alphaAir / aAir) / a0A).toFloat()

        // 5. Dynamic De-Esser Bandpass (6500 Hz)
        val fDeEss = 6500.0.coerceAtMost(fs * 0.45)
        val w0De = 2.0 * Math.PI * fDeEss / fs
        val alphaDe = sin(w0De) / (2.0 * 2.0)
        val a0De = 1.0 + alphaDe
        deEssB0 = (alphaDe / a0De).toFloat()
        deEssB1 = 0.0f
        deEssB2 = (-alphaDe / a0De).toFloat()
        deEssA1 = ((-2.0 * cos(w0De)) / a0De).toFloat()
        deEssA2 = ((1.0 - alphaDe) / a0De).toFloat()
    }

    /**
     * Process voice enhancement, 4-band Parametric EQ, De-Esser, AGC, and Limiter in-place.
     */
    fun processFrame(
        buffer: ShortArray,
        length: Int,
        vadProbability: Float,
        settings: ProcessingSettings
    ) {
        if (length <= 0) return

        if (settings.warmthDb != currentWarmthDb ||
            settings.presenceDb != currentPresenceDb ||
            settings.airDb != currentAirDb) {
            updateAllCoefficients(settings.warmthDb, settings.presenceDb, settings.airDb)
        }

        val clarityRatio = settings.voiceClarity.coerceIn(0f, 1f)
        val focusRatio = settings.voiceFocus.coerceIn(0f, 1f)
        val enableAgc = settings.automaticGainControlEnabled
        val enableRumbleCut = settings.lowRumbleCut

        // 1. Apply 4-Band Parametric EQ
        if (enableRumbleCut || clarityRatio > 0.05f) {
            for (i in 0 until length) {
                var sample = buffer[i] / 32768.0f

                // Low Rumble Cut
                if (enableRumbleCut) {
                    val outHp = hpB0 * sample + hpB1 * hpX1 + hpB2 * hpX2 - hpA1 * hpY1 - hpA2 * hpY2
                    hpX2 = hpX1; hpX1 = sample; hpY2 = hpY1; hpY1 = outHp
                    sample = outHp
                }

                if (clarityRatio > 0.05f) {
                    // Warmth EQ (220 Hz)
                    val outWarm = warmB0 * sample + warmB1 * warmX1 + warmB2 * warmX2 - warmA1 * warmY1 - warmA2 * warmY2
                    warmX2 = warmX1; warmX1 = sample; warmY2 = warmY1; warmY1 = outWarm

                    // Presence EQ (2800 Hz)
                    val outPres = presB0 * outWarm + presB1 * presX1 + presB2 * presX2 - presA1 * presY1 - presA2 * presY2
                    presX2 = presX1; presX1 = outWarm; presY2 = presY1; presY1 = outPres

                    // Air EQ (8000 Hz)
                    val outAir = airB0 * outPres + airB1 * airX1 + airB2 * airX2 - airA1 * airY1 - airA2 * airY2
                    airX2 = airX1; airX1 = outPres; airY2 = airY1; airY1 = outAir

                    // Blend with input according to clarity ratio
                    sample = (1f - clarityRatio) * sample + clarityRatio * outAir
                }

                buffer[i] = (sample.coerceIn(-1f, 1f) * 32767.0f).toInt().toShort()
            }
        }

        // 2. Dynamic De-Esser (attentuates harsh S/SH sibilants dynamically when enhancement enabled)
        if (clarityRatio > 0.05f) {
            applyDynamicDeEsser(buffer, length)
        }

        // 3. Voice Focus Attenuation for non-vocal frequency tails
        if (focusRatio > 0.3f && vadProbability < 0.35f) {
            val focusDampening = 1.0f - (focusRatio - 0.3f) * 0.45f
            for (i in 0 until length) {
                buffer[i] = (buffer[i] * focusDampening).toInt().toShort()
            }
        }

        // 4. Dynamic AGC & Compressor
        if (enableAgc) {
            applyAutomaticGainControl(buffer, length, vadProbability)
        }

        // 5. Output Master Gain & True Soft-Knee Peak Limiter (only apply limiter if gain offset or peak exceeds ceiling)
        if (settings.outputGainDb != 0.0f || settings.limiterThresholdDb < 0.0f) {
            applyOutputGainAndLimiter(buffer, length, settings.outputGainDb, settings.limiterThresholdDb)
        }
    }

    /**
     * Dynamic De-Esser: Detects harsh sibilance spikes (5.5kHz - 7.5kHz) and smoothly applies
     * dynamic gain reduction only during sibilant sounds.
     */
    private fun applyDynamicDeEsser(buffer: ShortArray, length: Int) {
        var totalEnergy = 0.0f
        var sibilanceEnergy = 0.0f

        for (i in 0 until length) {
            val s = buffer[i] / 32768.0f
            totalEnergy += s * s

            // Filter through 6.5kHz bandpass
            val outDe = deEssB0 * s + deEssB1 * deEssX1 + deEssB2 * deEssX2 - deEssA1 * deEssY1 - deEssA2 * deEssY2
            deEssX2 = deEssX1; deEssX1 = s; deEssY2 = deEssY1; deEssY1 = outDe
            sibilanceEnergy += outDe * outDe
        }

        val sibilanceRatio = if (totalEnergy > 1e-5f) (sibilanceEnergy / totalEnergy) else 0.0f

        // If sibilance exceeds 35% of total high energy, gently compress
        val targetDeEssGain = if (sibilanceRatio > 0.35f) {
            (1.0f - (sibilanceRatio - 0.35f) * 0.8f).coerceIn(0.65f, 1.0f)
        } else {
            1.0f
        }

        val deEssAlpha = if (targetDeEssGain < deEsserGain) 0.35f else 0.08f
        deEsserGain = (1.0f - deEssAlpha) * deEsserGain + deEssAlpha * targetDeEssGain

        if (deEsserGain < 0.98f) {
            for (i in 0 until length) {
                val sample = buffer[i] * deEsserGain
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }
        }
    }

    private fun applyAutomaticGainControl(
        buffer: ShortArray,
        length: Int,
        vadProbability: Float
    ) {
        var sumSquares = 0.0f
        var framePeak = 0.0f
        for (i in 0 until length) {
            val s = abs(buffer[i] / 32768.0f)
            if (s > framePeak) framePeak = s
            sumSquares += s * s
        }
        val frameRms = sqrt(sumSquares / length)

        val attack = 0.45f
        val release = 0.035f
        peakEnvelope = if (framePeak > peakEnvelope) {
            (1f - attack) * peakEnvelope + attack * framePeak
        } else {
            (1f - release) * peakEnvelope + release * framePeak
        }

        if (vadProbability > 0.35f && frameRms > 0.015f) {
            val desiredGain = (targetRms / frameRms).coerceIn(0.6f, 3.2f)
            agcGain = 0.96f * agcGain + 0.04f * desiredGain
        } else if (frameRms < 0.005f) {
            agcGain = 0.98f * agcGain + 0.02f * 1.0f
        }

        for (i in 0 until length) {
            val sample = (buffer[i] / 32768.0f) * agcGain
            buffer[i] = (sample.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()
        }
    }

    private fun applyOutputGainAndLimiter(
        buffer: ShortArray,
        length: Int,
        outputGainDb: Float,
        limiterCeilingDb: Float
    ) {
        val outLinearGain = if (outputGainDb != 0.0f) {
            10.0.pow(outputGainDb.toDouble() / 20.0).toFloat()
        } else 1.0f

        val ceilingLinear = 10.0.pow(limiterCeilingDb.coerceIn(-6.0f, 0.0f).toDouble() / 20.0).toFloat()
        val kneeThreshold = ceilingLinear * 0.85f
        val kneeRange = ceilingLinear - kneeThreshold

        for (i in 0 until length) {
            val sample = (buffer[i] / 32768.0f) * outLinearGain
            val absSample = abs(sample)

            val limited = if (absSample > kneeThreshold) {
                val excess = absSample - kneeThreshold
                val compressedExcess = kneeRange * tanh((excess / kneeRange).toDouble()).toFloat()
                (kneeThreshold + compressedExcess) * sample.sign
            } else {
                sample
            }

            buffer[i] = (limited.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()
        }
    }
}
