package com.example.audiorecording

import java.io.RandomAccessFile

object WavHeaderUtils {

    /**
     * Writes or updates standard 44-byte RIFF/WAV header for 16-bit PCM Mono audio.
     */
    fun writeWavHeader(
        raf: RandomAccessFile,
        sampleRate: Int,
        channels: Int = 1,
        bitsPerSample: Int = 16,
        pcmDataLength: Long
    ) {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)
        val totalDataLen = pcmDataLength + 36

        raf.seek(0)
        // RIFF header
        raf.writeBytes("RIFF")
        raf.writeInt(Integer.reverseBytes(totalDataLen.toInt()))
        raf.writeBytes("WAVE")

        // 'fmt ' chunk
        raf.writeBytes("fmt ")
        raf.writeInt(Integer.reverseBytes(16)) // 16 for PCM format chunk size
        raf.writeShort(java.lang.Short.reverseBytes(1.toShort()).toInt()) // AudioFormat 1 = PCM
        raf.writeShort(java.lang.Short.reverseBytes(channels.toShort()).toInt())
        raf.writeInt(Integer.reverseBytes(sampleRate))
        raf.writeInt(Integer.reverseBytes(byteRate))
        raf.writeShort(java.lang.Short.reverseBytes(blockAlign.toShort()).toInt())
        raf.writeShort(java.lang.Short.reverseBytes(bitsPerSample.toShort()).toInt())

        // 'data' chunk
        raf.writeBytes("data")
        raf.writeInt(Integer.reverseBytes(pcmDataLength.toInt()))
    }
}
