package com.example.audiorecording

import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentFilePath: String? = null,
    val currentPositionMs: Int = 0,
    val totalDurationMs: Int = 0,
    val progressFraction: Float = 0f
)

class AudioPlayerManager {
    private val TAG = "AudioPlayerManager"

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    fun play(filePath: String) {
        val file = File(filePath)
        if (!file.exists()) {
            Log.e(TAG, "Audio file does not exist: $filePath")
            return
        }

        // If already playing this file, toggle pause/play
        if (_playbackState.value.currentFilePath == filePath && mediaPlayer != null) {
            if (_playbackState.value.isPlaying) {
                pause()
            } else {
                resume()
            }
            return
        }

        stop()

        try {
            val player = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionMs = 0,
                        progressFraction = 0f
                    )
                    progressJob?.cancel()
                }
                start()
            }

            mediaPlayer = player
            val duration = player.duration

            _playbackState.value = PlaybackState(
                isPlaying = true,
                currentFilePath = filePath,
                currentPositionMs = 0,
                totalDurationMs = duration,
                progressFraction = 0f
            )

            startProgressTracker()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio file", e)
            stop()
        }
    }

    fun pause() {
        try {
            mediaPlayer?.pause()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
            progressJob?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing audio", e)
        }
    }

    fun resume() {
        try {
            mediaPlayer?.start()
            _playbackState.value = _playbackState.value.copy(isPlaying = true)
            startProgressTracker()
        } catch (e: Exception) {
            Log.w(TAG, "Error resuming audio", e)
        }
    }

    fun seekTo(fraction: Float) {
        val player = mediaPlayer ?: return
        try {
            val position = (player.duration * fraction.coerceIn(0f, 1f)).toInt()
            player.seekTo(position)
            _playbackState.value = _playbackState.value.copy(
                currentPositionMs = position,
                progressFraction = fraction
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error seeking audio", e)
        }
    }

    fun stop() {
        progressJob?.cancel()
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping media player", e)
        } finally {
            mediaPlayer = null
            _playbackState.value = PlaybackState()
        }
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _playbackState.value.isPlaying) {
                mediaPlayer?.let { player ->
                    try {
                        val current = player.currentPosition
                        val total = player.duration.coerceAtLeast(1)
                        _playbackState.value = _playbackState.value.copy(
                            currentPositionMs = current,
                            progressFraction = (current.toFloat() / total).coerceIn(0f, 1f)
                        )
                    } catch (e: Exception) {
                        // ignore during seek
                    }
                }
                delay(60)
            }
        }
    }
}
