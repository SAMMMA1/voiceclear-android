package com.example.audiorecording

import android.media.MediaPlayer
import android.util.Log
import com.example.database.AudioRecordingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentFilePath: String? = null,
    val currentRecordingId: Long? = null,
    val isPlayingRaw: Boolean = false,
    val currentPositionMs: Int = 0,
    val totalDurationMs: Int = 0,
    val progressFraction: Float = 0f
)

class AudioPlayerManager {
    private val TAG = "AudioPlayerManager"

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private var activeRecording: AudioRecordingEntity? = null

    fun playRecording(recording: AudioRecordingEntity, playRaw: Boolean = false) {
        val targetPath = if (playRaw && !recording.rawFilePath.isNullOrEmpty()) {
            recording.rawFilePath
        } else {
            recording.filePath
        }

        activeRecording = recording

        // If already playing this exact recording, toggle pause/play
        if (_playbackState.value.currentRecordingId == recording.id &&
            _playbackState.value.isPlayingRaw == playRaw &&
            mediaPlayer != null
        ) {
            if (_playbackState.value.isPlaying) {
                pause()
            } else {
                resume()
            }
            return
        }

        val file = File(targetPath)
        if (!file.exists()) {
            Log.e(TAG, "Audio file does not exist: $targetPath")
            return
        }

        stop()

        try {
            val player = MediaPlayer().apply {
                setDataSource(targetPath)
                prepare()
                setOnCompletionListener {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionMs = 0,
                        progressFraction = 0f
                    )
                    progressJob?.cancel()
                }
                start()
            }

            mediaPlayer = player
            val duration = player.duration

            _playbackState.value = PlaybackState(
                isPlaying = true,
                currentFilePath = targetPath,
                currentRecordingId = recording.id,
                isPlayingRaw = playRaw,
                currentPositionMs = 0,
                totalDurationMs = duration,
                progressFraction = 0f
            )

            startProgressTracker()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing recording", e)
            stop()
        }
    }

    /**
     * Seamlessly toggle between Enhanced and Original track at the exact same playback position.
     */
    fun toggleAuditionTrack(recording: AudioRecordingEntity) {
        val currentlyRaw = _playbackState.value.isPlayingRaw && _playbackState.value.currentRecordingId == recording.id
        val targetRaw = !currentlyRaw

        val targetPath = if (targetRaw) recording.rawFilePath else recording.filePath
        if (targetPath.isNullOrEmpty() || !File(targetPath).exists()) {
            Log.w(TAG, "Target track path does not exist: $targetPath")
            return
        }

        val currentPos = mediaPlayer?.currentPosition ?: 0
        val wasPlaying = _playbackState.value.isPlaying

        stopInternal()

        try {
            val player = MediaPlayer().apply {
                setDataSource(targetPath)
                prepare()
                seekTo(currentPos)
                setOnCompletionListener {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionMs = 0,
                        progressFraction = 0f
                    )
                    progressJob?.cancel()
                }
                if (wasPlaying) {
                    start()
                }
            }

            mediaPlayer = player
            val duration = player.duration

            _playbackState.value = PlaybackState(
                isPlaying = wasPlaying,
                currentFilePath = targetPath,
                currentRecordingId = recording.id,
                isPlayingRaw = targetRaw,
                currentPositionMs = currentPos,
                totalDurationMs = duration,
                progressFraction = if (duration > 0) (currentPos.toFloat() / duration).coerceIn(0f, 1f) else 0f
            )

            if (wasPlaying) {
                startProgressTracker()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error switching audition track", e)
            stop()
        }
    }

    fun play(filePath: String) {
        val file = File(filePath)
        if (!file.exists()) {
            Log.e(TAG, "Audio file does not exist: $filePath")
            return
        }

        if (_playbackState.value.currentFilePath == filePath && mediaPlayer != null) {
            if (_playbackState.value.isPlaying) {
                pause()
            } else {
                resume()
            }
            return
        }

        stop()

        try {
            val player = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionMs = 0,
                        progressFraction = 0f
                    )
                    progressJob?.cancel()
                }
                start()
            }

            mediaPlayer = player
            val duration = player.duration

            _playbackState.value = PlaybackState(
                isPlaying = true,
                currentFilePath = filePath,
                currentRecordingId = null,
                isPlayingRaw = false,
                currentPositionMs = 0,
                totalDurationMs = duration,
                progressFraction = 0f
            )

            startProgressTracker()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio file", e)
            stop()
        }
    }

    fun pause() {
        try {
            mediaPlayer?.pause()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
            progressJob?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing audio", e)
        }
    }

    fun resume() {
        try {
            mediaPlayer?.start()
            _playbackState.value = _playbackState.value.copy(isPlaying = true)
            startProgressTracker()
        } catch (e: Exception) {
            Log.w(TAG, "Error resuming audio", e)
        }
    }

    fun seekTo(fraction: Float) {
        val player = mediaPlayer ?: return
        try {
            val position = (player.duration * fraction.coerceIn(0f, 1f)).toInt()
            player.seekTo(position)
            _playbackState.value = _playbackState.value.copy(
                currentPositionMs = position,
                progressFraction = fraction
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error seeking audio", e)
        }
    }

    private fun stopInternal() {
        progressJob?.cancel()
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing media player", e)
        } finally {
            mediaPlayer = null
        }
    }

    fun stop() {
        stopInternal()
        activeRecording = null
        _playbackState.value = PlaybackState()
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _playbackState.value.isPlaying) {
                mediaPlayer?.let { player ->
                    try {
                        val current = player.currentPosition
                        val total = player.duration.coerceAtLeast(1)
                        _playbackState.value = _playbackState.value.copy(
                            currentPositionMs = current,
                            progressFraction = (current.toFloat() / total).coerceIn(0f, 1f)
                        )
                    } catch (e: Exception) {
                        // ignore during seek
                    }
                }
                delay(60)
            }
        }
    }
}
