package com.example.audiorecording

import android.content.Context
import android.util.Log
import com.example.audioengine.AudioSink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

data class RecordingState(
    val isRecording: Boolean = false,
    val durationMs: Long = 0L,
    val fileSizeBytes: Long = 0L,
    val currentFilePath: String? = null,
    val currentFileName: String? = null
)

class AudioRecorderEngine(private val context: Context) : AudioSink {
    private val TAG = "AudioRecorderEngine"

    private val isRecording = AtomicBoolean(false)
    private var currentOutputFile: File? = null
    private var fileOutputStream: FileOutputStream? = null
    private var bytesWritten = 0L
    private var sampleRate = 48000
    private var recordStartTime = 0L

    private val _recordingState = MutableStateFlow(RecordingState())
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    // Pre-allocated byte buffer for zero allocation in audio loop (up to 4096 shorts = 8192 bytes)
    private val rawByteArray = ByteArray(8192)

    fun startRecording(sampleRate: Int, presetName: String): File? {
        if (isRecording.get()) return currentOutputFile
        this.sampleRate = sampleRate

        try {
            val recordingsDir = File(context.filesDir, "recordings").apply {
                if (!exists()) mkdirs()
            }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val cleanPreset = presetName.replace(" ", "_").replace("&", "and")
            val fileName = "VoiceClear_${cleanPreset}_$timestamp.wav"
            val outputFile = File(recordingsDir, fileName)

            val fos = FileOutputStream(outputFile)
            // Allocate 44 blank bytes for WAV header placeholder
            fos.write(ByteArray(44))

            fileOutputStream = fos
            currentOutputFile = outputFile
            bytesWritten = 0L
            recordStartTime = System.currentTimeMillis()
            isRecording.set(true)

            _recordingState.value = RecordingState(
                isRecording = true,
                durationMs = 0L,
                fileSizeBytes = 44L,
                currentFilePath = outputFile.absolutePath,
                currentFileName = fileName
            )

            Log.i(TAG, "Started audio recording to ${outputFile.absolutePath}")
            return outputFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed starting WAV recording", e)
            stopRecording()
            return null
        }
    }

    override fun onAudioFrame(
        rawBuffer: ShortArray,
        enhancedBuffer: ShortArray,
        length: Int,
        sampleRate: Int
    ) {
        writeFrame(enhancedBuffer, length)
    }

    /**
     * Called on the real-time audio thread for each processed PCM buffer.
     */
    fun writeFrame(buffer: ShortArray, length: Int) {
        if (!isRecording.get() || length <= 0) return
        val fos = fileOutputStream ?: return

        try {
            val byteCount = length * 2
            val bytes = if (rawByteArray.size >= byteCount) rawByteArray else ByteArray(byteCount)
            for (i in 0 until length) {
                val s = buffer[i].toInt()
                bytes[i * 2] = (s and 0xFF).toByte()
                bytes[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
            }

            fos.write(bytes, 0, byteCount)
            bytesWritten += byteCount

            val durationMs = (bytesWritten / (sampleRate * 2.0) * 1000.0).toLong()
            _recordingState.value = _recordingState.value.copy(
                durationMs = durationMs,
                fileSizeBytes = bytesWritten + 44
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error writing audio buffer to file", e)
        }
    }

    fun stopRecording(): File? {
        if (!isRecording.compareAndSet(true, false)) return currentOutputFile

        val file = currentOutputFile
        try {
            fileOutputStream?.flush()
            fileOutputStream?.close()
            fileOutputStream = null

            if (file != null && file.exists()) {
                // Write proper 44-byte WAV header with final byte count
                RandomAccessFile(file, "rw").use { raf ->
                    WavHeaderUtils.writeWavHeader(
                        raf = raf,
                        sampleRate = sampleRate,
                        channels = 1,
                        bitsPerSample = 16,
                        pcmDataLength = bytesWritten
                    )
                }
                Log.i(TAG, "WAV header written. Recording saved: ${file.name} (${file.length()} bytes)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error finalizing WAV file", e)
        } finally {
            _recordingState.value = RecordingState(isRecording = false)
        }
        return file
    }

    override fun release() {
        stopRecording()
    }
}
