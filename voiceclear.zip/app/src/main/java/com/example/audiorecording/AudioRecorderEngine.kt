package com.example.audiorecording

import android.content.Context
import android.util.Log
import com.example.audioengine.AudioSink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

data class RecordingState(
    val isRecording: Boolean = false,
    val durationMs: Long = 0L,
    val fileSizeBytes: Long = 0L,
    val currentFilePath: String? = null,
    val currentRawFilePath: String? = null,
    val currentFileName: String? = null
)

data class DualRecordingResult(
    val enhancedFile: File,
    val rawFile: File,
    val durationMs: Long,
    val sampleRate: Int
)

class AudioRecorderEngine(private val context: Context) : AudioSink {
    private val TAG = "AudioRecorderEngine"

    private val isRecording = AtomicBoolean(false)
    private var currentEnhancedFile: File? = null
    private var currentRawFile: File? = null
    private var enhancedOutputStream: FileOutputStream? = null
    private var rawOutputStream: FileOutputStream? = null
    private var bytesWritten = 0L
    private var sampleRate = 48000
    private var recordStartTime = 0L

    private val _recordingState = MutableStateFlow(RecordingState())
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    // Pre-allocated byte buffers for zero allocation in real-time audio loop
    private val rawByteArray = ByteArray(8192)
    private val enhByteArray = ByteArray(8192)

    fun startRecording(sampleRate: Int, presetName: String): File? {
        if (isRecording.get()) return currentEnhancedFile
        this.sampleRate = sampleRate

        try {
            val recordingsDir = File(context.filesDir, "recordings").apply {
                if (!exists()) mkdirs()
            }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val cleanPreset = presetName.replace(" ", "_").replace("&", "and")
            val enhFileName = "VoiceClear_${cleanPreset}_Enhanced_$timestamp.wav"
            val rawFileName = "VoiceClear_${cleanPreset}_Original_$timestamp.wav"

            val enhFile = File(recordingsDir, enhFileName)
            val rawFile = File(recordingsDir, rawFileName)

            val fosEnh = FileOutputStream(enhFile)
            val fosRaw = FileOutputStream(rawFile)

            // Allocate 44 blank bytes for WAV header placeholders
            fosEnh.write(ByteArray(44))
            fosRaw.write(ByteArray(44))

            enhancedOutputStream = fosEnh
            rawOutputStream = fosRaw
            currentEnhancedFile = enhFile
            currentRawFile = rawFile
            bytesWritten = 0L
            recordStartTime = System.currentTimeMillis()
            isRecording.set(true)

            _recordingState.value = RecordingState(
                isRecording = true,
                durationMs = 0L,
                fileSizeBytes = 44L,
                currentFilePath = enhFile.absolutePath,
                currentRawFilePath = rawFile.absolutePath,
                currentFileName = enhFileName
            )

            Log.i(TAG, "Started dual audio recording: ${enhFile.name} & ${rawFile.name}")
            return enhFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed starting dual WAV recording", e)
            stopRecording()
            return null
        }
    }

    override fun onAudioFrame(
        rawBuffer: ShortArray,
        enhancedBuffer: ShortArray,
        length: Int,
        sampleRate: Int
    ) {
        if (!isRecording.get() || length <= 0) return
        val fosEnh = enhancedOutputStream ?: return
        val fosRaw = rawOutputStream ?: return

        try {
            val byteCount = length * 2

            val eBytes = if (enhByteArray.size >= byteCount) enhByteArray else ByteArray(byteCount)
            for (i in 0 until length) {
                val s = enhancedBuffer[i].toInt()
                eBytes[i * 2] = (s and 0xFF).toByte()
                eBytes[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
            }
            fosEnh.write(eBytes, 0, byteCount)

            val rBytes = if (rawByteArray.size >= byteCount) rawByteArray else ByteArray(byteCount)
            for (i in 0 until length) {
                val s = rawBuffer[i].toInt()
                rBytes[i * 2] = (s and 0xFF).toByte()
                rBytes[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
            }
            fosRaw.write(rBytes, 0, byteCount)

            bytesWritten += byteCount

            val durationMs = (bytesWritten / (sampleRate * 2.0) * 1000.0).toLong()
            _recordingState.value = _recordingState.value.copy(
                durationMs = durationMs,
                fileSizeBytes = bytesWritten + 44
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error writing dual audio buffers", e)
        }
    }

    fun stopRecording(): File? {
        val result = stopRecordingDual()
        return result?.enhancedFile
    }

    fun stopRecordingDual(): DualRecordingResult? {
        if (!isRecording.compareAndSet(true, false)) {
            val enh = currentEnhancedFile
            val raw = currentRawFile
            return if (enh != null && raw != null) {
                DualRecordingResult(enh, raw, 0L, sampleRate)
            } else null
        }

        val enhFile = currentEnhancedFile
        val rawFile = currentRawFile

        try {
            enhancedOutputStream?.flush()
            enhancedOutputStream?.close()
            enhancedOutputStream = null

            rawOutputStream?.flush()
            rawOutputStream?.close()
            rawOutputStream = null

            if (enhFile != null && enhFile.exists()) {
                RandomAccessFile(enhFile, "rw").use { raf ->
                    WavHeaderUtils.writeWavHeader(
                        raf = raf,
                        sampleRate = sampleRate,
                        channels = 1,
                        bitsPerSample = 16,
                        pcmDataLength = bytesWritten
                    )
                }
            }

            if (rawFile != null && rawFile.exists()) {
                RandomAccessFile(rawFile, "rw").use { raf ->
                    WavHeaderUtils.writeWavHeader(
                        raf = raf,
                        sampleRate = sampleRate,
                        channels = 1,
                        bitsPerSample = 16,
                        pcmDataLength = bytesWritten
                    )
                }
            }

            Log.i(TAG, "Finalized dual recordings: ${enhFile?.name} and ${rawFile?.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Error finalizing dual WAV files", e)
        } finally {
            _recordingState.value = RecordingState(isRecording = false)
        }

        return if (enhFile != null && rawFile != null) {
            val durationMs = (bytesWritten / (sampleRate * 2.0) * 1000.0).toLong()
            DualRecordingResult(enhFile, rawFile, durationMs, sampleRate)
        } else null
    }

    override fun release() {
        stopRecording()
    }
}
