package com.example.noisesuppression

import com.example.settings.ProcessingSettings
import kotlin.math.*

/**
 * Real-time streaming DSP Speech Isolation & Spectral Noise Suppression Engine.
 *
 * Signal Flow:
 * 1. Pre-amp linear input gain stage.
 * 2. 80 Hz 2nd-order Butterworth High-Pass Filter for rumble, wind, and HVAC rejection.
 * 3. Transient key-click & mechanical tap slew-rate limiter.
 * 4. 512-Point STFT / FFT with Square-Root Hann WOLA windowing and circular Overlap-Add.
 * 5. Multi-Feature VAD (Speech SNR, ZCR, Spectral Flatness, Flux) + Hangover State Machine.
 * 6. Minimum-Statistics Noise PSD estimation (with fast initial 500ms calibration).
 * 7. Decision-Directed A Priori SNR & Adaptive Parametric Wiener Filter.
 * 8. Soft spectral noise gate with smooth attack/release during non-speech intervals.
 */
class NoiseSuppressorDsp(private var sampleRate: Int = 48000) {

    // True STFT / FFT Spectral Isolation Engine
    val spectralSuppressor = SpectralNoiseSuppressor(sampleRate)

    // High-pass filter state (Biquad Butterworth 80 Hz)
    private var hpX1 = 0f; private var hpX2 = 0f; private var hpY1 = 0f; private var hpY2 = 0f
    private var hpB0 = 1f; private var hpB1 = -2f; private var hpB2 = 1f
    private var hpA1 = 0f; private var hpA2 = 0f

    // Gate & Envelope state
    private var gateGain = 1.0f
    private var vadHangoverFrames = 0

    val currentNoiseLevelDb: Float
        get() = spectralSuppressor.currentNoiseLevelDb

    val voiceProbability: Float
        get() = spectralSuppressor.voiceProbability

    val noiseProbability: Float
        get() = spectralSuppressor.noiseProbability

    val snrImprovementDb: Float
        get() = spectralSuppressor.currentSnrImprovementDb

    init {
        updateHighPassCoefficients(80.0, sampleRate.toDouble())
    }

    fun setSampleRate(newRate: Int) {
        if (sampleRate != newRate) {
            sampleRate = newRate
            updateHighPassCoefficients(80.0, sampleRate.toDouble())
            spectralSuppressor.setSampleRate(newRate)
            reset()
        }
    }

    fun reset() {
        hpX1 = 0f; hpX2 = 0f; hpY1 = 0f; hpY2 = 0f
        gateGain = 1.0f
        vadHangoverFrames = 0
        spectralSuppressor.reset()
    }

    private fun updateHighPassCoefficients(cutoffFreq: Double, fs: Double) {
        val fCut = cutoffFreq.coerceAtMost(fs * 0.40)
        val w0 = 2.0 * Math.PI * fCut / fs
        val cosW0 = cos(w0)
        val alpha = sin(w0) / (2.0 * 0.7071)
        val a0 = 1.0 + alpha

        hpB0 = ((1.0 + cosW0) / 2.0 / a0).toFloat()
        hpB1 = (-(1.0 + cosW0) / a0).toFloat()
        hpB2 = ((1.0 + cosW0) / 2.0 / a0).toFloat()
        hpA1 = (-2.0 * cosW0 / a0).toFloat()
        hpA2 = ((1.0 - alpha) / a0).toFloat()
    }

    fun processFrame(
        buffer: ShortArray,
        length: Int,
        settings: ProcessingSettings
    ): Float {
        if (length <= 0) return 0f

        // Pre-amp Input Gain
        if (settings.inputGainDb != 0.0f) {
            val inGain = 10.0.pow(settings.inputGainDb.toDouble() / 20.0).toFloat()
            for (i in 0 until length) {
                val s = buffer[i] * inGain
                buffer[i] = s.toInt().coerceIn(-32768, 32767).toShort()
            }
        }

        // 1. High-Pass Filter Pass (DC & Sub-bass rumble removal)
        if (settings.lowRumbleCut) {
            for (i in 0 until length) {
                val input = buffer[i] / 32768.0f
                val output = hpB0 * input + hpB1 * hpX1 + hpB2 * hpX2 - hpA1 * hpY1 - hpA2 * hpY2

                hpX2 = hpX1
                hpX1 = input
                hpY2 = hpY1
                hpY1 = output

                buffer[i] = (output.coerceIn(-1f, 1f) * 32767.0f).toInt().toShort()
            }
        }

        if (!settings.backgroundNoiseRemovalEnabled && settings.noiseSuppressionLevel <= 0f) {
            return calculateVAD(buffer, length)
        }

        val suppressionFactor = settings.noiseSuppressionLevel.coerceIn(0f, 1f)

        // 2. Transient Key-click & Mechanical Tap Suppressor
        suppressTransients(buffer, length, suppressionFactor)

        // 3. Real STFT Spectral Subtraction & Adaptive Wiener Filter
        val vadProb = spectralSuppressor.process(buffer, length, suppressionFactor)

        // Apply VAD Hangover (keep voice gate open for ~80ms to avoid clipping word ends)
        val isVoiceActive = vadProb > (1.0f - settings.vadSensitivity * 0.6f)
        if (isVoiceActive) {
            vadHangoverFrames = 8
        } else if (vadHangoverFrames > 0) {
            vadHangoverFrames--
        }

        val effectiveVad = if (vadHangoverFrames > 0) max(vadProb, 0.65f) else vadProb

        // 4. Soft Noise Gate during non-speech intervals
        applySoftNoiseGate(buffer, length, effectiveVad, suppressionFactor)

        return effectiveVad
    }

    private fun suppressTransients(buffer: ShortArray, length: Int, factor: Float) {
        if (factor < 0.15f) return
        val maxDelta = (32767.0f * (1.05f - factor * 0.55f)).toInt()
        var prevSample = buffer[0].toInt()

        for (i in 1 until length) {
            val current = buffer[i].toInt()
            val delta = current - prevSample
            if (abs(delta) > maxDelta) {
                val damped = prevSample + (delta.sign * maxDelta)
                buffer[i] = damped.coerceIn(-32768, 32767).toShort()
                prevSample = damped
            } else {
                prevSample = current
            }
        }
    }

    private fun applySoftNoiseGate(
        buffer: ShortArray,
        length: Int,
        vadProbability: Float,
        suppressionFactor: Float
    ) {
        val targetGateGain = if (vadProbability < 0.25f) {
            (1.0f - suppressionFactor * 0.80f).coerceAtLeast(0.10f)
        } else {
            1.0f
        }

        val alpha = if (targetGateGain < gateGain) 0.04f else 0.25f
        for (i in 0 until length) {
            gateGain = (1f - alpha) * gateGain + alpha * targetGateGain
            val sample = (buffer[i] * gateGain).toInt()
            buffer[i] = sample.coerceIn(-32768, 32767).toShort()
        }
    }

    private fun calculateVAD(buffer: ShortArray, length: Int): Float {
        var sumSquares = 0.0
        for (i in 0 until length) {
            val s = buffer[i] / 32768.0
            sumSquares += s * s
        }
        val rms = sqrt(sumSquares / length).toFloat()
        return (rms / 0.05f).coerceIn(0f, 1f)
    }
}
