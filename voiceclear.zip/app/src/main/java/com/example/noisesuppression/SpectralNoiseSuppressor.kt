package com.example.noisesuppression

import kotlin.math.*

/**
 * Real-Time STFT Spectral Speech Isolation & Noise Suppression Engine.
 *
 * Architecture & DSP Pipeline:
 * 1. 512-Point Fast Fourier Transform (STFT) with Square-Root Hann WOLA windowing (50% overlap, hop=256).
 * 2. Continuous Minimum-Tracking Noise Power Spectral Density (PSD) Estimator with initial 500ms rapid calibration.
 * 3. Multi-Feature Voice Activity Detection (VAD) utilizing:
 *    - Sub-band Speech SNR (300Hz - 3400Hz)
 *    - Zero Crossing Rate (ZCR)
 *    - Spectral Flatness Measure (SFM / Wiener Entropy)
 *    - Inter-frame Spectral Flux
 * 4. Decision-Directed (DD) A Priori SNR Estimation (Ephraim-Malah formulation).
 * 5. Parametric Wiener & Spectral Subtraction Gain Matrix with dynamic spectral floor & formant protection.
 * 6. Temporal Multi-frame Gain Smoothing (attack/release) preventing musical noise artifacts.
 * 7. In-place Synthesis Windowing, Inverse FFT (IFFT), and circular Overlap-Add (OLA) reconstruction.
 */
class SpectralNoiseSuppressor(
    private var sampleRate: Int = 48000,
    val fftSize: Int = 512,
    val hopSize: Int = 256 // 50% overlap
) {
    private val stft = StftTransformer(fftSize)
    val numBins: Int = stft.numBins // 257 bins for 512-point FFT

    // Circular input/analysis buffer for streaming STFT frames
    private val inputHistory = FloatArray(fftSize)
    private var inputWritePos = 0

    // Overlap-Add (OLA) circular synthesis reconstruction buffer
    private val olaBuffer = FloatArray(fftSize * 2)
    private var olaReadPos = 0
    private var olaWritePos = 0

    // Temporary frame buffers (zero allocation in loop)
    private val frameIn = FloatArray(fftSize)
    private val frameOut = FloatArray(fftSize)

    // Spectral power & noise tracking buffers
    private val powerSpectrum = FloatArray(numBins)
    private val prevPowerSpectrum = FloatArray(numBins)
    private val smoothedPower = FloatArray(numBins)
    private val noisePsd = FloatArray(numBins) { 0.0001f }
    private val minPsdTracker = FloatArray(numBins) { 0.0001f }

    // SNR & Decision-Directed state
    private val aPosterioriSnr = FloatArray(numBins)
    private val aPrioriSnr = FloatArray(numBins)
    private val prevEstimatedSignalPower = FloatArray(numBins)

    // Spectral Gains
    val spectralGains = FloatArray(numBins) { 1.0f }
    private val smoothedGains = FloatArray(numBins) { 1.0f }

    // Multi-Feature VAD State
    var voiceProbability: Float = 0.0f
        private set
    var noiseProbability: Float = 1.0f
        private set
    private var vadHangover = 0
    private var framesProcessedCount = 0

    // Frequency to bin mapping (dynamically recomputed on sample rate change)
    private var hzPerBin = sampleRate.toFloat() / fftSize
    private var speechBinStart = 1
    private var speechBinEnd = numBins - 1

    // Noise telemetry in dBFS & True Measured SNR Gain
    var currentNoiseLevelDb: Float = -60f
        private set
    var currentSnrImprovementDb: Float = 0f
        private set

    init {
        updateBinBoundaries()
    }

    private fun updateBinBoundaries() {
        hzPerBin = sampleRate.toFloat() / fftSize
        speechBinStart = (300.0f / hzPerBin).toInt().coerceIn(1, numBins - 2)
        speechBinEnd = (3400.0f / hzPerBin).toInt().coerceIn(speechBinStart + 1, numBins - 1)
    }

    fun setSampleRate(newRate: Int) {
        if (sampleRate != newRate) {
            sampleRate = newRate
            updateBinBoundaries()
            reset()
        }
    }

    fun reset() {
        inputHistory.fill(0f)
        inputWritePos = 0
        olaBuffer.fill(0f)
        olaReadPos = 0
        olaWritePos = 0
        frameIn.fill(0f)
        frameOut.fill(0f)

        powerSpectrum.fill(0f)
        prevPowerSpectrum.fill(0f)
        smoothedPower.fill(0f)
        noisePsd.fill(0.0001f)
        minPsdTracker.fill(0.0001f)
        aPosterioriSnr.fill(1f)
        aPrioriSnr.fill(1f)
        prevEstimatedSignalPower.fill(0f)
        spectralGains.fill(1f)
        smoothedGains.fill(1f)

        voiceProbability = 0f
        noiseProbability = 1f
        vadHangover = 0
        framesProcessedCount = 0
        currentNoiseLevelDb = -60f
        currentSnrImprovementDb = 0f
    }

    /**
     * Process an arbitrary length PCM 16-bit audio buffer through the STFT & OLA Spectral Engine.
     * Modifies [buffer] in-place.
     *
     * @param buffer PCM 16-bit sample buffer
     * @param length Number of samples in buffer
     * @param suppressionFactor User noise suppression level (0.0 to 1.0)
     * @return Multi-feature VAD speech probability (0.0 to 1.0)
     */
    fun process(buffer: ShortArray, length: Int, suppressionFactor: Float): Float {
        if (length <= 0) return 0f

        val strength = suppressionFactor.coerceIn(0.0f, 1.0f)
        var lastVad = voiceProbability

        for (i in 0 until length) {
            // Normalize sample to [-1.0, 1.0] and push to input circular history
            val inSample = buffer[i] / 32768.0f
            inputHistory[inputWritePos] = inSample
            inputWritePos = (inputWritePos + 1) % fftSize

            // When a hopSize boundary is crossed (every 256 samples), execute STFT analysis-synthesis
            if (inputWritePos % hopSize == 0) {
                lastVad = processStftFrame(strength)
            }

            // Read reconstructed sample from Overlap-Add circular buffer
            val olaSample = olaBuffer[olaReadPos]
            olaBuffer[olaReadPos] = 0.0f // Clear consumed position
            olaReadPos = (olaReadPos + 1) % olaBuffer.size

            // Clamp and write back to output buffer
            val outInt = (olaSample.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt()
            buffer[i] = outInt.coerceIn(-32768, 32767).toShort()
        }

        return lastVad
    }

    /**
     * Executes one complete STFT frame cycle:
     * 1. Window -> FFT
     * 2. Multi-Feature Acoustic Analysis (SNR, ZCR, Spectral Flatness, Flux)
     * 3. Noise PSD Minimum Tracking (with initial 500ms calibration)
     * 4. Multi-Feature VAD
     * 5. Decision-Directed A Priori SNR & Spectral Wiener Gain Calculation
     * 6. Formant Protection & Temporal Smoothing
     * 7. Complex Gain Application -> IFFT -> Overlap-Add
     */
    private fun processStftFrame(suppressionStrength: Float): Float {
        framesProcessedCount++

        // 1. Gather chronological frame from input history
        for (i in 0 until fftSize) {
            val idx = (inputWritePos + i) % fftSize
            frameIn[i] = inputHistory[idx]
        }

        // 2. Forward FFT with Square-Root Hann window
        stft.forwardFft(frameIn, 0)

        // 3. Compute Power Spectrum |X(k)|^2
        stft.computePowerSpectrum(powerSpectrum)

        // 4. Update Smoothed Power Spectrum
        val alphaP = 0.70f
        for (k in 0 until numBins) {
            smoothedPower[k] = alphaP * smoothedPower[k] + (1.0f - alphaP) * powerSpectrum[k]
        }

        // 5. Multi-Feature Acoustic Analysis
        // Feature A: Zero Crossing Rate (ZCR)
        var zeroCrossings = 0
        for (i in 1 until fftSize) {
            if ((frameIn[i] >= 0f && frameIn[i - 1] < 0f) || (frameIn[i] < 0f && frameIn[i - 1] >= 0f)) {
                zeroCrossings++
            }
        }
        val zcr = zeroCrossings.toFloat() / (fftSize - 1)

        // Feature B: Spectral Flatness Measure (SFM / Wiener Entropy)
        var sumLogPower = 0.0
        var sumLinearPower = 0.0
        val sfmBins = speechBinEnd - speechBinStart + 1
        for (k in speechBinStart..speechBinEnd) {
            val p = (powerSpectrum[k] + 1e-9f).toDouble()
            sumLogPower += ln(p)
            sumLinearPower += p
        }
        val geometricMean = exp(sumLogPower / sfmBins)
        val arithmeticMean = (sumLinearPower / sfmBins).coerceAtLeast(1e-9)
        val spectralFlatness = (geometricMean / arithmeticMean).toFloat().coerceIn(0.0f, 1.0f)

        // Feature C: Inter-frame Spectral Flux
        var spectralFlux = 0.0f
        if (framesProcessedCount > 1) {
            for (k in speechBinStart..speechBinEnd) {
                val diff = sqrt(powerSpectrum[k]) - sqrt(prevPowerSpectrum[k])
                if (diff > 0f) spectralFlux += diff * diff
            }
        }
        // Save current spectrum for next frame's flux
        System.arraycopy(powerSpectrum, 0, prevPowerSpectrum, 0, numBins)

        // 6. Noise PSD Estimation using Continuous Minimum Statistics Tracking
        // Fast initial learning during the first ~500ms (approx 40 frames @ 48kHz, hop 256)
        val isInitialCalibration = framesProcessedCount < 40
        val alphaRise = if (isInitialCalibration) 0.80f else 0.998f
        val alphaFall = if (isInitialCalibration) 0.40f else 0.20f
        var totalNoiseEnergy = 0.0f

        for (k in 0 until numBins) {
            val p = smoothedPower[k]
            if (p < minPsdTracker[k]) {
                minPsdTracker[k] = (1.0f - alphaFall) * minPsdTracker[k] + alphaFall * p
            } else {
                minPsdTracker[k] = alphaRise * minPsdTracker[k] + (1.0f - alphaRise) * p
            }

            // A posteriori SNR: gamma(k) = P(k) / lambda_N(k)
            val currentNoise = noisePsd[k].coerceAtLeast(1e-7f)
            val gamma = (powerSpectrum[k] / currentNoise).coerceIn(0.01f, 100.0f)
            aPosterioriSnr[k] = gamma

            // Update noise PSD: update rapidly during non-speech, slowly during speech
            val isSpeechLikely = gamma > 2.2f && !isInitialCalibration
            val alphaN = if (isSpeechLikely) 0.988f else (if (isInitialCalibration) 0.70f else 0.85f)
            noisePsd[k] = alphaN * noisePsd[k] + (1.0f - alphaN) * minPsdTracker[k]
            totalNoiseEnergy += noisePsd[k]
        }

        // Noise level in dBFS
        val noiseRms = sqrt(totalNoiseEnergy / numBins)
        currentNoiseLevelDb = (20.0f * log10(noiseRms.coerceAtLeast(1e-5f))).coerceIn(-60f, 0f)

        // 7. Multi-Feature Voice Activity Detection (VAD)
        var speechBandEnergy = 0.0f
        var speechNoiseEnergy = 0.0f
        for (k in speechBinStart..speechBinEnd) {
            speechBandEnergy += powerSpectrum[k]
            speechNoiseEnergy += noisePsd[k]
        }

        val speechSnr = (speechBandEnergy + 1e-6f) / (speechNoiseEnergy + 1e-6f)
        val snrScore = ((speechSnr - 1.5f) / 5.0f).coerceIn(0.0f, 1.0f)
        val flatnessScore = (1.0f - (spectralFlatness / 0.75f)).coerceIn(0.0f, 1.0f) // Lower flatness -> higher speech likelihood
        val zcrScore = if (zcr in 0.04f..0.32f) 1.0f else (1.0f - abs(zcr - 0.18f) * 3.0f).coerceIn(0.0f, 1.0f)

        // Composite Multi-Feature VAD probability (weighted combination)
        val compositeVad = (0.50f * snrScore + 0.30f * flatnessScore + 0.20f * zcrScore).coerceIn(0.0f, 1.0f)

        // Speech Hangover Protection (preserves soft consonants and word endings)
        if (compositeVad > 0.45f) {
            vadHangover = 14 // ~75 ms hangover
            voiceProbability = compositeVad
        } else if (vadHangover > 0) {
            vadHangover--
            voiceProbability = max(0.50f, compositeVad)
        } else {
            voiceProbability = compositeVad
        }
        noiseProbability = (1.0f - voiceProbability).coerceIn(0.0f, 1.0f)

        // 8. Decision-Directed (DD) A Priori SNR & Spectral Wiener Gain Computation
        val alphaDd = 0.92f
        val suppressionScale = suppressionStrength.coerceIn(0.0f, 1.0f)

        // Dynamic spectral floor: prevents robotic/musical noise artifacts
        val minGainFloor = (1.0f - suppressionScale * 0.93f).coerceAtLeast(0.03f)
        val oversubFactor = 1.0f + suppressionScale * 1.6f

        for (k in 0 until numBins) {
            val gamma = aPosterioriSnr[k]
            val prevS = prevEstimatedSignalPower[k]
            val currentNoise = noisePsd[k].coerceAtLeast(1e-7f)

            val priorFromPrev = (prevS / currentNoise)
            val priorFromCurrent = max(gamma - 1.0f, 0.0f)
            val xi = (alphaDd * priorFromPrev + (1.0f - alphaDd) * priorFromCurrent).coerceIn(0.001f, 100.0f)
            aPrioriSnr[k] = xi

            // Parametric Wiener Spectral Gain: G(k) = xi / (xi + oversubFactor)
            val rawGain = (xi / (xi + oversubFactor)).coerceIn(0.01f, 1.0f)

            // Human voice formant protection (300Hz - 3.4kHz)
            val formantWeight = if (k in speechBinStart..speechBinEnd) 1.15f else 0.85f
            val boostedGain = (rawGain * formantWeight).coerceIn(minGainFloor, 1.0f)

            // Dynamic gain curvature
            val targetGain = (boostedGain.pow(1.0f + suppressionScale * 0.5f)).coerceIn(minGainFloor, 1.0f)

            // 9. Temporal Multi-frame Smoothing (Attack/Release)
            val smoothCoeff = if (targetGain > smoothedGains[k]) 0.40f else 0.70f
            smoothedGains[k] = smoothCoeff * smoothedGains[k] + (1.0f - smoothCoeff) * targetGain
            spectralGains[k] = smoothedGains[k]

            // Save signal power estimate for next frame's DD recursion
            prevEstimatedSignalPower[k] = powerSpectrum[k] * (smoothedGains[k] * smoothedGains[k])

            // Apply gain directly to complex spectrum
            val g = smoothedGains[k]
            stft.real[k] *= g
            stft.imag[k] *= g

            // Enforce conjugate symmetry for negative frequency bins
            if (k > 0 && k < stft.halfSize) {
                val mirror = fftSize - k
                stft.real[mirror] = stft.real[k]
                stft.imag[mirror] = -stft.imag[k]
            }
        }
        stft.imag[0] = 0.0f
        stft.imag[stft.halfSize] = 0.0f

        // Compute mathematically true SNR Improvement (dB of noise floor attenuation by Wiener gain matrix)
        var sumRawNoise = 0.0
        var sumFilteredNoise = 0.0
        for (k in 0 until numBins) {
            val n = noisePsd[k].toDouble()
            sumRawNoise += n
            val g = smoothedGains[k].toDouble()
            sumFilteredNoise += n * (g * g)
        }
        val noiseReductionRatio = (sumRawNoise / sumFilteredNoise.coerceAtLeast(1e-12))
        currentSnrImprovementDb = (10.0 * log10(noiseReductionRatio)).toFloat().coerceIn(0.0f, 35.0f)

        // 10. Inverse FFT with synthesis windowing and 1/N scaling
        stft.inverseFft(frameOut, 0)

        // 11. Overlap-Add (OLA) synthesis into circular reconstruction buffer
        for (i in 0 until fftSize) {
            val outIdx = (olaReadPos + i) % olaBuffer.size
            olaBuffer[outIdx] += frameOut[i]
        }

        return voiceProbability
    }
}
