package com.example.noisesuppression

import kotlin.math.*

/**
 * High-performance, zero-allocation Fast Fourier Transform (FFT) & Inverse FFT (IFFT) engine.
 * Implements in-place Radix-2 Decimation-In-Time (DIT) Cooley-Tukey algorithm
 * with precomputed bit-reversal lookup tables, twiddle factors, and Weighted Overlap-Add (WOLA)
 * using Square-Root Periodic Hann Analysis & Synthesis Windows.
 *
 * Mathematical WOLA Property for 50% Overlap (hop = N / 2):
 * w_a[n] = sqrt(0.5 * (1 - cos(2 * PI * n / N)))
 * w_s[n] = sqrt(0.5 * (1 - cos(2 * PI * n / N)))
 * w_a[n] * w_s[n] = 0.5 * (1 - cos(2 * PI * n / N)) = Hann[n]
 * Sum_{m} (w_a[n - m*H] * w_s[n - m*H]) = 1.0 (Exact Constant OverLap-Add, COLA)
 *
 * This guarantees mathematically perfect reconstruction with zero gain distortion and
 * zero RMS error on bypass.
 */
class StftTransformer(val fftSize: Int = 512) {

    init {
        require(fftSize > 0 && (fftSize and (fftSize - 1)) == 0) {
            "FFT size must be a power of 2 (e.g. 256, 512, 1024), got $fftSize"
        }
    }

    val halfSize: Int = fftSize / 2
    val numBins: Int = halfSize + 1

    // Precomputed Square-Root Hann analysis and synthesis windows
    val analysisWindow = FloatArray(fftSize)
    val synthesisWindow = FloatArray(fftSize)

    // Precomputed bit-reversal indices
    private val bitReversal = IntArray(fftSize)

    // Precomputed twiddle factors for FFT and IFFT
    private val cosTable = FloatArray(halfSize)
    private val sinTable = FloatArray(halfSize)

    // Internal working arrays for FFT (reused across all frames, zero allocation)
    val real = FloatArray(fftSize)
    val imag = FloatArray(fftSize)

    init {
        // 1. Compute bit-reversal lookup table
        val log2N = (31 - Integer.numberOfLeadingZeros(fftSize))
        for (i in 0 until fftSize) {
            var reversed = 0
            var temp = i
            for (j in 0 until log2N) {
                reversed = (reversed shl 1) or (temp and 1)
                temp = temp shr 1
            }
            bitReversal[i] = reversed
        }

        // 2. Compute twiddle factor tables (e^(-j * 2 * PI * k / N))
        for (k in 0 until halfSize) {
            val angle = -2.0 * PI * k / fftSize
            cosTable[k] = cos(angle).toFloat()
            sinTable[k] = sin(angle).toFloat()
        }

        // 3. Compute Square-Root Hann Windows for WOLA
        for (n in 0 until fftSize) {
            val periodicHann = 0.5 * (1.0 - cos(2.0 * PI * n / fftSize))
            val sqrtHann = sqrt(periodicHann).toFloat()
            analysisWindow[n] = sqrtHann
            synthesisWindow[n] = sqrtHann
        }
    }

    /**
     * Compute forward FFT on input samples with Square-Root Hann analysis windowing.
     * Output complex spectrum is stored in [real] and [imag] buffers.
     */
    fun forwardFft(timeSamples: FloatArray, offset: Int = 0) {
        // Apply analysis window and bit-reversal permutation
        for (i in 0 until fftSize) {
            val rev = bitReversal[i]
            real[rev] = timeSamples[offset + i] * analysisWindow[i]
            imag[rev] = 0.0f
        }

        // Cooley-Tukey Radix-2 Butterflies
        var len = 2
        while (len <= fftSize) {
            val halfLen = len shr 1
            val step = fftSize / len
            var i = 0
            while (i < fftSize) {
                var k = 0
                for (j in 0 until halfLen) {
                    val c = cosTable[k]
                    val s = sinTable[k]

                    val idx1 = i + j
                    val idx2 = idx1 + halfLen

                    val tr = real[idx2] * c - imag[idx2] * s
                    val ti = real[idx2] * s + imag[idx2] * c

                    real[idx2] = real[idx1] - tr
                    imag[idx2] = imag[idx1] - ti
                    real[idx1] += tr
                    imag[idx1] += ti

                    k += step
                }
                i += len
            }
            len = len shl 1
        }
    }

    /**
     * Compute inverse FFT (IFFT) from complex spectrum in [real] and [imag].
     * Applies synthesis window and normalizes by 1/N.
     * Writes reconstructed time-domain samples to [outputSamples].
     */
    fun inverseFft(outputSamples: FloatArray, offset: Int = 0) {
        // Bit-reversal permutation
        for (i in 0 until fftSize) {
            val rev = bitReversal[i]
            if (i < rev) {
                val tempR = real[i]; real[i] = real[rev]; real[rev] = tempR
                val tempI = imag[i]; imag[i] = imag[rev]; imag[rev] = tempI
            }
        }

        // Cooley-Tukey with conjugated twiddle factors (positive sine)
        var len = 2
        while (len <= fftSize) {
            val halfLen = len shr 1
            val step = fftSize / len
            var i = 0
            while (i < fftSize) {
                var k = 0
                for (j in 0 until halfLen) {
                    val c = cosTable[k]
                    val s = -sinTable[k] // Conjugated for IFFT

                    val idx1 = i + j
                    val idx2 = idx1 + halfLen

                    val tr = real[idx2] * c - imag[idx2] * s
                    val ti = real[idx2] * s + imag[idx2] * c

                    real[idx2] = real[idx1] - tr
                    imag[idx2] = imag[idx1] - ti
                    real[idx1] += tr
                    imag[idx1] += ti

                    k += step
                }
                i += len
            }
            len = len shl 1
        }

        // Scale by 1/N and apply square-root synthesis window
        val scale = 1.0f / fftSize
        for (i in 0 until fftSize) {
            outputSamples[offset + i] = real[i] * scale * synthesisWindow[i]
        }
    }

    /**
     * Computes the one-sided power spectrum |X(k)|^2 for positive frequency bins [0 .. numBins-1].
     */
    fun computePowerSpectrum(outPower: FloatArray) {
        val limit = min(numBins, outPower.size)
        for (k in 0 until limit) {
            val r = real[k]
            val im = imag[k]
            outPower[k] = r * r + im * im
        }
    }

    /**
     * Computes the one-sided magnitude spectrum |X(k)| for positive frequency bins [0 .. numBins-1].
     */
    fun computeMagnitudeSpectrum(outMagnitude: FloatArray) {
        val limit = min(numBins, outMagnitude.size)
        for (k in 0 until limit) {
            val r = real[k]
            val im = imag[k]
            outMagnitude[k] = sqrt(r * r + im * im)
        }
    }
}
