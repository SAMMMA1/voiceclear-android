package com.example.foregroundservice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audioengine.AudioEngine
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import com.example.settings.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class VoiceEnhancerService : Service() {
    private val TAG = "VoiceEnhancerService"

    private val binder = LocalBinder()
    lateinit var audioEngine: AudioEngine
        private set
    lateinit var settingsRepository: SettingsRepository
        private set

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var isServiceRunning = false

    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    inner class LocalBinder : Binder() {
        fun getService(): VoiceEnhancerService = this@VoiceEnhancerService
    }

    override fun onCreate() {
        super.onCreate()
        audioEngine = AudioEngine(applicationContext)
        settingsRepository = SettingsRepository(applicationContext)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        createNotificationChannel()

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VoiceClear::AudioProcessingWakeLock")

        scope.launch {
            settingsRepository.settingsFlow.collectLatest { settings ->
                if (isServiceRunning) {
                    audioEngine.currentSettings = settings
                    updateNotification(settings)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startEnhancement()
            ACTION_STOP -> stopEnhancement()
            ACTION_TOGGLE -> {
                if (isServiceRunning) stopEnhancement() else startEnhancement()
            }
            ACTION_APPLY_PRESET -> {
                val presetName = intent.getStringExtra(EXTRA_PRESET) ?: PresetType.GAMING.name
                val preset = runCatching { PresetType.valueOf(presetName) }.getOrDefault(PresetType.GAMING)
                settingsRepository.applyPreset(preset)
            }
        }
        return START_STICKY
    }

    fun startEnhancement(): Boolean {
        if (isServiceRunning) return true
        val settings = settingsRepository.settingsFlow.value

        requestAudioFocus()
        try {
            wakeLock?.takeIf { !it.isHeld }?.acquire(4 * 60 * 60 * 1000L) // 4 hours safety timeout
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock acquisition warning", e)
        }

        val started = audioEngine.start(settings)
        if (started) {
            isServiceRunning = true
            val notification = buildNotification(settings)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            return true
        } else {
            abandonAudioFocus()
            try {
                wakeLock?.takeIf { it.isHeld }?.release()
            } catch (_: Exception) {}
        }
        return false
    }

    fun stopEnhancement() {
        if (!isServiceRunning) return
        isServiceRunning = false
        audioEngine.stop()
        abandonAudioFocus()
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun requestAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener { focusChange ->
                        Log.d(TAG, "Audio focus changed: $focusChange")
                    }
                    .build()
                audioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    { focusChange -> Log.d(TAG, "Audio focus changed: $focusChange") },
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed requesting audio focus", e)
        }
    }

    private fun abandonAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed abandoning audio focus", e)
        }
    }

    fun isEnhancing(): Boolean = isServiceRunning

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(settings: ProcessingSettings): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceEnhancerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val presetTitle = settings.activePreset.title
        val noisePct = (settings.noiseSuppressionLevel * 100).toInt()
        val clarityPct = (settings.voiceClarity * 100).toInt()
        val dspStatus = if (settings.aiEnhancementEnabled) " • STFT DSP" else ""

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VoiceClear • $presetTitle Mode Active$dspStatus")
            .setContentText("Noise Suppression: $noisePct% • Voice Clarity: $clarityPct%")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Turn OFF", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(settings: ProcessingSettings) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(settings))
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        stopEnhancement()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "voiceclear_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.voiceclear.ACTION_START"
        const val ACTION_STOP = "com.example.voiceclear.ACTION_STOP"
        const val ACTION_TOGGLE = "com.example.voiceclear.ACTION_TOGGLE"
        const val ACTION_APPLY_PRESET = "com.example.voiceclear.ACTION_APPLY_PRESET"
        const val EXTRA_PRESET = "EXTRA_PRESET"

        fun startService(context: Context) {
            val intent = Intent(context, VoiceEnhancerService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, VoiceEnhancerService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
