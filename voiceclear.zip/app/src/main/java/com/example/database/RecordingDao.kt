package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {
    @Query("SELECT * FROM audio_recordings ORDER BY createdAt DESC")
    fun getAllRecordings(): Flow<List<AudioRecordingEntity>>

    @Query("SELECT * FROM audio_recordings WHERE id = :id LIMIT 1")
    suspend fun getRecordingById(id: Long): AudioRecordingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(recording: AudioRecordingEntity): Long

    @Delete
    suspend fun deleteRecording(recording: AudioRecordingEntity)

    @Query("DELETE FROM audio_recordings WHERE id = :id")
    suspend fun deleteRecordingById(id: Long)

    @Query("UPDATE audio_recordings SET title = :newTitle WHERE id = :id")
    suspend fun updateRecordingTitle(id: Long, newTitle: String)
}
