package com.example.database

import kotlinx.coroutines.flow.Flow

class DatabaseRepository(
    private val presetDao: PresetDao,
    private val recordingDao: RecordingDao
) {
    val allPresets: Flow<List<CustomPresetEntity>> = presetDao.getAllPresets()
    val allRecordings: Flow<List<AudioRecordingEntity>> = recordingDao.getAllRecordings()

    suspend fun insertPreset(preset: CustomPresetEntity): Long = presetDao.insertPreset(preset)

    suspend fun updatePreset(preset: CustomPresetEntity) = presetDao.updatePreset(preset)

    suspend fun deletePreset(id: Long) = presetDao.deletePresetById(id)

    suspend fun insertRecording(recording: AudioRecordingEntity): Long = recordingDao.insertRecording(recording)

    suspend fun deleteRecording(id: Long) = recordingDao.deleteRecordingById(id)

    suspend fun updateRecordingTitle(id: Long, title: String) = recordingDao.updateRecordingTitle(id, title)
}
