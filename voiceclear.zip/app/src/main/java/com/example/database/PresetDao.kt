package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PresetDao {
    @Query("SELECT * FROM custom_presets ORDER BY isBuiltIn DESC, createdAt ASC")
    fun getAllPresets(): Flow<List<CustomPresetEntity>>

    @Query("SELECT * FROM custom_presets WHERE id = :id LIMIT 1")
    suspend fun getPresetById(id: Long): CustomPresetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreset(preset: CustomPresetEntity): Long

    @Update
    suspend fun updatePreset(preset: CustomPresetEntity)

    @Delete
    suspend fun deletePreset(preset: CustomPresetEntity)

    @Query("DELETE FROM custom_presets WHERE id = :id AND isBuiltIn = 0")
    suspend fun deletePresetById(id: Long)

    @Query("SELECT COUNT(*) FROM custom_presets")
    suspend fun getCount(): Int
}
