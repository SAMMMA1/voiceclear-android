package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audio_recordings")
data class AudioRecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val sampleRate: Int = 48000,
    val isEnhanced: Boolean = true,
    val presetUsed: String = "Gaming",
    val createdAt: Long = System.currentTimeMillis()
)
