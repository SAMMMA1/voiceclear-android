package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audio_recordings")
data class AudioRecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val filePath: String, // Cleaned / Enhanced WAV file path
    val rawFilePath: String? = null, // Original / Raw mic WAV file path
    val durationMs: Long,
    val fileSizeBytes: Long,
    val rawFileSizeBytes: Long = 0L,
    val sampleRate: Int = 48000,
    val isEnhanced: Boolean = true,
    val presetUsed: String = "Clean Voice",
    val createdAt: Long = System.currentTimeMillis()
)

