package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_presets")
data class CustomPresetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String,
    val iconColorHex: String = "#00E5FF",
    val noiseSuppressionLevel: Float = 0.80f,
    val voiceClarity: Float = 0.75f,
    val voiceFocus: Float = 0.70f,
    val echoCancellationEnabled: Boolean = true,
    val automaticGainControlEnabled: Boolean = true,
    val backgroundNoiseRemovalEnabled: Boolean = true,
    val lowLatencyMode: Boolean = true,
    val sampleRate: Int = 48000,
    val aiEnhancementEnabled: Boolean = true,
    val aiModelStrength: Float = 0.85f,
    val inputGainDb: Float = 0.0f,
    val outputGainDb: Float = 0.0f,
    val vadSensitivity: Float = 0.50f,
    val limiterThresholdDb: Float = -0.5f,
    val lowRumbleCut: Boolean = true,
    val warmthDb: Float = 1.8f,
    val presenceDb: Float = 4.5f,
    val airDb: Float = 2.0f,
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
