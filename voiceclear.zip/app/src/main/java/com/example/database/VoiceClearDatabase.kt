package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [CustomPresetEntity::class, AudioRecordingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VoiceClearDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile
        private var INSTANCE: VoiceClearDatabase? = null

        fun getDatabase(context: Context): VoiceClearDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VoiceClearDatabase::class.java,
                    "voiceclear_database"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            INSTANCE?.let { database ->
                                seedDefaultPresets(database.presetDao())
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaultPresets(dao: PresetDao) {
            val defaults = listOf(
                CustomPresetEntity(
                    name = "Gaming & Discord",
                    description = "Ultra low-latency, mechanical keyboard click suppression, and crisp presence boost",
                    iconColorHex = "#00E5FF",
                    noiseSuppressionLevel = 0.85f,
                    voiceClarity = 0.80f,
                    voiceFocus = 0.80f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 1.2f,
                    presenceDb = 4.8f,
                    airDb = 2.5f,
                    isBuiltIn = true
                ),
                CustomPresetEntity(
                    name = "Studio Podcast",
                    description = "Warm vocal tone, smooth broadcast AGC leveling, subtle noise reduction",
                    iconColorHex = "#00E676",
                    noiseSuppressionLevel = 0.60f,
                    voiceClarity = 0.90f,
                    voiceFocus = 0.65f,
                    echoCancellationEnabled = false,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 3.2f,
                    presenceDb = 4.0f,
                    airDb = 3.5f,
                    isBuiltIn = true
                ),
                CustomPresetEntity(
                    name = "Echoey Room & Office",
                    description = "Strong Acoustic Echo Cancellation and voice isolation for reverberant rooms",
                    iconColorHex = "#FFB300",
                    noiseSuppressionLevel = 0.80f,
                    voiceClarity = 0.75f,
                    voiceFocus = 0.90f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 0.5f,
                    presenceDb = 4.2f,
                    airDb = 1.0f,
                    isBuiltIn = true
                ),
                CustomPresetEntity(
                    name = "Fan & AC Suppression",
                    description = "Deep Wiener spectral subtraction targeting constant drone and HVAC rumble",
                    iconColorHex = "#7C4DFF",
                    noiseSuppressionLevel = 0.95f,
                    voiceClarity = 0.75f,
                    voiceFocus = 0.85f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 1.0f,
                    presenceDb = 5.0f,
                    airDb = 1.5f,
                    isBuiltIn = true
                ),
                CustomPresetEntity(
                    name = "Traffic & Street",
                    description = "Multi-band noise suppression with soft noise gate for outdoor environments",
                    iconColorHex = "#FF5252",
                    noiseSuppressionLevel = 1.00f,
                    voiceClarity = 0.70f,
                    voiceFocus = 0.95f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = false,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 0.0f,
                    presenceDb = 5.5f,
                    airDb = 0.5f,
                    isBuiltIn = true
                ),
                CustomPresetEntity(
                    name = "Natural Voice",
                    description = "Transparent high-fidelity pass-through with gentle noise floor cleaning",
                    iconColorHex = "#00B0FF",
                    noiseSuppressionLevel = 0.45f,
                    voiceClarity = 0.70f,
                    voiceFocus = 0.40f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = false,
                    backgroundNoiseRemovalEnabled = true,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    lowRumbleCut = true,
                    warmthDb = 1.5f,
                    presenceDb = 2.0f,
                    airDb = 2.0f,
                    isBuiltIn = true
                )
            )

            for (preset in defaults) {
                dao.insertPreset(preset)
            }
        }
    }
}
