package com.example.settings

import android.content.Context
import com.example.localization.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("voiceclear_settings", Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow: StateFlow<ProcessingSettings> = _settingsFlow.asStateFlow()

    private val _languageFlow = MutableStateFlow(loadLanguage())
    val languageFlow: StateFlow<AppLanguage> = _languageFlow.asStateFlow()

    private fun loadLanguage(): AppLanguage {
        val code = prefs.getString("app_language", AppLanguage.ARABIC.code) ?: AppLanguage.ARABIC.code
        return AppLanguage.fromCode(code)
    }

    fun setAppLanguage(language: AppLanguage) {
        prefs.edit().putString("app_language", language.code).apply()
        _languageFlow.value = language
    }

    private fun loadSettings(): ProcessingSettings {
        val presetName = prefs.getString("preset", PresetType.GAMING.name) ?: PresetType.GAMING.name
        val preset = runCatching { PresetType.valueOf(presetName) }.getOrDefault(PresetType.GAMING)

        return ProcessingSettings(
            noiseSuppressionLevel = prefs.getFloat("noise_suppression", 0.85f),
            voiceClarity = prefs.getFloat("voice_clarity", 0.75f),
            echoCancellationEnabled = prefs.getBoolean("echo_cancellation", true),
            automaticGainControlEnabled = prefs.getBoolean("agc", true),
            backgroundNoiseRemovalEnabled = prefs.getBoolean("bg_noise", true),
            voiceFocus = prefs.getFloat("voice_focus", 0.80f),
            lowLatencyMode = prefs.getBoolean("low_latency", true),
            sampleRate = prefs.getInt("sample_rate", 48000),
            activePreset = preset,
            customPresetId = if (prefs.contains("custom_preset_id")) prefs.getLong("custom_preset_id", 0L) else null,
            customPresetName = prefs.getString("custom_preset_name", null),
            aiEnhancementEnabled = prefs.getBoolean("ai_enhancement", true),
            aiModelStrength = prefs.getFloat("ai_model_strength", 0.85f),
            inputGainDb = prefs.getFloat("input_gain_db", 0.0f),
            outputGainDb = prefs.getFloat("output_gain_db", 0.0f),
            vadSensitivity = prefs.getFloat("vad_sensitivity", 0.50f),
            limiterThresholdDb = prefs.getFloat("limiter_threshold_db", -0.5f),
            lowRumbleCut = prefs.getBoolean("low_rumble_cut", true),
            warmthDb = prefs.getFloat("warmth_db", 1.8f),
            presenceDb = prefs.getFloat("presence_db", 4.5f),
            airDb = prefs.getFloat("air_db", 2.0f),
            isMonitoringActive = prefs.getBoolean("is_monitoring_active", false),
            monitoringVolume = prefs.getFloat("monitoring_volume", 1.0f),
            isFeedbackProtectionOverridden = prefs.getBoolean("feedback_overridden", false)
        )
    }

    fun updateSettings(newSettings: ProcessingSettings) {
        val editor = prefs.edit()
            .putFloat("noise_suppression", newSettings.noiseSuppressionLevel)
            .putFloat("voice_clarity", newSettings.voiceClarity)
            .putBoolean("echo_cancellation", newSettings.echoCancellationEnabled)
            .putBoolean("agc", newSettings.automaticGainControlEnabled)
            .putBoolean("bg_noise", newSettings.backgroundNoiseRemovalEnabled)
            .putFloat("voice_focus", newSettings.voiceFocus)
            .putBoolean("low_latency", newSettings.lowLatencyMode)
            .putInt("sample_rate", newSettings.sampleRate)
            .putString("preset", newSettings.activePreset.name)
            .putBoolean("ai_enhancement", newSettings.aiEnhancementEnabled)
            .putFloat("ai_model_strength", newSettings.aiModelStrength)
            .putFloat("input_gain_db", newSettings.inputGainDb)
            .putFloat("output_gain_db", newSettings.outputGainDb)
            .putFloat("vad_sensitivity", newSettings.vadSensitivity)
            .putFloat("limiter_threshold_db", newSettings.limiterThresholdDb)
            .putBoolean("low_rumble_cut", newSettings.lowRumbleCut)
            .putFloat("warmth_db", newSettings.warmthDb)
            .putFloat("presence_db", newSettings.presenceDb)
            .putFloat("air_db", newSettings.airDb)
            .putBoolean("is_monitoring_active", newSettings.isMonitoringActive)
            .putFloat("monitoring_volume", newSettings.monitoringVolume)
            .putBoolean("feedback_overridden", newSettings.isFeedbackProtectionOverridden)

        if (newSettings.customPresetId != null) {
            editor.putLong("custom_preset_id", newSettings.customPresetId)
        } else {
            editor.remove("custom_preset_id")
            editor.remove("custom_preset_name")
        }

        editor.apply()
        _settingsFlow.value = newSettings
    }

    fun applyPreset(preset: PresetType) {
        val newSettings = ProcessingSettings.forPreset(preset)
        updateSettings(newSettings)
    }
}
