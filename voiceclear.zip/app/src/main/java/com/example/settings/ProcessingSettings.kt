package com.example.settings

data class ProcessingSettings(
    val noiseSuppressionLevel: Float = 0.80f,      // 0.0 to 1.0 (0% - 100%)
    val voiceClarity: Float = 0.75f,               // 0.0 to 1.0 (0% - 100%)
    val echoCancellationEnabled: Boolean = true,    // ON / OFF
    val automaticGainControlEnabled: Boolean = true,// ON / OFF
    val backgroundNoiseRemovalEnabled: Boolean = true, // ON / OFF
    val voiceFocus: Float = 0.70f,                 // 0.0 to 1.0 (0% - 100%)
    val lowLatencyMode: Boolean = true,            // ON / OFF
    val sampleRate: Int = 48000,                   // 16000 or 48000 Hz
    val activePreset: PresetType = PresetType.GAMING,
    val customPresetId: Long? = null,
    val customPresetName: String? = null,
    // AI Neural Model Settings
    val aiEnhancementEnabled: Boolean = true,      // On-Device RNNoise neural speech enhancement
    val aiModelStrength: Float = 0.85f,            // 0.0 to 1.0
    // Gain & Dynamics
    val inputGainDb: Float = 0.0f,                 // -12.0dB to +18.0dB pre-amp input gain
    val outputGainDb: Float = 0.0f,                // -12.0dB to +18.0dB master output gain
    val vadSensitivity: Float = 0.50f,             // 0.0 to 1.0 VAD threshold
    val limiterThresholdDb: Float = -0.5f,         // -6.0dB to 0.0dB peak limiter ceiling
    // 4-Band Parametric Equalizer
    val lowRumbleCut: Boolean = true,              // 80Hz Butterworth High-Pass
    val warmthDb: Float = 1.8f,                    // -6.0dB to +6.0dB @ 220Hz
    val presenceDb: Float = 4.5f,                  // -6.0dB to +9.0dB @ 2800Hz
    val airDb: Float = 2.0f,                       // -6.0dB to +6.0dB @ 8000Hz
    // Sidetone / Monitoring Settings
    val isMonitoringActive: Boolean = false,
    val monitoringVolume: Float = 1.0f,            // 0.0 to 1.0
    val isFeedbackProtectionOverridden: Boolean = false
) {
    companion object {
        fun forPreset(preset: PresetType): ProcessingSettings {
            return when (preset) {
                PresetType.GAMING -> ProcessingSettings(
                    noiseSuppressionLevel = 0.85f,
                    voiceClarity = 0.75f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 0.80f,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    aiEnhancementEnabled = true,
                    aiModelStrength = 0.85f,
                    inputGainDb = 2.0f,
                    outputGainDb = 0.0f,
                    vadSensitivity = 0.55f,
                    lowRumbleCut = true,
                    warmthDb = 1.2f,
                    presenceDb = 4.8f,
                    airDb = 2.5f,
                    activePreset = PresetType.GAMING
                )
                PresetType.DISCORD -> ProcessingSettings(
                    noiseSuppressionLevel = 0.80f,
                    voiceClarity = 0.80f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 0.70f,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    aiEnhancementEnabled = true,
                    aiModelStrength = 0.80f,
                    inputGainDb = 0.0f,
                    outputGainDb = 0.0f,
                    vadSensitivity = 0.50f,
                    lowRumbleCut = true,
                    warmthDb = 2.0f,
                    presenceDb = 4.2f,
                    airDb = 2.0f,
                    activePreset = PresetType.DISCORD
                )
                PresetType.CALLS -> ProcessingSettings(
                    noiseSuppressionLevel = 0.75f,
                    voiceClarity = 0.85f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 0.90f,
                    lowLatencyMode = false,
                    sampleRate = 16000,
                    aiEnhancementEnabled = true,
                    aiModelStrength = 0.75f,
                    inputGainDb = 3.0f,
                    outputGainDb = 1.0f,
                    vadSensitivity = 0.60f,
                    lowRumbleCut = true,
                    warmthDb = 0.5f,
                    presenceDb = 5.0f,
                    airDb = 1.0f,
                    activePreset = PresetType.CALLS
                )
                PresetType.STREAMING -> ProcessingSettings(
                    noiseSuppressionLevel = 0.60f,
                    voiceClarity = 0.90f,
                    echoCancellationEnabled = false,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 0.60f,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    aiEnhancementEnabled = true,
                    aiModelStrength = 0.65f,
                    inputGainDb = 0.0f,
                    outputGainDb = 0.0f,
                    vadSensitivity = 0.40f,
                    lowRumbleCut = true,
                    warmthDb = 3.0f,
                    presenceDb = 4.0f,
                    airDb = 3.5f,
                    activePreset = PresetType.STREAMING
                )
                PresetType.MAXIMUM_NOISE_REMOVAL -> ProcessingSettings(
                    noiseSuppressionLevel = 1.00f,
                    voiceClarity = 0.65f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = true,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 1.00f,
                    lowLatencyMode = false,
                    sampleRate = 48000,
                    aiEnhancementEnabled = true,
                    aiModelStrength = 1.00f,
                    inputGainDb = 0.0f,
                    outputGainDb = 0.0f,
                    vadSensitivity = 0.70f,
                    lowRumbleCut = true,
                    warmthDb = 0.0f,
                    presenceDb = 5.5f,
                    airDb = 0.5f,
                    activePreset = PresetType.MAXIMUM_NOISE_REMOVAL
                )
                PresetType.NATURAL_VOICE -> ProcessingSettings(
                    noiseSuppressionLevel = 0.45f,
                    voiceClarity = 0.70f,
                    echoCancellationEnabled = true,
                    automaticGainControlEnabled = false,
                    backgroundNoiseRemovalEnabled = true,
                    voiceFocus = 0.40f,
                    lowLatencyMode = true,
                    sampleRate = 48000,
                    aiEnhancementEnabled = false,
                    aiModelStrength = 0.40f,
                    inputGainDb = 0.0f,
                    outputGainDb = 0.0f,
                    vadSensitivity = 0.35f,
                    lowRumbleCut = true,
                    warmthDb = 1.5f,
                    presenceDb = 2.0f,
                    airDb = 2.0f,
                    activePreset = PresetType.NATURAL_VOICE
                )
                PresetType.CUSTOM -> ProcessingSettings(
                    activePreset = PresetType.CUSTOM
                )
            }
        }
    }
}
