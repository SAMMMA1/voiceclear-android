package com.example.settings

enum class PresetType(
    val title: String,
    val subtitle: String,
    val description: String,
    val iconName: String
) {
    GAMING(
        title = "Gaming",
        subtitle = "Zero Fan & Keyboard Clicks",
        description = "Eliminates loud mechanical switches, mouse clicks, and PC cooling fan roar while keeping in-game team comms loud and clear.",
        iconName = "sports_esports"
    ),
    DISCORD(
        title = "Discord",
        subtitle = "Clear Chat & Warmth",
        description = "Optimized for Discord voice channels with aggressive noise gate, keyboard suppression, and warm voice EQ.",
        iconName = "forum"
    ),
    CALLS(
        title = "Calls",
        subtitle = "Maximum Intelligibility",
        description = "Boosts speech presence frequencies and cuts background hums for crystal-clear phone, Zoom, and Meet conferences.",
        iconName = "call"
    ),
    STREAMING(
        title = "Streaming",
        subtitle = "Broadcast Studio Quality",
        description = "Studio-grade vocal balance, gentle noise gating, dynamic compressor, and natural vocal timbre for live broadcasting.",
        iconName = "podcasts"
    ),
    MAXIMUM_NOISE_REMOVAL(
        title = "Max Removal",
        subtitle = "Extreme Noise Environments",
        description = "Maximum aggressive spectral subtraction for street traffic, construction, cafe clamor, and heavy air conditioning.",
        iconName = "shield"
    ),
    NATURAL_VOICE(
        title = "Natural Voice",
        subtitle = "Subtle & Transparent",
        description = "Gentle de-noising preserving every nuance and dynamic expression of the speaker's natural timbre without robotic artifacts.",
        iconName = "eco"
    ),
    CUSTOM(
        title = "Custom",
        subtitle = "User Configured",
        description = "User-customized DSP and AI voice enhancement parameters.",
        iconName = "tune"
    )
}
