package com.example.settings

enum class PresetType(
    val title: String,
    val subtitle: String,
    val description: String,
    val iconName: String
) {
    CLEAN_VOICE(
        title = "Clean Voice",
        subtitle = "Natural & Crystal Clear",
        description = "Transparent high-fidelity noise floor cleaning with natural vocal timbre preservation.",
        iconName = "mic"
    ),
    INDOOR(
        title = "Indoor",
        subtitle = "Fan & HVAC Suppression",
        description = "Suppresses air conditioning hum, ceiling fans, computer cooling, and subtle room reverb.",
        iconName = "home"
    ),
    CAR(
        title = "Car",
        subtitle = "Engine & Road Rumble",
        description = "Deep low-frequency spectral subtraction canceling road rumble, tire noise, and engine drone.",
        iconName = "directions_car"
    ),
    STREET(
        title = "Street",
        subtitle = "Traffic & Urban Bustle",
        description = "Aggressive multi-band filtering targeting passing vehicles, distant horns, wind, and city noise.",
        iconName = "location_city"
    ),
    PODCAST(
        title = "Podcast",
        subtitle = "Broadcast Studio EQ",
        description = "Warm vocal body, smooth compressor leveling, presence boost, and transparent noise floor.",
        iconName = "podcasts"
    ),
    GAMING(
        title = "Gaming",
        subtitle = "Key Clicks & Fan Roar",
        description = "Eliminates loud mechanical switches, mouse clicks, and PC cooling fan roar with zero latency.",
        iconName = "sports_esports"
    ),
    CALL(
        title = "Call",
        subtitle = "Maximum Intelligibility",
        description = "Boosts speech presence frequencies, cuts background hums, and applies AGC for conference calls.",
        iconName = "call"
    ),
    MAXIMUM_ISOLATION(
        title = "Max Isolation",
        subtitle = "Extreme Noise Removal",
        description = "Maximum aggressive spectral subtraction and Wiener filtering for high noise environments.",
        iconName = "shield"
    ),
    CUSTOM(
        title = "Custom",
        subtitle = "User Configured",
        description = "User-customized STFT spectral filtering and DSP voice enhancement parameters.",
        iconName = "tune"
    )
}

