package com.example.audiorouting

enum class AudioDeviceType {
    WIRED_HEADSET,     // 3.5mm jack or TRRS headset
    USB_HEADSET,       // USB Type-C DAC / Headset
    BLUETOOTH_HEADSET, // Bluetooth TWS / Headset (A2DP / SCO)
    BUILTIN_SPEAKER,   // External phone loudspeaker (requires howl protection)
    BUILTIN_EARPIECE,  // Phone earpiece speaker
    UNKNOWN
}
