package com.example.audiorouting

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages audio input and output device detection, headphones plugging events,
 * and feedback/howl protection safety evaluation.
 */
class AudioDeviceManager(private val context: Context) {
    private val TAG = "AudioDeviceManager"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _deviceState = MutableStateFlow(AudioDeviceInfoState())
    val deviceState: StateFlow<AudioDeviceInfoState> = _deviceState.asStateFlow()

    private var audioDeviceCallback: AudioDeviceCallback? = null
    private var headsetReceiver: BroadcastReceiver? = null

    init {
        updateActiveDevices()
        registerDeviceCallbacks()
    }

    private fun registerDeviceCallbacks() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioDeviceCallback = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                    updateActiveDevices()
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                    updateActiveDevices()
                }
            }
            audioManager.registerAudioDeviceCallback(audioDeviceCallback, null)
        }

        headsetReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_HEADSET_PLUG,
                    AudioManager.ACTION_AUDIO_BECOMING_NOISY,
                    "android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED" -> {
                        updateActiveDevices()
                    }
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            addAction("android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED")
        }
        context.registerReceiver(headsetReceiver, filter)
    }

    fun updateActiveDevices() {
        try {
            var detectedType = AudioDeviceType.BUILTIN_SPEAKER
            var outName = "Built-in Speaker"
            var inName = "Built-in Microphone"
            var isHeadphones = false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Check Outputs
                val outDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                for (dev in outDevices) {
                    when (dev.type) {
                        AudioDeviceInfo.TYPE_WIRED_HEADSET,
                        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> {
                            detectedType = AudioDeviceType.WIRED_HEADSET
                            outName = dev.productName.toString().ifEmpty { "Wired Headset" }
                            isHeadphones = true
                            break
                        }
                        AudioDeviceInfo.TYPE_USB_HEADSET,
                        AudioDeviceInfo.TYPE_USB_DEVICE,
                        AudioDeviceInfo.TYPE_USB_ACCESSORY -> {
                            detectedType = AudioDeviceType.USB_HEADSET
                            outName = dev.productName.toString().ifEmpty { "USB-C Audio Device" }
                            isHeadphones = true
                            break
                        }
                        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                        AudioDeviceInfo.TYPE_BLE_HEADSET,
                        AudioDeviceInfo.TYPE_HEARING_AID -> {
                            detectedType = AudioDeviceType.BLUETOOTH_HEADSET
                            outName = dev.productName.toString().ifEmpty { "Bluetooth Headset (TWS)" }
                            isHeadphones = true
                            break
                        }
                        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> {
                            if (detectedType == AudioDeviceType.BUILTIN_SPEAKER) {
                                detectedType = AudioDeviceType.BUILTIN_EARPIECE
                                outName = "Phone Earpiece"
                            }
                        }
                        else -> {}
                    }
                }

                // Check Inputs
                val inDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
                for (dev in inDevices) {
                    when (dev.type) {
                        AudioDeviceInfo.TYPE_WIRED_HEADSET -> {
                            inName = dev.productName.toString().ifEmpty { "Wired Headset Mic" }
                            break
                        }
                        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> {
                            inName = dev.productName.toString().ifEmpty { "Bluetooth Mic (SCO)" }
                            break
                        }
                        AudioDeviceInfo.TYPE_USB_HEADSET,
                        AudioDeviceInfo.TYPE_USB_DEVICE -> {
                            inName = dev.productName.toString().ifEmpty { "USB External Mic" }
                            break
                        }
                        AudioDeviceInfo.TYPE_BUILTIN_MIC -> {
                            inName = "Built-in Mic Array"
                        }
                        else -> {}
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                if (audioManager.isWiredHeadsetOn) {
                    detectedType = AudioDeviceType.WIRED_HEADSET
                    outName = "Wired Headset"
                    inName = "Wired Headset Mic"
                    isHeadphones = true
                } else if (audioManager.isBluetoothA2dpOn || audioManager.isBluetoothScoOn) {
                    detectedType = AudioDeviceType.BLUETOOTH_HEADSET
                    outName = "Bluetooth Headset"
                    inName = "Bluetooth Headset Mic"
                    isHeadphones = true
                }
            }

            val isSafe = isHeadphones || detectedType == AudioDeviceType.BUILTIN_EARPIECE

            _deviceState.value = AudioDeviceInfoState(
                deviceType = detectedType,
                deviceName = outName,
                inputDeviceName = inName,
                outputDeviceName = outName,
                isHeadphonesConnected = isHeadphones,
                isSafeForMonitoring = isSafe,
                isBluetoothScoActive = audioManager.isBluetoothScoOn
            )
            Log.d(TAG, "Active audio devices: IN='$inName', OUT='$outName' (safe: $isSafe)")
        } catch (e: Exception) {
            Log.w(TAG, "Failed inspecting audio devices", e)
        }
    }

    fun release() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback != null) {
                audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
                audioDeviceCallback = null
            }
            headsetReceiver?.let {
                context.unregisterReceiver(it)
                headsetReceiver = null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering audio device manager callbacks", e)
        }
    }
}
