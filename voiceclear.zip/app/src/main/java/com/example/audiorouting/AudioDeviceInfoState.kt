package com.example.audiorouting

data class AudioDeviceInfoState(
    val deviceType: AudioDeviceType = AudioDeviceType.BUILTIN_SPEAKER,
    val deviceName: String = "Built-in Speaker",
    val inputDeviceName: String = "Built-in Microphone",
    val outputDeviceName: String = "Built-in Speaker",
    val isHeadphonesConnected: Boolean = false,
    val isSafeForMonitoring: Boolean = false,
    val isBluetoothScoActive: Boolean = false
)
