package com.example.localization

enum class AppLanguage(
    val code: String,
    val titleEn: String,
    val titleAr: String,
    val nativeName: String
) {
    ARABIC(
        code = "ar",
        titleEn = "Arabic",
        titleAr = "العربية",
        nativeName = "العربية"
    ),
    ENGLISH(
        code = "en",
        titleEn = "English",
        titleAr = "الإنجليزية",
        nativeName = "English"
    );

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: ARABIC
        }
    }
}
