package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.LocalAppLanguage
import com.example.localization.LocalAppStrings
import com.example.ui.VoiceClearViewModel
import com.example.ui.components.AndroidMicrophoneRealityDialog
import com.example.ui.components.AudioFeedbackWarningDialog
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class AppScreen {
    HOME,
    TEST_MIC,
    RECORDINGS,
    CUSTOM_PRESETS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    private val viewModel: VoiceClearViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
            val appStrings = remember(appLanguage) { AppStrings.get(appLanguage) }
            val layoutDirection = if (appLanguage == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(
                LocalAppLanguage provides appLanguage,
                LocalAppStrings provides appStrings,
                LocalLayoutDirection provides layoutDirection
            ) {
                VoiceClearTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        VoiceClearApp(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceClearApp(viewModel: VoiceClearViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    val isEnhancing by viewModel.isEnhancing.collectAsStateWithLifecycle()
    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val settings by viewModel.settingsFlow.collectAsStateWithLifecycle()
    val auditionMode by viewModel.auditionMode.collectAsStateWithLifecycle()
    val allPresets by viewModel.allPresets.collectAsStateWithLifecycle()
    val allRecordings by viewModel.allRecordings.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val showRealityDialog by viewModel.showRealityDialog.collectAsStateWithLifecycle()
    val showFeedbackWarning by viewModel.showFeedbackWarningDialog.collectAsStateWithLifecycle()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasMicPermission = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (hasMicPermission) {
            viewModel.toggleEnhancement()
        }
    }

    fun requestPermissionsAndToggle() {
        val permissionsToRequest = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        permissionLauncher.launch(permissionsToRequest.toTypedArray())
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = StudioDarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    if (targetState.ordinal > initialState.ordinal) {
                        slideInHorizontally { it } + fadeIn() togetherWith
                                slideOutHorizontally { -it } + fadeOut()
                    } else {
                        slideInHorizontally { -it } + fadeIn() togetherWith
                                slideOutHorizontally { it } + fadeOut()
                    }
                },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    AppScreen.HOME -> HomeScreen(
                        isEnhancing = isEnhancing,
                        metrics = metrics,
                        settings = settings,
                        recordingsCount = allRecordings.size,
                        onToggleEnhancement = {
                            if (hasMicPermission) {
                                viewModel.toggleEnhancement()
                            } else {
                                requestPermissionsAndToggle()
                            }
                        },
                        onToggleMonitoring = { viewModel.toggleMonitoring() },
                        onToggleRecording = {
                            if (hasMicPermission) {
                                viewModel.toggleRecording()
                            } else {
                                requestPermissionsAndToggle()
                            }
                        },
                        onSelectPreset = { viewModel.applyPreset(it) },
                        onOpenTestScreen = { currentScreen = AppScreen.TEST_MIC },
                        onOpenRecordingsScreen = { currentScreen = AppScreen.RECORDINGS },
                        onOpenPresetsScreen = { currentScreen = AppScreen.CUSTOM_PRESETS },
                        onOpenSettingsScreen = { currentScreen = AppScreen.SETTINGS },
                        onOpenRealityInfo = { viewModel.setShowRealityDialog(true) },
                        onToggleLanguage = { viewModel.toggleAppLanguage() }
                    )

                    AppScreen.TEST_MIC -> TestMicrophoneScreen(
                        isEnhancing = isEnhancing,
                        metrics = metrics,
                        settings = settings,
                        auditionMode = auditionMode,
                        onBack = { currentScreen = AppScreen.HOME },
                        onToggleEnhancement = {
                            if (hasMicPermission) {
                                viewModel.toggleEnhancement()
                            } else {
                                requestPermissionsAndToggle()
                            }
                        },
                        onToggleMonitoring = { viewModel.toggleMonitoring() },
                        onSetMonitoringVolume = { viewModel.setMonitoringVolume(it) },
                        onSetAuditionMode = { viewModel.setAuditionMode(it) }
                    )

                    AppScreen.RECORDINGS -> RecordingsScreen(
                        recordings = allRecordings,
                        playbackState = playbackState,
                        onBack = { currentScreen = AppScreen.HOME },
                        onPlay = { viewModel.playRecording(it) },
                        onToggleAuditionTrack = { viewModel.toggleAuditionPlaybackTrack(it) },
                        onPause = { viewModel.pauseRecording() },
                        onSeek = { viewModel.seekRecording(it) },
                        onDelete = { viewModel.deleteRecording(it) },
                        onShare = { viewModel.shareRecording(it) }
                    )

                    AppScreen.CUSTOM_PRESETS -> CustomPresetsScreen(
                        presets = allPresets,
                        currentSettings = settings,
                        onBack = { currentScreen = AppScreen.HOME },
                        onApplyPreset = { viewModel.applyCustomPreset(it) },
                        onSaveNewPreset = { name, desc, colorHex ->
                            viewModel.saveCurrentAsCustomPreset(name, desc, colorHex)
                        },
                        onDeletePreset = { viewModel.deleteCustomPreset(it) }
                    )

                    AppScreen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        onBack = { currentScreen = AppScreen.HOME },
                        onSelectPreset = { viewModel.applyPreset(it) },
                        onOpenPresetsManager = { currentScreen = AppScreen.CUSTOM_PRESETS },
                        onToggleAiEnhancement = { viewModel.toggleAiEnhancement() },
                        onAiModelStrengthChange = { viewModel.setAiModelStrength(it) },
                        onInputGainDbChange = { viewModel.setInputGainDb(it) },
                        onOutputGainDbChange = { viewModel.setOutputGainDb(it) },
                        onVadSensitivityChange = { viewModel.setVadSensitivity(it) },
                        onLimiterThresholdDbChange = { viewModel.setLimiterThresholdDb(it) },
                        onNoiseSuppressionChange = { viewModel.setNoiseSuppression(it) },
                        onVoiceClarityChange = { viewModel.setVoiceClarity(it) },
                        onVoiceFocusChange = { viewModel.setVoiceFocus(it) },
                        onLowRumbleCutChange = { viewModel.setLowRumbleCut(it) },
                        onWarmthDbChange = { viewModel.setWarmthDb(it) },
                        onPresenceDbChange = { viewModel.setPresenceDb(it) },
                        onAirDbChange = { viewModel.setAirDb(it) },
                        onToggleEchoCancellation = { viewModel.toggleEchoCancellation() },
                        onToggleAgc = { viewModel.toggleAgc() },
                        onToggleBackgroundNoiseRemoval = { viewModel.toggleBackgroundNoiseRemoval() },
                        onToggleLowLatency = { viewModel.toggleLowLatency() },
                        onSelectSampleRate = { viewModel.setSampleRate(it) },
                        onOpenRealityInfo = { viewModel.setShowRealityDialog(true) },
                        onSelectLanguage = { viewModel.setAppLanguage(it) }
                    )
                }
            }

            // Acoustic Feedback Protection Modal Dialog
            if (showFeedbackWarning) {
                AudioFeedbackWarningDialog(
                    onDismiss = { viewModel.dismissFeedbackWarning() },
                    onOverride = { viewModel.overrideFeedbackWarningAndEnableMonitoring() }
                )
            }

            // Android Audio Architecture BottomSheet Dialog
            if (showRealityDialog) {
                AndroidMicrophoneRealityDialog(
                    onDismiss = { viewModel.setShowRealityDialog(false) }
                )
            }
        }
    }
}
