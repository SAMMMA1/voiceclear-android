package com.example.audioengine

import com.example.echocancellation.EchoCancelerDsp
import com.example.noisesuppression.NoiseSuppressorDsp
import com.example.settings.ProcessingSettings
import com.example.voiceenhancement.VoiceEnhancerDsp
import kotlin.math.*

/**
 * Audio DSP Pipeline coordinator.
 * Chains Noise Suppression -> Echo Cancellation -> Voice Enhancement / AGC / Limiter -> Spectral Analysis.
 */
class AudioPipeline(sampleRate: Int = 48000) {

    val noiseSuppressor = NoiseSuppressorDsp(sampleRate)
    val voiceEnhancer = VoiceEnhancerDsp(sampleRate)
    val echoCanceler = EchoCancelerDsp()

    private val waveformBuffer = FloatArray(48)
    private val spectrumBuffer = FloatArray(16)

    fun setSampleRate(sampleRate: Int) {
        noiseSuppressor.setSampleRate(sampleRate)
        voiceEnhancer.setSampleRate(sampleRate)
    }

    fun reset() {
        noiseSuppressor.reset()
        voiceEnhancer.reset()
    }

    /**
     * Process an audio frame through the full DSP pipeline.
     * @param rawBuffer Original mic samples (remains unmodified as reference)
     * @param workBuffer Working buffer modified in-place
     * @param length Number of samples in frame
     * @param settings Active settings
     */
    fun process(
        rawBuffer: ShortArray,
        workBuffer: ShortArray,
        length: Int,
        settings: ProcessingSettings
    ): ProcessResult {
        // Copy raw to work
        System.arraycopy(rawBuffer, 0, workBuffer, 0, length)

        // 1. Noise Suppression Stage (High-pass + RNNoise Neural Model / Spectral Subtraction + Transient Dampener)
        val vadProbability = noiseSuppressor.processFrame(workBuffer, length, settings)

        // 2. Feedback & Echo Suppression Stage
        echoCanceler.processFeedbackSuppression(workBuffer, length, settings.echoCancellationEnabled)

        // 3. Voice Enhancement Stage (Presence boost + Warmth EQ + Voice Focus + AGC + Limiter)
        voiceEnhancer.processFrame(workBuffer, length, vadProbability, settings)

        // 4. Calculate real-time metrics & Clipping detection
        var rawSumSq = 0.0
        var enhSumSq = 0.0
        var hasClipped = false

        for (i in 0 until length) {
            val r = rawBuffer[i] / 32768.0
            val e = workBuffer[i] / 32768.0
            rawSumSq += r * r
            enhSumSq += e * e
            if (rawBuffer[i] >= 32760 || rawBuffer[i] <= -32760 || workBuffer[i] >= 32760 || workBuffer[i] <= -32760) {
                hasClipped = true
            }
        }
        val rawRms = sqrt(rawSumSq / length).toFloat()
        val enhRms = sqrt(enhSumSq / length).toFloat()

        val micDbFs = (20 * log10(rawRms.coerceAtLeast(0.00001f))).coerceIn(-60f, 0f)
        val enhDbFs = (20 * log10(enhRms.coerceAtLeast(0.00001f))).coerceIn(-60f, 0f)
        val noiseDb = noiseSuppressor.currentNoiseLevelDb
        val snrImprovement = max(0f, (enhDbFs - noiseDb) - (micDbFs - noiseDb))

        // 5. Downsample waveform for visualizer (48 points)
        val step = max(1, length / waveformBuffer.size)
        for (i in waveformBuffer.indices) {
            val idx = (i * step).coerceAtMost(length - 1)
            waveformBuffer[i] = (workBuffer[idx] / 32768.0f).coerceIn(-1f, 1f)
        }

        // 6. Compute 16-band spectrum energy for animated equalizer
        val bandStep = max(1, length / spectrumBuffer.size)
        for (b in spectrumBuffer.indices) {
            val start = b * bandStep
            val end = min(start + bandStep, length)
            var bandSum = 0f
            for (j in start until end) {
                val s = abs(workBuffer[j] / 32768.0f)
                bandSum += s
            }
            val avg = bandSum / (end - start).coerceAtLeast(1)
            // Smooth spectrum decay
            spectrumBuffer[b] = 0.6f * spectrumBuffer[b] + 0.4f * (avg * 2.5f).coerceIn(0f, 1f)
        }

        var activeCount = 0
        if (settings.aiEnhancementEnabled) activeCount += 1
        if (settings.backgroundNoiseRemovalEnabled) activeCount += 2
        if (settings.echoCancellationEnabled) activeCount += 1
        if (settings.automaticGainControlEnabled) activeCount += 1
        if (settings.voiceClarity > 0.1f) activeCount += 1
        if (settings.voiceFocus > 0.1f) activeCount += 1

        return ProcessResult(
            rawRms = rawRms,
            enhRms = enhRms,
            micDbFs = micDbFs,
            enhDbFs = enhDbFs,
            noiseDb = noiseDb,
            voiceLevel = vadProbability,
            isVoiceActive = vadProbability > 0.35f,
            isClipping = hasClipped,
            snrImprovementDb = snrImprovement,
            activeFiltersCount = activeCount,
            waveform = waveformBuffer.clone(),
            spectrum = spectrumBuffer.clone()
        )
    }
}

data class ProcessResult(
    val rawRms: Float,
    val enhRms: Float,
    val micDbFs: Float,
    val enhDbFs: Float,
    val noiseDb: Float,
    val voiceLevel: Float,
    val isVoiceActive: Boolean,
    val isClipping: Boolean,
    val snrImprovementDb: Float,
    val activeFiltersCount: Int,
    val waveform: FloatArray,
    val spectrum: FloatArray
)
