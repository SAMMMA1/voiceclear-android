package com.example.audioengine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import android.util.Log
import com.example.audiorecording.AudioRecorderEngine
import com.example.audiorecording.RecordingState
import com.example.audiorouting.AudioDeviceManager
import com.example.audiooutput.AudioOutputManager
import com.example.audiooutput.AuditionMode
import com.example.settings.ProcessingSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-performance streaming Audio Engine.
 * Runs on dedicated THREAD_PRIORITY_URGENT_AUDIO background thread for minimal latency.
 * Supports real-time DSP, RNNoise neural speech enhancement, live sidetone monitoring,
 * and high-fidelity WAV recording with modular AudioSink architecture.
 */
class AudioEngine(private val context: Context) {
    private val TAG = "AudioEngine"

    private val pipeline = AudioPipeline()
    val outputManager = AudioOutputManager()
    val recorderEngine = AudioRecorderEngine(context)
    val deviceManager = AudioDeviceManager(context)

    // Modular Sinks
    private val sinks = CopyOnWriteArrayList<AudioSink>()

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private val isRunning = AtomicBoolean(false)

    private val _metrics = MutableStateFlow(AudioMetrics())
    val metrics: StateFlow<AudioMetrics> = _metrics.asStateFlow()

    @Volatile
    var currentSettings: ProcessingSettings = ProcessingSettings()
        set(value) {
            field = value
            pipeline.setSampleRate(value.sampleRate)
            pipeline.echoCanceler.setAecEnabled(value.echoCancellationEnabled)
            outputManager.setMonitoringVolume(value.monitoringVolume)
        }

    val recordingState: StateFlow<RecordingState> = recorderEngine.recordingState

    init {
        sinks.add(outputManager)
        sinks.add(recorderEngine)
    }

    fun addSink(sink: AudioSink) {
        if (!sinks.contains(sink)) {
            sinks.add(sink)
        }
    }

    fun removeSink(sink: AudioSink) {
        sinks.remove(sink)
    }

    @SuppressLint("MissingPermission")
    fun start(settings: ProcessingSettings): Boolean {
        if (isRunning.get()) return true
        currentSettings = settings

        val sampleRate = settings.sampleRate
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT

        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(TAG, "Invalid AudioRecord buffer parameters for rate $sampleRate")
            return false
        }

        // Frame size: 10ms for low-latency mode (480 samples at 48kHz, 160 samples at 16kHz)
        val frameSize = if (settings.lowLatencyMode) {
            (sampleRate / 100).coerceAtLeast(160)
        } else {
            (sampleRate / 50).coerceAtLeast(320)
        }
        val recordBufferSize = maxOf(minBufferSize * 2, frameSize * 4)

        try {
            // Try VOICE_COMMUNICATION first for built-in hardware AEC/NS routing, fallback to MIC
            val record = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    recordBufferSize
                )
            } catch (e: Exception) {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    recordBufferSize
                )
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord initialization failed")
                record.release()
                return false
            }

            audioRecord = record
            pipeline.setSampleRate(sampleRate)
            pipeline.reset()

            // Attach hardware AEC / Noise Suppressor
            val audioSessionId = record.audioSessionId
            pipeline.echoCanceler.attachToSession(
                audioSessionId = audioSessionId,
                enableAec = settings.echoCancellationEnabled,
                enableNs = settings.backgroundNoiseRemovalEnabled
            )

            // Start AudioRecord
            record.startRecording()
            isRunning.set(true)

            // Start audio monitor output (Sidetone)
            outputManager.setMonitoringVolume(settings.monitoringVolume)
            outputManager.setMonitoringEnabled(settings.isMonitoringActive, sampleRate, settings.lowLatencyMode)

            // Start dedicated real-time processing thread
            startProcessingLoop(record, frameSize, sampleRate)
            Log.i(TAG, "VoiceClear Audio Engine started successfully @ $sampleRate Hz (frame: $frameSize)")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Fatal error launching audio engine", e)
            stop()
            return false
        }
    }

    private fun startProcessingLoop(record: AudioRecord, frameSize: Int, sampleRate: Int) {
        val rawBuffer = ShortArray(frameSize)
        val workBuffer = ShortArray(frameSize)

        recordingThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)

            var frameCount = 0L
            var lastMetricsEmission = 0L
            var consecutiveErrors = 0

            while (isRunning.get()) {
                val startTime = System.nanoTime()

                // Read real-time audio from microphone
                val readSamples = record.read(rawBuffer, 0, frameSize)
                if (readSamples <= 0) {
                    consecutiveErrors++
                    if (consecutiveErrors > 50) {
                        Log.w(TAG, "Consecutive AudioRecord read failures: $readSamples")
                        try {
                            Thread.sleep(5)
                        } catch (_: Exception) {}
                    }
                    continue
                }
                consecutiveErrors = 0

                // Process through DSP & AI Neural RNNoise pipeline
                val result = pipeline.process(rawBuffer, workBuffer, readSamples, currentSettings)

                // Dispatch to all modular Audio Sinks (Monitoring AudioTrack, WAV Recorder, etc.)
                for (sink in sinks) {
                    try {
                        sink.onAudioFrame(rawBuffer, workBuffer, readSamples, sampleRate)
                    } catch (e: Exception) {
                        Log.w(TAG, "AudioSink frame dispatch error", e)
                    }
                }

                val endTime = System.nanoTime()
                val latencyMs = (endTime - startTime) / 1_000_000.0f
                frameCount++

                // Throttle UI state updates to ~35-40fps to keep UI ultra responsive
                val now = System.currentTimeMillis()
                if (now - lastMetricsEmission >= 26) {
                    lastMetricsEmission = now
                    val devState = deviceManager.deviceState.value
                    val recState = recorderEngine.recordingState.value

                    // Telemetry calculations
                    val runtime = Runtime.getRuntime()
                    val usedRamMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)
                    val framePeriodMs = (frameSize * 1000f / sampleRate)
                    val cpuEst = ((latencyMs / framePeriodMs) * 100f).coerceIn(1.2f, 92.0f)
                    val bitrateKbps = (sampleRate * 16) / 1000

                    _metrics.value = AudioMetrics(
                        isRunning = true,
                        micRms = result.rawRms,
                        enhancedRms = result.enhRms,
                        micDbFs = result.micDbFs,
                        enhancedDbFs = result.enhDbFs,
                        noiseDb = result.noiseDb,
                        voiceLevel = result.voiceLevel,
                        isVoiceActive = result.isVoiceActive,
                        isClipping = result.isClipping,
                        snrImprovementDb = result.snrImprovementDb,
                        latencyMs = latencyMs,
                        sampleRate = sampleRate,
                        bufferSize = frameSize,
                        activeFiltersCount = result.activeFiltersCount,
                        waveformSamples = result.waveform,
                        frequencySpectrum = result.spectrum,
                        isHardwareAecActive = pipeline.echoCanceler.isHardwareAecSupported && currentSettings.echoCancellationEnabled,
                        isHardwareNsActive = pipeline.echoCanceler.isHardwareNsSupported && currentSettings.backgroundNoiseRemovalEnabled,
                        isOutputMonitoring = outputManager.isMonitoringEnabled,
                        monitoringVolume = outputManager.monitoringVolume,
                        isRecording = recState.isRecording,
                        recordingDurationMs = recState.durationMs,
                        recordingFileSize = recState.fileSizeBytes,
                        audioDeviceName = devState.deviceName,
                        inputDeviceName = devState.inputDeviceName,
                        isHeadphonesConnected = devState.isHeadphonesConnected,
                        isFeedbackProtected = !devState.isSafeForMonitoring && !currentSettings.isFeedbackProtectionOverridden,
                        cpuUsagePercent = cpuEst,
                        ramUsageMb = usedRamMb,
                        bitrateKbps = bitrateKbps,
                        totalFramesProcessed = frameCount
                    )
                }
            }
        }, "VoiceClearAudioThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun setAuditionMode(mode: AuditionMode) {
        outputManager.setAuditionMode(mode)
    }

    fun setMonitoringEnabled(enabled: Boolean) {
        outputManager.setMonitoringEnabled(enabled, currentSettings.sampleRate, currentSettings.lowLatencyMode)
    }

    fun setMonitoringVolume(volume: Float) {
        outputManager.setMonitoringVolume(volume)
    }

    fun startRecording(presetName: String = "VoiceClear"): File? {
        return recorderEngine.startRecording(currentSettings.sampleRate, presetName)
    }

    fun stopRecording(): File? {
        return recorderEngine.stopRecording()
    }

    fun stop() {
        if (!isRunning.compareAndSet(true, false)) return

        try {
            audioRecord?.apply {
                if (recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    stop()
                }
                release()
            }
            audioRecord = null

            recordingThread?.join(300)
            recordingThread = null

            recorderEngine.stopRecording()
            outputManager.stop()
            pipeline.echoCanceler.release()
            pipeline.reset()

            _metrics.value = AudioMetrics(isRunning = false)
            Log.i(TAG, "VoiceClear Audio Engine stopped")
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping audio engine", e)
        }
    }
}
