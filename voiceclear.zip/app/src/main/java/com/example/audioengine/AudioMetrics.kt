package com.example.audioengine

data class AudioMetrics(
    val isRunning: Boolean = false,
    val micRms: Float = 0f,
    val enhancedRms: Float = 0f,
    val micDbFs: Float = -60f,
    val enhancedDbFs: Float = -60f,
    val noiseDb: Float = -60f,
    val voiceLevel: Float = 0f,
    val isVoiceActive: Boolean = false,
    val isClipping: Boolean = false,
    val snrImprovementDb: Float = 0f,
    val latencyMs: Float = 0f,
    val sampleRate: Int = 48000,
    val bufferSize: Int = 960,
    val activeFiltersCount: Int = 6,
    val waveformSamples: FloatArray = FloatArray(48),
    val frequencySpectrum: FloatArray = FloatArray(16),
    val isHardwareAecActive: Boolean = false,
    val isHardwareNsActive: Boolean = false,
    val isOutputMonitoring: Boolean = false,
    val monitoringVolume: Float = 1.0f,
    val isRecording: Boolean = false,
    val recordingDurationMs: Long = 0L,
    val recordingFileSize: Long = 0L,
    val audioDeviceName: String = "Built-in Speaker",
    val inputDeviceName: String = "Built-in Microphone",
    val isHeadphonesConnected: Boolean = false,
    val isFeedbackProtected: Boolean = true,
    val cpuUsagePercent: Float = 3.5f,
    val ramUsageMb: Float = 32.0f,
    val bitrateKbps: Int = 768,
    val totalFramesProcessed: Long = 0L
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AudioMetrics
        if (isRunning != other.isRunning) return false
        if (micRms != other.micRms) return false
        if (enhancedRms != other.enhancedRms) return false
        if (micDbFs != other.micDbFs) return false
        if (enhancedDbFs != other.enhancedDbFs) return false
        if (noiseDb != other.noiseDb) return false
        if (voiceLevel != other.voiceLevel) return false
        if (isVoiceActive != other.isVoiceActive) return false
        if (isClipping != other.isClipping) return false
        if (latencyMs != other.latencyMs) return false
        if (isRecording != other.isRecording) return false
        if (recordingDurationMs != other.recordingDurationMs) return false
        if (isOutputMonitoring != other.isOutputMonitoring) return false
        if (totalFramesProcessed != other.totalFramesProcessed) return false
        return true
    }

    override fun hashCode(): Int {
        var result = isRunning.hashCode()
        result = 31 * result + micRms.hashCode()
        result = 31 * result + enhancedRms.hashCode()
        result = 31 * result + micDbFs.hashCode()
        result = 31 * result + isRecording.hashCode()
        result = 31 * result + totalFramesProcessed.hashCode()
        return result
    }
}
