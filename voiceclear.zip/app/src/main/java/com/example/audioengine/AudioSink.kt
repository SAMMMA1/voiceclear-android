package com.example.audioengine

/**
 * Modular Audio Sink interface.
 * Decouples audio processing from audio outputs (Monitoring AudioTrack, WAV Recorder, or future HAL).
 */
interface AudioSink {
    /**
     * Called on the audio processing thread with real-time audio frames.
     * Implementations must not perform blocking I/O or heavy allocations in this method.
     */
    fun onAudioFrame(rawBuffer: ShortArray, enhancedBuffer: ShortArray, length: Int, sampleRate: Int)

    /**
     * Release any underlying resources.
     */
    fun release() {}
}
