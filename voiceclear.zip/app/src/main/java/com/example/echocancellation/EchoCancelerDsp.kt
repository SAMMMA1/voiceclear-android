package com.example.echocancellation

import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlin.math.abs

/**
 * Echo Cancellation & Hardware AudioFx Manager.
 * Attaches system AcousticEchoCanceler and NoiseSuppressor to the AudioRecord session,
 * and maintains software feedback anti-howl suppression.
 */
class EchoCancelerDsp {
    private val TAG = "EchoCancelerDsp"

    private var hardwareAec: AcousticEchoCanceler? = null
    private var hardwareNs: NoiseSuppressor? = null

    var isHardwareAecSupported: Boolean = false
        private set
    var isHardwareNsSupported: Boolean = false
        private set

    init {
        try {
            isHardwareAecSupported = AcousticEchoCanceler.isAvailable()
            isHardwareNsSupported = NoiseSuppressor.isAvailable()
        } catch (t: Throwable) {
            // Graceful fallback for mock/JVM unit test environments where android.media is unmocked
            isHardwareAecSupported = false
            isHardwareNsSupported = false
        }
    }

    /**
     * Attach hardware effects to the active AudioRecord audioSessionId.
     */
    fun attachToSession(audioSessionId: Int, enableAec: Boolean, enableNs: Boolean) {
        release()
        try {
            if (isHardwareAecSupported && enableAec) {
                hardwareAec = AcousticEchoCanceler.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "Hardware AcousticEchoCanceler attached and enabled (session: $audioSessionId)")
                }
            }

            if (isHardwareNsSupported && enableNs) {
                hardwareNs = NoiseSuppressor.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "Hardware NoiseSuppressor attached and enabled (session: $audioSessionId)")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error attaching AudioFx effects to session $audioSessionId", e)
        }
    }

    fun setAecEnabled(enabled: Boolean) {
        hardwareAec?.enabled = enabled
    }

    fun release() {
        try {
            hardwareAec?.release()
            hardwareAec = null
            hardwareNs?.release()
            hardwareNs = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing hardware audio effects", e)
        }
    }

    /**
     * Software Feedback & Loopback Echo Protection for live monitoring.
     * Prevents runaway screaming resonance and speaker-to-mic howl.
     */
    fun processFeedbackSuppression(buffer: ShortArray, length: Int, aecEnabled: Boolean) {
        if (!aecEnabled || length <= 0) return

        // Anti-howling slew limiter on high correlation runs
        var consecLarge = 0
        val howlThreshold = 28000
        for (i in 0 until length) {
            if (abs(buffer[i].toInt()) > howlThreshold) {
                consecLarge++
                if (consecLarge > 12) {
                    // Suppress persistent feedback oscillation
                    buffer[i] = (buffer[i] * 0.4f).toInt().toShort()
                }
            } else {
                consecLarge = 0
            }
        }
    }
}
