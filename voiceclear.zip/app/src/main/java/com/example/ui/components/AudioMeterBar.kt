package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun AudioMeterBar(
    title: String,
    levelFraction: Float, // 0.0 to 1.0
    dbValue: Float,       // -60dB to 0dB
    colorType: MeterColorType = MeterColorType.CYAN,
    tag: String = "meter_bar",
    modifier: Modifier = Modifier
) {
    val animatedLevel by animateFloatAsState(
        targetValue = levelFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 80),
        label = "meter_anim"
    )

    val gradientColors = when (colorType) {
        MeterColorType.CYAN -> listOf(NeonCyan.copy(alpha = 0.5f), NeonCyan)
        MeterColorType.EMERALD -> listOf(NeonEmerald.copy(alpha = 0.5f), NeonEmerald)
        MeterColorType.AMBER -> listOf(NeonAmber.copy(alpha = 0.6f), NeonAmber)
        MeterColorType.VIOLET -> listOf(NeonViolet.copy(alpha = 0.6f), NeonViolet)
        MeterColorType.FULL_SPECTRUM -> listOf(MeterGreen, MeterYellow, MeterRed)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            )
            Text(
                text = String.format("%.1f dB", dbValue),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (dbValue > -10f) NeonCoral else TextSecondary,
                    fontSize = 11.sp
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Meter Track
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(MeterInactive)
        ) {
            // Filled Segment
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedLevel.coerceAtLeast(0.01f))
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        Brush.horizontalGradient(colors = gradientColors)
                    )
            )
        }
    }
}

enum class MeterColorType {
    CYAN,
    EMERALD,
    AMBER,
    VIOLET,
    FULL_SPECTRUM
}
