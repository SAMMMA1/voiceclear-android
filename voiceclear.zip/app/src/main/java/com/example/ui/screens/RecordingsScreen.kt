package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audiorecording.PlaybackState
import com.example.database.AudioRecordingEntity
import com.example.localization.LocalAppStrings
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingsScreen(
    recordings: List<AudioRecordingEntity>,
    playbackState: PlaybackState,
    onBack: () -> Unit,
    onPlay: (AudioRecordingEntity) -> Unit,
    onToggleAuditionTrack: (AudioRecordingEntity) -> Unit,
    onPause: () -> Unit,
    onSeek: (Float) -> Unit,
    onDelete: (AudioRecordingEntity) -> Unit,
    onShare: (AudioRecordingEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.recordingsScreenTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_recordings")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.back,
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBg)
            )
        },
        containerColor = StudioDarkBg
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            // Header stats banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = strings.savedAudioFiles,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "${recordings.size} ${strings.losslessWavRecorded}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Dual WAV A/B",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (recordings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.MicNone,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = strings.noRecordingsYet,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.noRecordingsDesc,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(recordings, key = { it.id }) { recording ->
                        val isCurrentPlaying = playbackState.currentRecordingId == recording.id ||
                                (playbackState.currentFilePath != null &&
                                        (playbackState.currentFilePath == recording.filePath || playbackState.currentFilePath == recording.rawFilePath))

                        RecordingCard(
                            recording = recording,
                            isPlaying = isCurrentPlaying && playbackState.isPlaying,
                            isPlayingRaw = isCurrentPlaying && playbackState.isPlayingRaw,
                            progressFraction = if (isCurrentPlaying) playbackState.progressFraction else 0f,
                            currentPosMs = if (isCurrentPlaying) playbackState.currentPositionMs else 0,
                            onPlayPause = {
                                if (isCurrentPlaying && playbackState.isPlaying) {
                                    onPause()
                                } else {
                                    onPlay(recording)
                                }
                            },
                            onToggleAudition = { onToggleAuditionTrack(recording) },
                            onSeek = onSeek,
                            onDelete = { onDelete(recording) },
                            onShare = { onShare(recording) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordingCard(
    recording: AudioRecordingEntity,
    isPlaying: Boolean,
    isPlayingRaw: Boolean,
    progressFraction: Float,
    currentPosMs: Int,
    onPlayPause: () -> Unit,
    onToggleAudition: () -> Unit,
    onSeek: (Float) -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    val strings = LocalAppStrings.current
    val dateStr = remember(recording.createdAt) {
        SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault()).format(Date(recording.createdAt))
    }

    val fileSizeStr = remember(recording.fileSizeBytes) {
        val kb = recording.fileSizeBytes / 1024.0
        if (kb > 1024) {
            String.format(Locale.US, "%.1f MB", kb / 1024.0)
        } else {
            String.format(Locale.US, "%.0f KB", kb)
        }
    }

    val durationStr = remember(recording.durationMs) {
        val totalSecs = (recording.durationMs / 1000).toInt()
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    val hasRawTrack = !recording.rawFilePath.isNullOrEmpty()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isPlaying) Color(0xFF10283A) else StudioCardBg)
            .border(
                width = if (isPlaying) 1.5.dp else 1.dp,
                color = if (isPlaying) NeonCyan else StudioCardBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Play/Pause Button
                    IconButton(
                        onClick = onPlayPause,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isPlaying) NeonCoral else NeonCyan)
                            .testTag("btn_play_${recording.id}")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) strings.pause else strings.play,
                            tint = Color(0xFF001F29),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = recording.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "$dateStr • $fileSizeStr",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Preset Tag & Action Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(StudioCardElevated)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = recording.presetUsed,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NeonEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Share button
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("btn_share_${recording.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = strings.share,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Delete button
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("btn_delete_${recording.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = strings.delete,
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Dual Track A/B Selector Chip Row
            if (hasRawTrack) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(StudioCardElevated)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Enhanced Track Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isPlayingRaw) NeonCyan.copy(alpha = 0.25f) else Color.Transparent)
                            .border(
                                width = if (!isPlayingRaw) 1.dp else 0.dp,
                                color = if (!isPlayingRaw) NeonCyan else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                if (isPlayingRaw) onToggleAudition()
                            }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = null,
                                tint = if (!isPlayingRaw) NeonCyan else TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "✨ Cleaned (B)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (!isPlayingRaw) FontWeight.Bold else FontWeight.Normal,
                                    color = if (!isPlayingRaw) NeonCyan else TextMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    // Raw Track Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isPlayingRaw) NeonCoral.copy(alpha = 0.25f) else Color.Transparent)
                            .border(
                                width = if (isPlayingRaw) 1.dp else 0.dp,
                                color = if (isPlayingRaw) NeonCoral else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                if (!isPlayingRaw) onToggleAudition()
                            }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = if (isPlayingRaw) NeonCoral else TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "📢 Original (A)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isPlayingRaw) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isPlayingRaw) NeonCoral else TextMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            // Scrub Bar & Duration Row
            Spacer(modifier = Modifier.height(10.dp))

            Slider(
                value = progressFraction,
                onValueChange = onSeek,
                colors = SliderDefaults.colors(
                    thumbColor = if (isPlayingRaw) NeonCoral else NeonCyan,
                    activeTrackColor = if (isPlayingRaw) NeonCoral else NeonCyan,
                    inactiveTrackColor = MeterInactive
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val currentSecs = (currentPosMs / 1000)
                val curMins = currentSecs / 60
                val curSecs = currentSecs % 60
                val curFormatted = String.format(Locale.US, "%02d:%02d", curMins, curSecs)

                Text(
                    text = curFormatted,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (isPlaying) (if (isPlayingRaw) NeonCoral else NeonCyan) else TextMuted,
                        fontSize = 11.sp
                    )
                )

                Text(
                    text = durationStr,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}
