package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.LocalAppStrings
import com.example.settings.PresetType
import com.example.ui.theme.*

@Composable
fun PresetSelector(
    selectedPreset: PresetType,
    onSelectPreset: (PresetType) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val presets = listOf(
        PresetType.CLEAN_VOICE,
        PresetType.INDOOR,
        PresetType.CAR,
        PresetType.STREET,
        PresetType.PODCAST,
        PresetType.GAMING,
        PresetType.CALL,
        PresetType.MAXIMUM_ISOLATION
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.presetsTitle,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Text(
                text = strings.getPresetInfo(selectedPreset).title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(presets) { preset ->
                val isSelected = preset == selectedPreset
                PresetCard(
                    preset = preset,
                    isSelected = isSelected,
                    onClick = { onSelectPreset(preset) }
                )
            }
        }
    }
}

@Composable
private fun PresetCard(
    preset: PresetType,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val presetInfo = strings.getPresetInfo(preset)
    val icon = when (preset) {
        PresetType.CLEAN_VOICE -> Icons.Default.Mic
        PresetType.INDOOR -> Icons.Default.Home
        PresetType.CAR -> Icons.Default.DirectionsCar
        PresetType.STREET -> Icons.Default.LocationCity
        PresetType.PODCAST -> Icons.Default.Podcasts
        PresetType.GAMING -> Icons.Default.SportsEsports
        PresetType.CALL -> Icons.Default.Call
        PresetType.MAXIMUM_ISOLATION -> Icons.Default.Shield
        PresetType.CUSTOM -> Icons.Default.Tune
    }

    Box(
        modifier = Modifier
            .width(140.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (isSelected) {
                    Brush.verticalGradient(
                        listOf(StudioCardElevated, Color(0xFF132A38))
                    )
                } else {
                    Brush.verticalGradient(
                        listOf(StudioCardBg, StudioCardBg)
                    )
                }
            )
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) NeonCyan else StudioCardBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = NeonCyan),
                onClick = onClick
            )
            .padding(12.dp)
            .testTag("preset_${preset.name.lowercase()}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else StudioCardElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = presetInfo.title,
                        tint = if (isSelected) NeonCyan else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(NeonEmerald)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = presetInfo.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) TextPrimary else TextSecondary,
                    fontSize = 14.sp
                )
            )

            Text(
                text = presetInfo.subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = if (isSelected) NeonCyan.copy(alpha = 0.8f) else TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                ),
                maxLines = 2
            )
        }
    }
}

