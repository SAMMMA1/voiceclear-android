package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audioengine.AudioMetrics
import com.example.localization.AppLanguage
import com.example.localization.LocalAppLanguage
import com.example.localization.LocalAppStrings
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import com.example.ui.components.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun HomeScreen(
    isEnhancing: Boolean,
    metrics: AudioMetrics,
    settings: ProcessingSettings,
    recordingsCount: Int,
    onToggleEnhancement: () -> Unit,
    onToggleMonitoring: () -> Unit,
    onToggleRecording: () -> Unit,
    onSelectPreset: (PresetType) -> Unit,
    onOpenTestScreen: () -> Unit,
    onOpenRecordingsScreen: () -> Unit,
    onOpenPresetsScreen: () -> Unit,
    onOpenSettingsScreen: () -> Unit,
    onOpenRealityInfo: () -> Unit,
    onToggleLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val currentLang = LocalAppLanguage.current
    val scrollState = rememberScrollState()

    // Blinking animation for recording indicator
    val infiniteTransition = rememberInfiniteTransition(label = "recording_pulse")
    val recordAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 32.dp)
    ) {
        // 1. Studio Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f, fill = false),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(NeonCyan, NeonEmerald)))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StudioCardBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = strings.appTitle,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = strings.appTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = TextPrimary,
                            fontSize = 19.sp
                        )
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (settings.aiEnhancementEnabled) strings.onDeviceNeuralAi else strings.realTimeDsp,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (settings.aiEnhancementEnabled) NeonCyan else NeonEmerald,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            maxLines = 1
                        )
                        if (settings.aiEnhancementEnabled) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NeonCyan.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "RNNoise",
                                    color = NeonCyan,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Language Switcher Button (AR / EN)
                OutlinedButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("btn_toggle_language"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = StudioCardElevated,
                        contentColor = NeonCyan
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioCardBorder),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = strings.language,
                        tint = NeonCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentLang == AppLanguage.ARABIC) "English" else "العربية",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 11.sp
                        )
                    )
                }

                // Info button explaining audio architecture
                IconButton(
                    onClick = onOpenRealityInfo,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(StudioCardElevated)
                        .border(1.dp, StudioCardBorder, CircleShape)
                        .testTag("reality_info_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = strings.archTitle,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Audio Device & Monitoring Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioCardElevated)
                .border(1.dp, StudioCardBorder, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Audio Output Device Info
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (metrics.isHeadphonesConnected) Icons.Default.Headphones else Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = if (metrics.isHeadphonesConnected) NeonCyan else NeonAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = metrics.audioDeviceName,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = if (metrics.isHeadphonesConnected) strings.headphonesSafeMonitoring else strings.speakerLimiterOn,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (metrics.isHeadphonesConnected) NeonEmerald else NeonAmber,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                // Sidetone / Live Monitor Toggle Switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = strings.earMonitor,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (settings.isMonitoringActive) NeonCyan else TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                        Text(
                            text = if (settings.isMonitoringActive) strings.statusOn else strings.statusOff,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (settings.isMonitoringActive) NeonCyan else TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = settings.isMonitoringActive,
                        onCheckedChange = { onToggleMonitoring() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF001F29),
                            checkedTrackColor = NeonCyan,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = StudioCardBg
                        ),
                        modifier = Modifier.testTag("switch_ear_monitoring")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Audio Pipeline Flow Indicator
        PipelineFlowIndicator(
            isActive = isEnhancing,
            micLevel = metrics.micRms,
            enhancedLevel = metrics.enhancedRms,
            activeFiltersCount = metrics.activeFiltersCount
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 4. Live Waveform & Spectrum Visualizer
        LiveWaveformVisualizer(
            waveform = metrics.waveformSamples,
            spectrum = metrics.frequencySpectrum,
            isActive = isEnhancing
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 5. Real-Time Telemetry Diagnostic Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(StudioCardBg)
                .border(1.dp, StudioCardBorder, RoundedCornerShape(12.dp))
                .padding(vertical = 8.dp, horizontal = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryItem(
                    label = strings.latencyMetric,
                    value = if (isEnhancing) String.format(Locale.US, "%.1f ms", metrics.latencyMs) else "--",
                    valueColor = if (metrics.latencyMs < 12f) NeonEmerald else NeonAmber
                )
                TelemetryItem(
                    label = strings.bitrateMetric,
                    value = if (isEnhancing) "${metrics.bitrateKbps} kbps" else "--",
                    valueColor = NeonCyan
                )
                TelemetryItem(
                    label = strings.snrGainMetric,
                    value = if (isEnhancing) String.format(Locale.US, "+%.1f dB", metrics.snrImprovementDb) else "--",
                    valueColor = NeonEmerald
                )
                TelemetryItem(
                    label = strings.cpuLoadMetric,
                    value = if (isEnhancing) String.format(Locale.US, "%.1f%%", metrics.cpuUsagePercent) else "--",
                    valueColor = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6. Master Tactical Power Button
        VoiceClearPowerButton(
            isActive = isEnhancing,
            onToggle = onToggleEnhancement
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 7. Live Lossless WAV Recording Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (metrics.isRecording) Color(0xFF2C1014) else StudioCardElevated)
                .border(
                    width = 1.dp,
                    color = if (metrics.isRecording) NeonCoral else StudioCardBorder,
                    shape = RoundedCornerShape(14.dp)
                )
                .clickable { onToggleRecording() }
                .padding(14.dp)
                .testTag("btn_toggle_recording")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (metrics.isRecording) NeonCoral.copy(alpha = recordAlpha)
                                else NeonCoral.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (metrics.isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                            contentDescription = null,
                            tint = NeonCoral,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = if (metrics.isRecording) strings.recordingEnhancedWav else strings.captureWavRecording,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = if (metrics.isRecording) {
                                val totalSecs = (metrics.recordingDurationMs / 1000).toInt()
                                val mins = totalSecs / 60
                                val secs = totalSecs % 60
                                val sizeKb = metrics.recordingFileSize / 1024
                                String.format(Locale.US, "%02d:%02d • %d KB", mins, secs, sizeKb)
                            } else {
                                strings.saveLosslessAudioDesc
                            },
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (metrics.isRecording) NeonCoral else TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Button(
                    onClick = onToggleRecording,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (metrics.isRecording) NeonCoral else Color(0x30FF5252),
                        contentColor = if (metrics.isRecording) Color.White else NeonCoral
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (metrics.isRecording) strings.stopRecordingBtn else strings.recordBtn,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 8. Live Studio Audio Meters Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(StudioCardBg)
                .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = strings.liveAudioLevels,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Microphone Input Meter
                AudioMeterBar(
                    title = strings.micLevelTitle,
                    levelFraction = if (isEnhancing) metrics.micRms * 2.5f else 0f,
                    dbValue = if (isEnhancing) metrics.micDbFs else -60f,
                    colorType = MeterColorType.CYAN,
                    tag = "mic_level_meter"
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Background Noise Level Meter
                AudioMeterBar(
                    title = strings.ambientNoiseFloorTitle,
                    levelFraction = if (isEnhancing) ((metrics.noiseDb + 60f) / 60f).coerceIn(0f, 1f) else 0f,
                    dbValue = if (isEnhancing) metrics.noiseDb else -60f,
                    colorType = MeterColorType.AMBER,
                    tag = "noise_level_meter"
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Voice Clarity & Speech Presence Meter
                AudioMeterBar(
                    title = strings.voiceIntelligibilityTitle,
                    levelFraction = if (isEnhancing) metrics.voiceLevel else 0f,
                    dbValue = if (isEnhancing) metrics.enhancedDbFs else -60f,
                    colorType = MeterColorType.EMERALD,
                    tag = "voice_clarity_meter"
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 9. Presets Selector Carousel
        PresetSelector(
            selectedPreset = settings.activePreset,
            onSelectPreset = onSelectPreset
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 10. Multi-feature 2x2 Navigation Grid
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Test Microphone (A/B Audition & Sidetone)
                NavCard(
                    title = strings.testMicNavTitle,
                    subtitle = strings.testMicNavSub,
                    icon = Icons.Default.Hearing,
                    accentColor = NeonCyan,
                    onClick = onOpenTestScreen,
                    modifier = Modifier.weight(1f),
                    tag = "btn_test_microphone"
                )

                // Recordings Library
                NavCard(
                    title = "${strings.recordingsNavTitle} ($recordingsCount)",
                    subtitle = strings.recordingsNavSub,
                    icon = Icons.Default.LibraryMusic,
                    accentColor = NeonCoral,
                    onClick = onOpenRecordingsScreen,
                    modifier = Modifier.weight(1f),
                    tag = "btn_recordings_library"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Smart & Custom Presets
                NavCard(
                    title = strings.customProfilesNavTitle,
                    subtitle = strings.customProfilesNavSub,
                    icon = Icons.Default.BookmarkBorder,
                    accentColor = NeonAmber,
                    onClick = onOpenPresetsScreen,
                    modifier = Modifier.weight(1f),
                    tag = "btn_custom_presets"
                )

                // Parametric EQ & DSP Settings
                NavCard(
                    title = strings.dspEqNavTitle,
                    subtitle = strings.dspEqNavSub,
                    icon = Icons.Default.Tune,
                    accentColor = NeonEmerald,
                    onClick = onOpenSettingsScreen,
                    modifier = Modifier.weight(1f),
                    tag = "btn_settings"
                )
            }
        }
    }
}

@Composable
private fun TelemetryItem(
    label: String,
    value: String,
    valueColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Black,
                color = valueColor,
                fontSize = 12.sp
            )
        )
    }
}

@Composable
private fun NavCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(StudioCardElevated)
            .border(1.dp, StudioCardBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp)
            .testTag(tag)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                ),
                maxLines = 1
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}
