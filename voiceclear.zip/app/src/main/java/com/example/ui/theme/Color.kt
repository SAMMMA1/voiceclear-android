package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VoiceClear Audio Studio Color Palette
val StudioDarkBg = Color(0xFF090D16)
val StudioCardBg = Color(0xFF111827)
val StudioCardElevated = Color(0xFF1A2337)
val StudioCardBorder = Color(0xFF26354E)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x3300E5FF)
val NeonEmerald = Color(0xFF00F59B)
val NeonEmeraldGlow = Color(0x3300F59B)
val NeonCoral = Color(0xFFFF4B72)
val NeonAmber = Color(0xFFFFB800)
val NeonViolet = Color(0xFF8C52FF)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val MeterGreen = Color(0xFF10B981)
val MeterYellow = Color(0xFFF59E0B)
val MeterRed = Color(0xFFEF4444)
val MeterInactive = Color(0xFF1E293B)

