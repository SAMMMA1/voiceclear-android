package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import com.example.localization.LocalAppStrings
import com.example.ui.theme.*

@Composable
fun PipelineFlowIndicator(
    isActive: Boolean,
    micLevel: Float,
    enhancedLevel: Float,
    activeFiltersCount: Int,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val infiniteTransition = rememberInfiniteTransition(label = "flow_anim")
    val dotOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dots"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioCardBg)
            .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Node 1: Raw Microphone Input
            PipelineNode(
                title = strings.pipelineMic,
                subtitle = strings.pipelineMicSub,
                icon = Icons.Default.Mic,
                isActive = isActive,
                level = micLevel,
                accentColor = NeonCyan,
                modifier = Modifier.weight(1f)
            )

            // Arrow 1
            FlowConnector(isActive = isActive, dotProgress = dotOffset)

            // Node 2: AI & DSP Processing Core
            val aiSub = if (isActive) "$activeFiltersCount ${strings.pipelineAiSubFilters}" else strings.pipelineAiSubBypass
            PipelineNode(
                title = strings.pipelineAi,
                subtitle = aiSub,
                icon = Icons.Default.AutoAwesome,
                isActive = isActive,
                level = if (isActive) 0.85f else 0f,
                accentColor = NeonViolet,
                modifier = Modifier.weight(1.1f)
            )

            // Arrow 2
            FlowConnector(isActive = isActive, dotProgress = dotOffset)

            // Node 3: Enhanced Voice Output
            val voiceSub = if (isActive) strings.pipelineVoiceSubClean else strings.pipelineVoiceSubRaw
            PipelineNode(
                title = strings.pipelineVoice,
                subtitle = voiceSub,
                icon = Icons.Default.VolumeUp,
                isActive = isActive,
                level = enhancedLevel,
                accentColor = NeonEmerald,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun PipelineNode(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    level: Float,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val scaleFactor = if (isActive) 1.0f + (level * 0.15f).coerceAtMost(0.2f) else 1.0f

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(44.dp)
                .scale(scaleFactor)
                .clip(CircleShape)
                .background(
                    if (isActive) accentColor.copy(alpha = 0.2f) else StudioCardElevated
                )
                .border(
                    width = 1.5.dp,
                    color = if (isActive) accentColor else StudioCardBorder,
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isActive) accentColor else TextMuted,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (isActive) TextPrimary else TextSecondary,
                fontSize = 11.sp
            ),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isActive) accentColor else TextSecondary.copy(alpha = 0.7f),
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Medium
            ),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun FlowConnector(
    isActive: Boolean,
    dotProgress: Float
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.width(32.dp)
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Audio flow",
            tint = if (isActive) NeonCyan.copy(alpha = 0.8f) else TextMuted.copy(alpha = 0.4f),
            modifier = Modifier.size(18.dp)
        )
    }
}
