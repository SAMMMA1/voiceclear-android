package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun LiveWaveformVisualizer(
    waveform: FloatArray,
    spectrum: FloatArray,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(StudioCardElevated)
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 12.dp)) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f

            // Draw subtle background grid lines
            val gridColor = Color(0x1A00E5FF)
            for (i in 1..4) {
                val y = height * (i / 5f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            if (!isActive) {
                // Idle baseline line
                drawLine(
                    color = TextMuted.copy(alpha = 0.4f),
                    start = Offset(0f, centerY),
                    end = Offset(width, centerY),
                    strokeWidth = 2.dp.toPx()
                )
                return@Canvas
            }

            // 1. Draw 16 Spectrum EQ Columns behind waveform
            val barCount = 16
            val barSpacing = 4.dp.toPx()
            val totalSpacing = (barCount - 1) * barSpacing
            val barWidth = (width - totalSpacing) / barCount

            for (i in 0 until barCount) {
                val specVal = if (i < spectrum.size) spectrum[i] else 0f
                val barHeight = (specVal * (height * 0.85f)).coerceAtLeast(4.dp.toPx())
                val x = i * (barWidth + barSpacing)
                val y = height - barHeight

                val barBrush = Brush.verticalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.85f),
                        NeonEmerald.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    startY = y,
                    endY = height
                )

                drawRoundRect(
                    brush = barBrush,
                    topLeft = Offset(x, y),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
            }

            // 2. Draw Smooth Oscilloscope Waveform
            val path = Path()
            val samples = waveform
            val pointCount = samples.size
            if (pointCount > 1) {
                val dx = width / (pointCount - 1)

                for (i in 0 until pointCount) {
                    val sample = samples[i]
                    // Add subtle harmonic breathing wave
                    val harmonic = sin(pulsePhase + i * 0.4f) * 0.05f
                    val y = centerY - ((sample + harmonic) * (height * 0.42f))

                    if (i == 0) {
                        path.moveTo(0f, y)
                    } else {
                        val prevX = (i - 1) * dx
                        val prevSample = samples[i - 1]
                        val prevY = centerY - ((prevSample + harmonic) * (height * 0.42f))
                        val cx = (prevX + (i * dx)) / 2f
                        path.cubicTo(cx, prevY, cx, y, i * dx, y)
                    }
                }

                // Glow path behind
                drawPath(
                    path = path,
                    color = NeonCyan.copy(alpha = 0.35f),
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                // Main sharp neon path
                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(
                        colors = listOf(NeonCyan, NeonEmerald, NeonCyan)
                    ),
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }

        // Overlay status pill
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x80090D16))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (isActive) NeonEmerald else TextMuted)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isActive) "REAL-TIME DSP" else "STANDBY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) NeonEmerald else TextMuted
                )
            )
        }
    }
}
