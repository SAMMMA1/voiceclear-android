package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import com.example.localization.LocalAppStrings
import com.example.ui.theme.*

@Composable
fun VoiceClearPowerButton(
    isActive: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isActive) 1.08f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = if (isActive) 0.6f else 0.0f,
        targetValue = if (isActive) 0.15f else 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring"
    )

    val buttonBgColor by animateColorAsState(
        targetValue = if (isActive) NeonEmerald else StudioCardElevated,
        animationSpec = tween(300),
        label = "btn_bg"
    )

    val contentColor by animateColorAsState(
        targetValue = if (isActive) Color(0xFF002213) else TextPrimary,
        animationSpec = tween(300),
        label = "content_color"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(170.dp)
        ) {
            // Outer Pulsating Glow Rings when active
            if (isActive) {
                Box(
                    modifier = Modifier
                        .size(165.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(NeonEmerald.copy(alpha = ringAlpha))
                )
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .border(2.dp, NeonCyan.copy(alpha = 0.5f), CircleShape)
                )
            }

            // Main Tactile Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(136.dp)
                    .clip(CircleShape)
                    .shadow(
                        elevation = if (isActive) 24.dp else 8.dp,
                        shape = CircleShape,
                        spotColor = if (isActive) NeonEmerald else Color.Black
                    )
                    .background(
                        if (isActive) {
                            Brush.radialGradient(
                                colors = listOf(NeonEmerald, Color(0xFF00B066))
                            )
                        } else {
                            Brush.verticalGradient(
                                colors = listOf(StudioCardElevated, StudioCardBg)
                            )
                        }
                    )
                    .border(
                        width = 2.dp,
                        brush = if (isActive) Brush.linearGradient(listOf(NeonCyan, NeonEmerald))
                               else Brush.linearGradient(listOf(StudioCardBorder, StudioCardBorder)),
                        shape = CircleShape
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, color = if (isActive) Color.Black else NeonCyan),
                        onClick = onToggle
                    )
                    .padding(12.dp)
                    .testTag("power_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = if (isActive) "Turn Off Enhancement" else "Turn On Enhancement",
                        tint = contentColor,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isActive) strings.powerButtonActive else strings.powerButtonInactive,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp,
                            fontSize = 13.sp,
                            color = contentColor
                        ),
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // State indicator badge
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (isActive) NeonEmerald.copy(alpha = 0.15f) else StudioCardElevated
                )
                .border(
                    width = 1.dp,
                    color = if (isActive) NeonEmerald.copy(alpha = 0.5f) else StudioCardBorder,
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isActive) NeonEmerald else TextMuted)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isActive) strings.powerEnhancementOn else strings.powerEnhancementOff,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        color = if (isActive) NeonEmerald else TextSecondary,
                        fontSize = 11.5.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
