package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF001F28),
    primaryContainer = Color(0xFF004D5C),
    onPrimaryContainer = Color(0xFFBCE9FF),
    secondary = NeonEmerald,
    onSecondary = Color(0xFF002213),
    secondaryContainer = Color(0xFF005232),
    onSecondaryContainer = Color(0xFF86F8C3),
    tertiary = NeonViolet,
    onTertiary = Color(0xFF26005B),
    background = StudioDarkBg,
    onBackground = TextPrimary,
    surface = StudioCardBg,
    onSurface = TextPrimary,
    surfaceVariant = StudioCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = StudioCardBorder,
    error = NeonCoral
  )

@Composable
fun VoiceClearTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}

