package com.example.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audioengine.AudioMetrics
import com.example.audiorecording.AudioPlayerManager
import com.example.audiorecording.PlaybackState
import com.example.audiorecording.RecordingState
import com.example.audiooutput.AuditionMode
import com.example.database.AudioRecordingEntity
import com.example.database.CustomPresetEntity
import com.example.database.DatabaseRepository
import com.example.database.VoiceClearDatabase
import com.example.foregroundservice.VoiceEnhancerService
import com.example.localization.AppLanguage
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import com.example.settings.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class VoiceClearViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    val settingsFlow: StateFlow<ProcessingSettings> = settingsRepository.settingsFlow
    val appLanguage: StateFlow<AppLanguage> = settingsRepository.languageFlow

    fun setAppLanguage(language: AppLanguage) {
        settingsRepository.setAppLanguage(language)
    }

    fun toggleAppLanguage() {
        val next = if (appLanguage.value == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        setAppLanguage(next)
    }

    private val database = VoiceClearDatabase.getDatabase(application)
    private val databaseRepository = DatabaseRepository(database.presetDao(), database.recordingDao())

    val allPresets: StateFlow<List<CustomPresetEntity>> = databaseRepository.allPresets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRecordings: StateFlow<List<AudioRecordingEntity>> = databaseRepository.allRecordings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playerManager = AudioPlayerManager()
    val playbackState: StateFlow<PlaybackState> = playerManager.playbackState

    private var enhancerService: VoiceEnhancerService? = null
    private val _isServiceBound = MutableStateFlow(false)
    val isServiceBound: StateFlow<Boolean> = _isServiceBound.asStateFlow()

    private val _isEnhancing = MutableStateFlow(false)
    val isEnhancing: StateFlow<Boolean> = _isEnhancing.asStateFlow()

    private val _auditionMode = MutableStateFlow(AuditionMode.ENHANCED)
    val auditionMode: StateFlow<AuditionMode> = _auditionMode.asStateFlow()

    private val _metrics = MutableStateFlow(AudioMetrics())
    val metrics: StateFlow<AudioMetrics> = _metrics.asStateFlow()

    private val _recordingState = MutableStateFlow(RecordingState())
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    private val _showRealityDialog = MutableStateFlow(false)
    val showRealityDialog: StateFlow<Boolean> = _showRealityDialog.asStateFlow()

    private val _showFeedbackWarningDialog = MutableStateFlow(false)
    val showFeedbackWarningDialog: StateFlow<Boolean> = _showFeedbackWarningDialog.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as? VoiceEnhancerService.LocalBinder
            enhancerService = localBinder?.getService()
            _isServiceBound.value = true
            _isEnhancing.value = enhancerService?.isEnhancing() ?: false

            enhancerService?.let { service ->
                viewModelScope.launch {
                    service.audioEngine.metrics.collectLatest { liveMetrics ->
                        _metrics.value = liveMetrics
                        _isEnhancing.value = liveMetrics.isRunning
                    }
                }
                viewModelScope.launch {
                    service.audioEngine.recordingState.collectLatest { recState ->
                        _recordingState.value = recState
                    }
                }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            enhancerService = null
            _isServiceBound.value = false
            _isEnhancing.value = false
        }
    }

    init {
        bindService()
    }

    fun bindService() {
        val intent = Intent(getApplication(), VoiceEnhancerService::class.java)
        getApplication<Application>().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    fun toggleEnhancement() {
        val app = getApplication<Application>()
        if (_isEnhancing.value) {
            if (_recordingState.value.isRecording) {
                stopRecording()
            }
            enhancerService?.stopEnhancement()
            _isEnhancing.value = false
        } else {
            VoiceEnhancerService.startService(app)
            bindService()
            val started = enhancerService?.startEnhancement() ?: false
            _isEnhancing.value = started
        }
    }

    // --- Sidetone / Audio Monitoring Controls ---

    fun toggleMonitoring(forceOverride: Boolean = false) {
        val current = settingsFlow.value
        val isHeadphones = _metrics.value.isHeadphonesConnected
        val newMonitoringState = !current.isMonitoringActive

        if (newMonitoringState && !isHeadphones && !current.isFeedbackProtectionOverridden && !forceOverride) {
            _showFeedbackWarningDialog.value = true
            return
        }

        settingsRepository.updateSettings(
            current.copy(
                isMonitoringActive = newMonitoringState,
                isFeedbackProtectionOverridden = if (forceOverride) true else current.isFeedbackProtectionOverridden
            )
        )
        enhancerService?.audioEngine?.setMonitoringEnabled(newMonitoringState)
    }

    fun setMonitoringVolume(volume: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(current.copy(monitoringVolume = volume))
        enhancerService?.audioEngine?.setMonitoringVolume(volume)
    }

    fun dismissFeedbackWarning() {
        _showFeedbackWarningDialog.value = false
    }

    fun overrideFeedbackWarningAndEnableMonitoring() {
        _showFeedbackWarningDialog.value = false
        toggleMonitoring(forceOverride = true)
    }

    fun setAuditionMode(mode: AuditionMode) {
        _auditionMode.value = mode
        enhancerService?.audioEngine?.setAuditionMode(mode)
    }

    fun toggleAuditionMode() {
        val nextMode = if (_auditionMode.value == AuditionMode.ENHANCED) {
            AuditionMode.ORIGINAL
        } else {
            AuditionMode.ENHANCED
        }
        setAuditionMode(nextMode)
    }

    // --- Recording & Playback Controls ---

    fun toggleRecording() {
        if (_recordingState.value.isRecording) {
            stopRecording()
        } else {
            startRecording()
        }
    }

    fun startRecording() {
        if (!_isEnhancing.value) {
            toggleEnhancement()
        }
        val presetName = settingsFlow.value.activePreset.title
        enhancerService?.audioEngine?.startRecording(presetName)
    }

    fun stopRecording() {
        val dualResult = enhancerService?.audioEngine?.stopRecordingDual()
        dualResult?.let { result ->
            val presetName = settingsFlow.value.activePreset.title
            val sampleRate = result.sampleRate
            val durationMs = result.durationMs

            viewModelScope.launch {
                databaseRepository.insertRecording(
                    AudioRecordingEntity(
                        title = result.enhancedFile.nameWithoutExtension
                            .replace("VoiceClear_", "")
                            .replace("_Enhanced", ""),
                        filePath = result.enhancedFile.absolutePath,
                        rawFilePath = result.rawFile.absolutePath,
                        durationMs = durationMs,
                        fileSizeBytes = result.enhancedFile.length(),
                        rawFileSizeBytes = result.rawFile.length(),
                        sampleRate = sampleRate,
                        isEnhanced = true,
                        presetUsed = presetName
                    )
                )
                Toast.makeText(getApplication(), "Recording saved: ${result.enhancedFile.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun playRecording(recording: AudioRecordingEntity, playRaw: Boolean = false) {
        playerManager.playRecording(recording, playRaw)
    }

    fun toggleAuditionPlaybackTrack(recording: AudioRecordingEntity) {
        playerManager.toggleAuditionTrack(recording)
    }

    fun pauseRecording() {
        playerManager.pause()
    }

    fun seekRecording(fraction: Float) {
        playerManager.seekTo(fraction)
    }

    fun deleteRecording(recording: AudioRecordingEntity) {
        viewModelScope.launch {
            playerManager.stop()
            try {
                val file = File(recording.filePath)
                if (file.exists()) file.delete()
            } catch (e: Exception) {
                // ignore
            }
            databaseRepository.deleteRecording(recording.id)
            Toast.makeText(getApplication(), "Recording deleted", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareRecording(recording: AudioRecordingEntity) {
        val context = getApplication<Application>()
        try {
            val file = File(recording.filePath)
            if (!file.exists()) {
                Toast.makeText(context, "File not found", Toast.LENGTH_SHORT).show()
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, recording.title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Share VoiceClear Audio")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share recording: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Presets & Equalizer Controls ---

    fun applyPreset(preset: PresetType) {
        settingsRepository.applyPreset(preset)
    }

    fun applyCustomPreset(preset: CustomPresetEntity) {
        val newSettings = ProcessingSettings(
            noiseSuppressionLevel = preset.noiseSuppressionLevel,
            voiceClarity = preset.voiceClarity,
            voiceFocus = preset.voiceFocus,
            echoCancellationEnabled = preset.echoCancellationEnabled,
            automaticGainControlEnabled = preset.automaticGainControlEnabled,
            backgroundNoiseRemovalEnabled = preset.backgroundNoiseRemovalEnabled,
            lowLatencyMode = preset.lowLatencyMode,
            sampleRate = preset.sampleRate,
            activePreset = PresetType.CUSTOM,
            customPresetId = preset.id,
            customPresetName = preset.name,
            aiEnhancementEnabled = preset.aiEnhancementEnabled,
            aiModelStrength = preset.aiModelStrength,
            inputGainDb = preset.inputGainDb,
            outputGainDb = preset.outputGainDb,
            vadSensitivity = preset.vadSensitivity,
            limiterThresholdDb = preset.limiterThresholdDb,
            lowRumbleCut = preset.lowRumbleCut,
            warmthDb = preset.warmthDb,
            presenceDb = preset.presenceDb,
            airDb = preset.airDb,
            isMonitoringActive = settingsFlow.value.isMonitoringActive,
            monitoringVolume = settingsFlow.value.monitoringVolume
        )
        settingsRepository.updateSettings(newSettings)
    }

    fun saveCurrentAsCustomPreset(name: String, description: String, iconColorHex: String = "#00E5FF") {
        val cur = settingsFlow.value
        viewModelScope.launch {
            val id = databaseRepository.insertPreset(
                CustomPresetEntity(
                    name = name,
                    description = description.ifEmpty { "User-configured equalizer & DSP profile" },
                    iconColorHex = iconColorHex,
                    noiseSuppressionLevel = cur.noiseSuppressionLevel,
                    voiceClarity = cur.voiceClarity,
                    voiceFocus = cur.voiceFocus,
                    echoCancellationEnabled = cur.echoCancellationEnabled,
                    automaticGainControlEnabled = cur.automaticGainControlEnabled,
                    backgroundNoiseRemovalEnabled = cur.backgroundNoiseRemovalEnabled,
                    lowLatencyMode = cur.lowLatencyMode,
                    sampleRate = cur.sampleRate,
                    aiEnhancementEnabled = cur.aiEnhancementEnabled,
                    aiModelStrength = cur.aiModelStrength,
                    inputGainDb = cur.inputGainDb,
                    outputGainDb = cur.outputGainDb,
                    vadSensitivity = cur.vadSensitivity,
                    limiterThresholdDb = cur.limiterThresholdDb,
                    lowRumbleCut = cur.lowRumbleCut,
                    warmthDb = cur.warmthDb,
                    presenceDb = cur.presenceDb,
                    airDb = cur.airDb,
                    isBuiltIn = false
                )
            )
            settingsRepository.updateSettings(
                cur.copy(
                    activePreset = PresetType.CUSTOM,
                    customPresetId = id,
                    customPresetName = name
                )
            )
            Toast.makeText(getApplication(), "Custom preset '$name' saved!", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteCustomPreset(preset: CustomPresetEntity) {
        viewModelScope.launch {
            databaseRepository.deletePreset(preset.id)
            if (settingsFlow.value.customPresetId == preset.id) {
                applyPreset(PresetType.GAMING)
            }
            Toast.makeText(getApplication(), "Preset '${preset.name}' deleted", Toast.LENGTH_SHORT).show()
        }
    }

    // STFT Spectral & DSP Controls

    fun toggleAiEnhancement() {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                aiEnhancementEnabled = !current.aiEnhancementEnabled,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setAiModelStrength(strength: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                aiModelStrength = strength,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setInputGainDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                inputGainDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setOutputGainDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                outputGainDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setVadSensitivity(sensitivity: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                vadSensitivity = sensitivity,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setLimiterThresholdDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                limiterThresholdDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    // Continuous & Toggle DSP Settings

    fun setNoiseSuppression(level: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                noiseSuppressionLevel = level,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setVoiceClarity(level: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                voiceClarity = level,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setVoiceFocus(level: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                voiceFocus = level,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setLowRumbleCut(enabled: Boolean) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                lowRumbleCut = enabled,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setWarmthDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                warmthDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setPresenceDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                presenceDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun setAirDb(db: Float) {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                airDb = db,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun toggleEchoCancellation() {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                echoCancellationEnabled = !current.echoCancellationEnabled,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun toggleAgc() {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                automaticGainControlEnabled = !current.automaticGainControlEnabled,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun toggleBackgroundNoiseRemoval() {
        val current = settingsFlow.value
        settingsRepository.updateSettings(
            current.copy(
                backgroundNoiseRemovalEnabled = !current.backgroundNoiseRemovalEnabled,
                activePreset = PresetType.CUSTOM
            )
        )
    }

    fun toggleLowLatency() {
        val current = settingsFlow.value
        val newMode = !current.lowLatencyMode
        settingsRepository.updateSettings(
            current.copy(
                lowLatencyMode = newMode,
                activePreset = PresetType.CUSTOM
            )
        )
        if (_isEnhancing.value) {
            enhancerService?.audioEngine?.stop()
            enhancerService?.audioEngine?.start(settingsFlow.value)
        }
    }

    fun setSampleRate(rate: Int) {
        val current = settingsFlow.value
        if (current.sampleRate != rate) {
            settingsRepository.updateSettings(
                current.copy(
                    sampleRate = rate,
                    activePreset = PresetType.CUSTOM
                )
            )
            if (_isEnhancing.value) {
                enhancerService?.audioEngine?.stop()
                enhancerService?.audioEngine?.start(settingsFlow.value)
            }
        }
    }

    fun setShowRealityDialog(show: Boolean) {
        _showRealityDialog.value = show
    }

    override fun onCleared() {
        try {
            playerManager.stop()
            getApplication<Application>().unbindService(serviceConnection)
        } catch (e: Exception) {
            // Service already unbound
        }
        super.onCleared()
    }
}
