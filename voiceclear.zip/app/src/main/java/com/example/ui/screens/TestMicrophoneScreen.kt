package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audioengine.AudioMetrics
import com.example.audiooutput.AuditionMode
import com.example.localization.LocalAppStrings
import com.example.settings.ProcessingSettings
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestMicrophoneScreen(
    isEnhancing: Boolean,
    metrics: AudioMetrics,
    settings: ProcessingSettings,
    auditionMode: AuditionMode,
    onBack: () -> Unit,
    onToggleEnhancement: () -> Unit,
    onToggleMonitoring: () -> Unit,
    onSetMonitoringVolume: (Float) -> Unit,
    onSetAuditionMode: (AuditionMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.testScreenTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_test")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.back,
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBg)
            )
        },
        containerColor = StudioDarkBg
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // 1. Audio Routing & Sidetone Control Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardElevated)
                    .border(
                        1.dp,
                        if (settings.isMonitoringActive) NeonCyan else StudioCardBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (metrics.isHeadphonesConnected) NeonCyan.copy(alpha = 0.2f)
                                        else NeonAmber.copy(alpha = 0.2f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (metrics.isHeadphonesConnected) Icons.Default.Headphones else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = if (metrics.isHeadphonesConnected) NeonCyan else NeonAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = strings.liveSidetoneMonitor,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "${metrics.audioDeviceName} • ${if (metrics.isHeadphonesConnected) strings.headphonesSafe else strings.speakerLimiterOn}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (metrics.isHeadphonesConnected) NeonEmerald else NeonAmber,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = settings.isMonitoringActive,
                            onCheckedChange = { onToggleMonitoring() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF001F29),
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = StudioCardBg
                            ),
                            modifier = Modifier.testTag("switch_sidetone_monitoring")
                        )
                    }

                    if (settings.isMonitoringActive) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = StudioCardBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Monitor Volume Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VolumeDown,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.monitorVolume,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            Text(
                                text = "${(settings.monitoringVolume * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Slider(
                            value = settings.monitoringVolume,
                            onValueChange = onSetMonitoringVolume,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = MeterInactive
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("slider_monitor_volume")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. Live A/B Switch Section
            Text(
                text = strings.liveAbAudition,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.liveAbSubtitle,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 12.sp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // A: Original Voice Button
                val isOriginalSelected = auditionMode == AuditionMode.ORIGINAL
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isOriginalSelected) Color(0xFF261D15) else StudioCardBg
                        )
                        .border(
                            width = if (isOriginalSelected) 2.dp else 1.dp,
                            color = if (isOriginalSelected) NeonAmber else StudioCardBorder,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, color = NeonAmber),
                            onClick = { onSetAuditionMode(AuditionMode.ORIGINAL) }
                        )
                        .padding(14.dp)
                        .testTag("audition_original_btn")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.originalAuditionBadge,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = if (isOriginalSelected) NeonAmber else TextSecondary
                                )
                            )
                            if (isOriginalSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(NeonAmber)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.rawVoiceTitle,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = strings.rawVoiceDesc,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // B: Enhanced Voice Button
                val isEnhancedSelected = auditionMode == AuditionMode.ENHANCED
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isEnhancedSelected) Color(0xFF0C2B22) else StudioCardBg
                        )
                        .border(
                            width = if (isEnhancedSelected) 2.dp else 1.dp,
                            color = if (isEnhancedSelected) NeonEmerald else StudioCardBorder,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, color = NeonEmerald),
                            onClick = { onSetAuditionMode(AuditionMode.ENHANCED) }
                        )
                        .padding(14.dp)
                        .testTag("audition_enhanced_btn")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.enhancedAuditionBadge,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = if (isEnhancedSelected) NeonEmerald else TextSecondary
                                )
                            )
                            if (isEnhancedSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(NeonEmerald)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.enhancedVoiceTitle,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = strings.enhancedVoiceDesc,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Waveform Visualizer
            LiveWaveformVisualizer(
                waveform = metrics.waveformSamples,
                spectrum = metrics.frequencySpectrum,
                isActive = isEnhancing
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3. Real-time Audio Diagnostics Grid
            Text(
                text = strings.liveDspTelemetry,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DiagnosticRow(
                    label = strings.engineStatusLabel,
                    value = if (isEnhancing) strings.engineActiveStream else strings.engineStandby,
                    valueColor = if (isEnhancing) NeonEmerald else TextMuted,
                    icon = Icons.Default.Speed
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.roundTripLatencyLabel,
                    value = String.format(java.util.Locale.US, "%.2f ms", metrics.latencyMs),
                    valueColor = if (metrics.latencyMs < 12f) NeonEmerald else NeonAmber,
                    icon = Icons.Default.Timer
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.origMicLevelLabel,
                    value = String.format(java.util.Locale.US, "%.1f dBFS", metrics.micDbFs),
                    valueColor = TextPrimary,
                    icon = Icons.Default.Mic
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.enhVoiceLevelLabel,
                    value = String.format(java.util.Locale.US, "%.1f dBFS", metrics.enhancedDbFs),
                    valueColor = NeonCyan,
                    icon = Icons.Default.GraphicEq
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.snrImprovementLabel,
                    value = String.format(java.util.Locale.US, "+%.1f dB", metrics.snrImprovementDb),
                    valueColor = NeonEmerald,
                    icon = Icons.Default.VolumeUp
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.voiceActivityLabel,
                    value = if (metrics.isVoiceActive) "${strings.speechDetected} (${(metrics.voiceLevel * 100).toInt()}%)" else strings.silenceNonVocal,
                    valueColor = if (metrics.isVoiceActive) NeonEmerald else TextMuted,
                    icon = Icons.Default.RecordVoiceOver
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.sampleRateEncodingLabel,
                    value = "${metrics.sampleRate} Hz (16-bit PCM)",
                    valueColor = TextPrimary,
                    icon = Icons.Default.SettingsVoice
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.frameBufferSizeLabel,
                    value = "${metrics.bufferSize} samples (${String.format(java.util.Locale.US, "%.1f", (metrics.bufferSize.toFloat() / metrics.sampleRate) * 1000f)} ms)",
                    valueColor = TextPrimary,
                    icon = Icons.Default.Memory
                )

                HorizontalDivider(color = StudioCardBorder)

                DiagnosticRow(
                    label = strings.hardwareAecNsLabel,
                    value = if (metrics.isHardwareAecActive) strings.supportedActive else strings.softwareFallback,
                    valueColor = if (metrics.isHardwareAecActive) NeonEmerald else TextSecondary,
                    icon = Icons.Default.CheckCircle
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Master Engine Switch
            Button(
                onClick = onToggleEnhancement,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("test_screen_toggle_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEnhancing) NeonCoral else NeonEmerald,
                    contentColor = if (isEnhancing) Color.White else Color(0xFF002213)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = if (isEnhancing) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEnhancing) strings.stopAudioEngine else strings.startAudioEngine,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
private fun DiagnosticRow(
    label: String,
    value: String,
    valueColor: Color,
    icon: ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            )
        }

        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = valueColor,
                fontSize = 13.sp
            )
        )
    }
}
