package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.LocalAppLanguage
import com.example.localization.LocalAppStrings
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import com.example.ui.components.PresetSelector
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: ProcessingSettings,
    onBack: () -> Unit,
    onSelectPreset: (PresetType) -> Unit,
    onOpenPresetsManager: () -> Unit,
    onToggleAiEnhancement: () -> Unit,
    onAiModelStrengthChange: (Float) -> Unit,
    onInputGainDbChange: (Float) -> Unit,
    onOutputGainDbChange: (Float) -> Unit,
    onVadSensitivityChange: (Float) -> Unit,
    onLimiterThresholdDbChange: (Float) -> Unit,
    onNoiseSuppressionChange: (Float) -> Unit,
    onVoiceClarityChange: (Float) -> Unit,
    onVoiceFocusChange: (Float) -> Unit,
    onLowRumbleCutChange: (Boolean) -> Unit,
    onWarmthDbChange: (Float) -> Unit,
    onPresenceDbChange: (Float) -> Unit,
    onAirDbChange: (Float) -> Unit,
    onToggleEchoCancellation: () -> Unit,
    onToggleAgc: () -> Unit,
    onToggleBackgroundNoiseRemoval: () -> Unit,
    onToggleLowLatency: () -> Unit,
    onSelectSampleRate: (Int) -> Unit,
    onOpenRealityInfo: () -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val currentLanguage = LocalAppLanguage.current
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.settingsScreenTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_settings")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.back,
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onOpenRealityInfo,
                        modifier = Modifier.testTag("btn_reality_info_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = strings.archTitle,
                            tint = NeonCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBg)
            )
        },
        containerColor = StudioDarkBg
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
                .padding(bottom = 36.dp)
        ) {
            // 0. Language Selector Card (Arabic & English)
            Text(
                text = strings.languageSettingsTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.languageSettingsSubtitle,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 12.sp)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LanguageOptionCard(
                    title = "العربية",
                    subtitle = "Arabic",
                    isSelected = currentLanguage == AppLanguage.ARABIC,
                    onClick = { onSelectLanguage(AppLanguage.ARABIC) },
                    modifier = Modifier.weight(1f)
                )

                LanguageOptionCard(
                    title = "English",
                    subtitle = "الإنجليزية",
                    isSelected = currentLanguage == AppLanguage.ENGLISH,
                    onClick = { onSelectLanguage(AppLanguage.ENGLISH) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 1. Presets Header with Manage Profiles link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.activeProfileTitle,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )

                TextButton(
                    onClick = onOpenPresetsManager,
                    modifier = Modifier.testTag("btn_manage_presets")
                ) {
                    Icon(
                        imageVector = Icons.Default.BookmarkBorder,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = strings.manageProfilesBtn,
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            PresetSelector(
                selectedPreset = settings.activePreset,
                onSelectPreset = onSelectPreset
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 2. On-Device AI Speech Enhancement Card
            Text(
                text = strings.onDeviceAiTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.onDeviceAiDesc,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 12.sp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SettingToggleRow(
                    title = strings.rnnoiseToggleTitle,
                    subtitle = strings.rnnoiseToggleSubtitle,
                    icon = Icons.Default.AutoAwesome,
                    checked = settings.aiEnhancementEnabled,
                    onToggle = onToggleAiEnhancement,
                    testTag = "toggle_ai_enhancement"
                )

                if (settings.aiEnhancementEnabled) {
                    HorizontalDivider(color = StudioCardBorder)

                    SettingSlider(
                        title = strings.aiStrengthTitle,
                        subtitle = strings.aiStrengthSubtitle,
                        value = settings.aiModelStrength,
                        onValueChange = onAiModelStrengthChange,
                        accentColor = NeonCyan,
                        testTag = "slider_ai_strength"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. 4-Band Parametric Equalizer Card
            Text(
                text = strings.parametricEqTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.parametricEqDesc,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 12.sp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Low Rumble Cut 80Hz
                SettingToggleRow(
                    title = strings.lowRumbleCutTitle,
                    subtitle = strings.lowRumbleCutSubtitle,
                    icon = Icons.Default.GraphicEq,
                    checked = settings.lowRumbleCut,
                    onToggle = { onLowRumbleCutChange(!settings.lowRumbleCut) },
                    testTag = "toggle_low_rumble"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Warmth (220 Hz)
                SettingDbSlider(
                    title = strings.warmthTitle,
                    subtitle = strings.warmthSubtitle,
                    valueDb = settings.warmthDb,
                    minDb = -6.0f,
                    maxDb = 6.0f,
                    onValueChange = onWarmthDbChange,
                    accentColor = NeonAmber,
                    testTag = "slider_warmth_db"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Presence (2.8 kHz)
                SettingDbSlider(
                    title = strings.presenceTitle,
                    subtitle = strings.presenceSubtitle,
                    valueDb = settings.presenceDb,
                    minDb = -6.0f,
                    maxDb = 9.0f,
                    onValueChange = onPresenceDbChange,
                    accentColor = NeonEmerald,
                    testTag = "slider_presence_db"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Air (8.0 kHz)
                SettingDbSlider(
                    title = strings.airTitle,
                    subtitle = strings.airSubtitle,
                    valueDb = settings.airDb,
                    minDb = -6.0f,
                    maxDb = 6.0f,
                    onValueChange = onAirDbChange,
                    accentColor = NeonCyan,
                    testTag = "slider_air_db"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 4. Pre-Amp & Dynamics Gain Stages Card
            Text(
                text = strings.preampLimiterTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SettingDbSlider(
                    title = strings.inputGainTitle,
                    subtitle = strings.inputGainSubtitle,
                    valueDb = settings.inputGainDb,
                    minDb = -12.0f,
                    maxDb = 18.0f,
                    onValueChange = onInputGainDbChange,
                    accentColor = NeonEmerald,
                    testTag = "slider_input_gain"
                )

                HorizontalDivider(color = StudioCardBorder)

                SettingDbSlider(
                    title = strings.outputGainTitle,
                    subtitle = strings.outputGainSubtitle,
                    valueDb = settings.outputGainDb,
                    minDb = -12.0f,
                    maxDb = 18.0f,
                    onValueChange = onOutputGainDbChange,
                    accentColor = NeonCyan,
                    testTag = "slider_output_gain"
                )

                HorizontalDivider(color = StudioCardBorder)

                SettingSlider(
                    title = strings.vadSensitivityTitle,
                    subtitle = strings.vadSensitivitySubtitle,
                    value = settings.vadSensitivity,
                    onValueChange = onVadSensitivityChange,
                    accentColor = NeonViolet,
                    testTag = "slider_vad_sensitivity"
                )

                HorizontalDivider(color = StudioCardBorder)

                SettingDbSlider(
                    title = strings.limiterCeilingTitle,
                    subtitle = strings.limiterCeilingSubtitle,
                    valueDb = settings.limiterThresholdDb,
                    minDb = -6.0f,
                    maxDb = 0.0f,
                    onValueChange = onLimiterThresholdDbChange,
                    accentColor = NeonAmber,
                    testTag = "slider_limiter_ceiling"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 5. Precision DSP Continuous Sliders Card
            Text(
                text = strings.dspStrengthTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Slider 1: Noise Suppression
                SettingSlider(
                    title = strings.spectralFilterTitle,
                    subtitle = strings.spectralFilterSubtitle,
                    value = settings.noiseSuppressionLevel,
                    onValueChange = onNoiseSuppressionChange,
                    accentColor = NeonCyan,
                    testTag = "slider_noise_suppression"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Slider 2: Voice Clarity
                SettingSlider(
                    title = strings.clarityEqTitle,
                    subtitle = strings.clarityEqSubtitle,
                    value = settings.voiceClarity,
                    onValueChange = onVoiceClarityChange,
                    accentColor = NeonEmerald,
                    testTag = "slider_voice_clarity"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Slider 3: Voice Focus
                SettingSlider(
                    title = strings.voiceFocusSettingTitle,
                    subtitle = strings.voiceFocusSettingSubtitle,
                    value = settings.voiceFocus,
                    onValueChange = onVoiceFocusChange,
                    accentColor = NeonViolet,
                    testTag = "slider_voice_focus"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 6. DSP Algorithm Switches Card
            Text(
                text = strings.dspHardwareSafetyTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(StudioCardBg)
                    .border(1.dp, StudioCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Echo Cancellation
                SettingToggleRow(
                    title = strings.echoCancellationTitle,
                    subtitle = strings.echoCancellationSubtitle,
                    icon = Icons.Default.SurroundSound,
                    checked = settings.echoCancellationEnabled,
                    onToggle = onToggleEchoCancellation,
                    testTag = "toggle_echo_cancellation"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Automatic Gain Control
                SettingToggleRow(
                    title = strings.agcTitle,
                    subtitle = strings.agcSubtitle,
                    icon = Icons.Default.Equalizer,
                    checked = settings.automaticGainControlEnabled,
                    onToggle = onToggleAgc,
                    testTag = "toggle_agc"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Background Noise Removal
                SettingToggleRow(
                    title = strings.bgNoiseRemovalTitle,
                    subtitle = strings.bgNoiseRemovalSubtitle,
                    icon = Icons.Default.NoiseControlOff,
                    checked = settings.backgroundNoiseRemovalEnabled,
                    onToggle = onToggleBackgroundNoiseRemoval,
                    testTag = "toggle_bg_noise"
                )

                HorizontalDivider(color = StudioCardBorder)

                // Low Latency Mode
                SettingToggleRow(
                    title = strings.ultraLowLatencyTitle,
                    subtitle = strings.ultraLowLatencySubtitle,
                    icon = Icons.Default.Bolt,
                    checked = settings.lowLatencyMode,
                    onToggle = onToggleLowLatency,
                    testTag = "toggle_low_latency"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 7. Sample Rate Selector
            Text(
                text = strings.sampleRateTitle,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SampleRateCard(
                    rate = 48000,
                    label = strings.sampleRate48kLabel,
                    desc = strings.sampleRate48kDesc,
                    isSelected = settings.sampleRate == 48000,
                    onClick = { onSelectSampleRate(48000) },
                    modifier = Modifier.weight(1f)
                )

                SampleRateCard(
                    rate = 16000,
                    label = strings.sampleRate16kLabel,
                    desc = strings.sampleRate16kDesc,
                    isSelected = settings.sampleRate == 16000,
                    onClick = { onSelectSampleRate(16000) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun LanguageOptionCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) NeonCyan.copy(alpha = 0.12f) else StudioCardBg)
            .border(
                1.5.dp,
                if (isSelected) NeonCyan else StudioCardBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) NeonCyan else TextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingSlider(
    title: String,
    subtitle: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    accentColor: Color,
    testTag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                )
            }

            Text(
                text = "${(value * 100).toInt()}%",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = accentColor
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Slider(
            value = value,
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = MeterInactive
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag)
        )
    }
}

@Composable
private fun SettingDbSlider(
    title: String,
    subtitle: String,
    valueDb: Float,
    minDb: Float,
    maxDb: Float,
    onValueChange: (Float) -> Unit,
    accentColor: Color,
    testTag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                )
            }

            val sign = if (valueDb > 0) "+" else ""
            Text(
                text = "$sign${String.format(java.util.Locale.US, "%.1f", valueDb)} dB",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = accentColor
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Slider(
            value = valueDb,
            valueRange = minDb..maxDb,
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = MeterInactive
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag)
        )
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onToggle: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(),
                onClick = onToggle
            )
            .testTag(testTag),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (checked) NeonCyan.copy(alpha = 0.15f) else StudioCardElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) NeonCyan else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = NeonCyan,
                checkedTrackColor = NeonCyan.copy(alpha = 0.35f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = MeterInactive
            ),
            modifier = Modifier.testTag("${testTag}_switch")
        )
    }
}

@Composable
private fun SampleRateCard(
    rate: Int,
    label: String,
    desc: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) NeonCyan.copy(alpha = 0.12f) else StudioCardBg)
            .border(
                1.5.dp,
                if (isSelected) NeonCyan else StudioCardBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(14.dp)
            .testTag("samplerate_${rate}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) NeonCyan else TextPrimary
                    )
                )
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            )
        }
    }
}

