package com.example.audiooutput

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.example.audioengine.AudioSink
import kotlin.math.abs
import kotlin.math.sign
import kotlin.math.tanh

enum class AuditionMode {
    ENHANCED, // AI & DSP Enhanced Voice
    ORIGINAL, // Raw, unfiltered microphone input
    MUTED     // Output muted (Processing only without ear monitoring)
}

/**
 * Ultra low-latency AudioTrack Output Manager with real-time A/B switching,
 * monitoring volume slider, and ear safety limiter.
 * Implements [AudioSink] to keep processing decoupled from playback.
 */
class AudioOutputManager : AudioSink {
    private val TAG = "AudioOutputManager"

    private var audioTrack: AudioTrack? = null

    var auditionMode: AuditionMode = AuditionMode.ENHANCED
        private set

    var isMonitoringEnabled: Boolean = true
        private set

    var monitoringVolume: Float = 1.0f
        private set

    private var targetMonitoringVolume: Float = 1.0f
    private var currentGain: Float = 1.0f
    private val monitorWorkBuffer = ShortArray(2048)

    fun start(sampleRate: Int, lowLatency: Boolean): Boolean {
        stop()
        try {
            val channelConfig = AudioFormat.CHANNEL_OUT_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            if (minBufferSize <= 0) {
                Log.e(TAG, "Invalid AudioTrack minBufferSize: $minBufferSize")
                return false
            }
            val bufferSize = if (lowLatency) {
                (minBufferSize * 2).coerceAtLeast(1024)
            } else {
                (minBufferSize * 4).coerceAtLeast(2048)
            }

            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(channelConfig)
                .setEncoding(audioFormat)
                .build()

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(
                    if (lowLatency) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY
                    else AudioTrack.PERFORMANCE_MODE_NONE
                )
                .build()

            if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed")
                audioTrack?.release()
                audioTrack = null
                return false
            }

            audioTrack?.play()
            Log.d(TAG, "AudioTrack output started (SampleRate: $sampleRate, BufferSize: $bufferSize)")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed starting AudioTrack output", e)
            return false
        }
    }

    fun setAuditionMode(mode: AuditionMode) {
        auditionMode = mode
    }

    fun setMonitoringEnabled(enabled: Boolean, sampleRate: Int = 48000, lowLatency: Boolean = true) {
        isMonitoringEnabled = enabled
        if (enabled && (audioTrack == null || audioTrack?.state != AudioTrack.STATE_INITIALIZED)) {
            start(sampleRate, lowLatency)
        } else if (!enabled && audioTrack != null) {
            stop()
        }
    }

    fun setMonitoringVolume(volume: Float) {
        targetMonitoringVolume = volume.coerceIn(0f, 1f)
        monitoringVolume = targetMonitoringVolume
    }

    override fun onAudioFrame(
        rawBuffer: ShortArray,
        enhancedBuffer: ShortArray,
        length: Int,
        sampleRate: Int
    ) {
        write(rawBuffer, enhancedBuffer, length)
    }

    fun write(
        rawBuffer: ShortArray,
        enhancedBuffer: ShortArray,
        length: Int
    ) {
        if (!isMonitoringEnabled || length <= 0) return
        val track = audioTrack ?: return
        if (track.playState != AudioTrack.PLAYSTATE_PLAYING) return

        val sourceBuffer = when (auditionMode) {
            AuditionMode.ENHANCED -> enhancedBuffer
            AuditionMode.ORIGINAL -> rawBuffer
            AuditionMode.MUTED -> return
        }

        // Apply smooth gain ramp and ear safety soft-knee saturation
        val destBuffer = if (monitorWorkBuffer.size >= length) monitorWorkBuffer else ShortArray(length)
        val alpha = 0.05f
        for (i in 0 until length) {
            currentGain = (1f - alpha) * currentGain + alpha * targetMonitoringVolume
            val sample = (sourceBuffer[i] / 32768.0f) * currentGain

            // Ear safety limiter: compress peaks over 0.85 to avoid ear fatigue
            val limited = if (abs(sample) > 0.85f) {
                0.85f + 0.15f * tanh((abs(sample) - 0.85f) / 0.15f) * sample.sign
            } else {
                sample
            }
            destBuffer[i] = (limited.coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()
        }

        try {
            track.write(destBuffer, 0, length, AudioTrack.WRITE_NON_BLOCKING)
        } catch (e: Exception) {
            Log.w(TAG, "AudioTrack write error", e)
        }
    }

    fun stop() {
        try {
            audioTrack?.apply {
                if (playState == AudioTrack.PLAYSTATE_PLAYING) {
                    stop()
                }
                release()
            }
            audioTrack = null
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioTrack", e)
        }
    }

    override fun release() {
        stop()
    }
}
