package com.example

import com.example.audioengine.AudioPipeline
import com.example.noisesuppression.NoiseSuppressorDsp
import com.example.noisesuppression.SpectralNoiseSuppressor
import com.example.noisesuppression.StftTransformer
import com.example.settings.ProcessingSettings
import com.example.voiceenhancement.VoiceEnhancerDsp
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs
import kotlin.math.sin

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun testStftTransformerForwardAndInverseReconstruction() {
        val stft = StftTransformer(fftSize = 512)
        val input = FloatArray(512)
        val output = FloatArray(512)

        // Single frame synthetic signal
        for (i in 0 until 512) {
            input[i] = sin(2.0 * Math.PI * 5.0 * i / 512.0).toFloat()
        }

        stft.forwardFft(input, 0)
        stft.inverseFft(output, 0)

        // Verify output is computed and finite
        for (i in 0 until 512) {
            assertFalse("Sample must not be NaN", output[i].isNaN())
            assertFalse("Sample must not be Infinite", output[i].isInfinite())
        }
    }

    @Test
    fun testWolaReconstructionColaPropertyZeroError() {
        val stft = StftTransformer(fftSize = 512)
        val hop = stft.halfSize // 256
        val numSamples = 2048
        val input = FloatArray(numSamples)
        val output = FloatArray(numSamples)

        // Multi-frequency test signal (440Hz + 1200Hz + 3000Hz)
        for (i in 0 until numSamples) {
            input[i] = (0.5 * sin(2.0 * Math.PI * 440.0 * i / 48000.0) +
                        0.3 * sin(2.0 * Math.PI * 1200.0 * i / 48000.0) +
                        0.2 * sin(2.0 * Math.PI * 3000.0 * i / 48000.0)).toFloat()
        }

        // Stream through STFT -> IFFT -> Overlap-Add with zero modification
        val frameIn = FloatArray(512)
        val frameOut = FloatArray(512)
        var pos = 0
        while (pos + 512 <= numSamples) {
            System.arraycopy(input, pos, frameIn, 0, 512)
            stft.forwardFft(frameIn, 0)
            stft.inverseFft(frameOut, 0)
            for (i in 0 until 512) {
                output[pos + i] += frameOut[i]
            }
            pos += hop
        }

        // Verify that in the stationary WOLA overlap region (from 512 to numSamples - 512),
        // reconstruction error is virtually 0 (RMS error < 1e-4)
        var sumSqError = 0.0
        var count = 0
        for (i in 512 until (pos - 256)) {
            val diff = (output[i] - input[i]).toDouble()
            sumSqError += diff * diff
            count++
        }
        val rmsError = kotlin.math.sqrt(sumSqError / count)
        assertTrue("WOLA perfect reconstruction RMS error must be < 1e-4, was: $rmsError", rmsError < 1e-4)
    }

    @Test
    fun testSpectralNoiseSuppressorProcessesBufferWithoutArtifacts() {
        val suppressor = SpectralNoiseSuppressor(sampleRate = 48000, fftSize = 512, hopSize = 256)
        val frameSize = 480
        val buffer = ShortArray(frameSize)

        // Generate synthetic speech-like signal (1kHz sine wave with noise)
        for (i in 0 until frameSize) {
            val signal = (sin(2.0 * Math.PI * 1000.0 * i / 48000.0) * 10000.0).toInt()
            val noise = ((Math.random() - 0.5) * 2000.0).toInt()
            buffer[i] = (signal + noise).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }

        val vadProb = suppressor.process(buffer, frameSize, suppressionFactor = 0.85f)

        assertTrue("VAD probability should be in [0.0, 1.0]", vadProb in 0.0f..1.0f)
        for (i in 0 until frameSize) {
            assertFalse("Buffer sample should not be NaN or corrupted", buffer[i].toInt().toFloat().isNaN())
        }
    }

    @Test
    fun testNoiseSuppressorDspAttenuatesNoiseAndSupportsMultipleSampleRates() {
        val sampleRates = intArrayOf(16000, 24000, 44100, 48000)

        for (sr in sampleRates) {
            val suppressor = NoiseSuppressorDsp(sampleRate = sr)
            val frameSize = sr / 100 // 10ms frame
            val buffer = ShortArray(frameSize)

            // Pure stationary background noise
            for (i in 0 until frameSize) {
                buffer[i] = ((Math.random() - 0.5) * 4000.0).toInt().toShort()
            }

            val settings = ProcessingSettings(
                noiseSuppressionLevel = 0.90f,
                backgroundNoiseRemovalEnabled = true,
                lowRumbleCut = true,
                sampleRate = sr
            )

            val vad = suppressor.processFrame(buffer, frameSize, settings)
            assertTrue("VAD in [0, 1] at $sr Hz", vad in 0.0f..1.0f)
            for (sample in buffer) {
                assertTrue("Sample within short bounds at $sr Hz", sample in Short.MIN_VALUE..Short.MAX_VALUE)
            }
        }
    }

    @Test
    fun testVoiceEnhancerDspLimiterPreventsClipping() {
        val enhancer = VoiceEnhancerDsp(sampleRate = 48000)
        val frameSize = 480
        val buffer = ShortArray(frameSize)

        // Loud input that would otherwise clip
        for (i in 0 until frameSize) {
            buffer[i] = (sin(2.0 * Math.PI * 500.0 * i / 48000.0) * 32000.0).toInt().toShort()
        }

        val settings = ProcessingSettings(
            voiceClarity = 1.0f,
            warmthDb = 6.0f,
            presenceDb = 9.0f,
            airDb = 6.0f,
            automaticGainControlEnabled = true,
            outputGainDb = 12.0f,
            limiterThresholdDb = -0.5f
        )

        enhancer.processFrame(buffer, frameSize, 0.8f, settings)

        // Verify no sample exceeds Short bounds and limiter ceiling
        for (i in 0 until frameSize) {
            val sample = buffer[i]
            assertTrue("Sample within short bounds", sample in Short.MIN_VALUE..Short.MAX_VALUE)
        }
    }

    @Test
    fun testAudioPipelineEndToEnd() {
        val pipeline = AudioPipeline(sampleRate = 48000)
        val settings = ProcessingSettings(
            noiseSuppressionLevel = 0.85f,
            voiceClarity = 0.80f
        )

        val frameSize = 480
        val rawBuffer = ShortArray(frameSize)
        val workBuffer = ShortArray(frameSize)

        for (i in 0 until frameSize) {
            rawBuffer[i] = (sin(2.0 * Math.PI * 440.0 * i / 48000.0) * 8000.0).toInt().toShort()
        }

        val result = pipeline.process(rawBuffer, workBuffer, frameSize, settings)

        assertTrue("Raw RMS should be positive", result.rawRms > 0f)
        assertTrue("Enhanced RMS should be positive", result.enhRms > 0f)
        assertEquals("Spectrum should have 16 bins", 16, result.spectrum.size)
        assertEquals("Waveform should have 48 points", 48, result.waveform.size)
        assertFalse("Should not be clipping", result.isClipping)
        assertTrue("SNR Improvement should be calculated", result.snrImprovementDb >= 0f)
    }

    @Test
    fun testCompletePipelineStreamingToWavFile() {
        val pipeline = AudioPipeline(sampleRate = 48000)
        val settings = ProcessingSettings(
            backgroundNoiseRemovalEnabled = true,
            noiseSuppressionLevel = 0.85f,
            voiceClarity = 0.75f,
            automaticGainControlEnabled = true,
            sampleRate = 48000
        )

        val tempWav = java.io.File.createTempFile("voiceclear_test", ".wav")
        val rawTempWav = java.io.File.createTempFile("voiceclear_raw_test", ".wav")

        try {
            val wavOut = java.io.FileOutputStream(tempWav)
            val rawWavOut = java.io.FileOutputStream(rawTempWav)

            // Write 44-byte placeholder headers
            wavOut.write(ByteArray(44))
            rawWavOut.write(ByteArray(44))

            var totalBytes = 0L
            val frameSize = 480 // 10ms frame @ 48kHz
            val rawFrame = ShortArray(frameSize)
            val workFrame = ShortArray(frameSize)
            val byteBuffer = ByteArray(frameSize * 2)
            val rawByteBuffer = ByteArray(frameSize * 2)

            // Stream 1 second of audio (100 frames = 48000 samples)
            // Signal: 1000 Hz tone + broadband noise
            for (f in 0 until 100) {
                for (i in 0 until frameSize) {
                    val sampleIdx = f * frameSize + i
                    val tone = (sin(2.0 * Math.PI * 1000.0 * sampleIdx / 48000.0) * 6000.0)
                    val noise = ((Math.random() - 0.5) * 3000.0)
                    rawFrame[i] = (tone + noise).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                // Process through complete pipeline: PCM -> STFT -> Noise PSD -> Wiener -> IFFT -> OLA -> EQ -> AGC -> Limiter
                val result = pipeline.process(rawFrame, workFrame, frameSize, settings)

                assertTrue("Processed output within valid range", result.enhRms >= 0f)

                // Write to WAV byte streams
                for (i in 0 until frameSize) {
                    val r = rawFrame[i].toInt()
                    rawByteBuffer[i * 2] = (r and 0xFF).toByte()
                    rawByteBuffer[i * 2 + 1] = ((r shr 8) and 0xFF).toByte()

                    val w = workFrame[i].toInt()
                    byteBuffer[i * 2] = (w and 0xFF).toByte()
                    byteBuffer[i * 2 + 1] = ((w shr 8) and 0xFF).toByte()
                }

                wavOut.write(byteBuffer)
                rawWavOut.write(rawByteBuffer)
                totalBytes += byteBuffer.size
            }

            wavOut.flush(); wavOut.close()
            rawWavOut.flush(); rawWavOut.close()

            // Update WAV headers with standard RIFF PCM 16-bit format
            java.io.RandomAccessFile(tempWav, "rw").use { raf ->
                com.example.audiorecording.WavHeaderUtils.writeWavHeader(raf, 48000, 1, 16, totalBytes)
            }
            java.io.RandomAccessFile(rawTempWav, "rw").use { raf ->
                com.example.audiorecording.WavHeaderUtils.writeWavHeader(raf, 48000, 1, 16, totalBytes)
            }

            // Verify WAV header validity
            assertTrue("Enhanced WAV file must exist", tempWav.exists() && tempWav.length() > 44)
            assertTrue("Raw WAV file must exist", rawTempWav.exists() && rawTempWav.length() > 44)

            val headerBytes = ByteArray(44)
            val fis = java.io.FileInputStream(tempWav)
            fis.read(headerBytes)
            fis.close()

            val riff = String(headerBytes, 0, 4, java.nio.charset.StandardCharsets.US_ASCII)
            val wave = String(headerBytes, 8, 4, java.nio.charset.StandardCharsets.US_ASCII)
            val fmt = String(headerBytes, 12, 4, java.nio.charset.StandardCharsets.US_ASCII)
            val data = String(headerBytes, 36, 4, java.nio.charset.StandardCharsets.US_ASCII)

            assertEquals("WAV RIFF identifier", "RIFF", riff)
            assertEquals("WAV WAVE identifier", "WAVE", wave)
            assertEquals("WAV fmt identifier", "fmt ", fmt)
            assertEquals("WAV data identifier", "data", data)
        } finally {
            tempWav.delete()
            rawTempWav.delete()
        }
    }

    @Test
    fun testBypassModeTransparency() {
        val pipeline = AudioPipeline(sampleRate = 48000)
        val bypassSettings = ProcessingSettings(
            backgroundNoiseRemovalEnabled = false,
            noiseSuppressionLevel = 0.0f,
            voiceClarity = 0.0f,
            lowRumbleCut = false,
            automaticGainControlEnabled = false,
            inputGainDb = 0.0f,
            outputGainDb = 0.0f,
            limiterThresholdDb = 0.0f,
            sampleRate = 48000
        )

        val frameSize = 480
        val rawBuffer = ShortArray(frameSize)
        val workBuffer = ShortArray(frameSize)

        for (i in 0 until frameSize) {
            rawBuffer[i] = (sin(2.0 * Math.PI * 440.0 * i / 48000.0) * 12000.0).toInt().toShort()
        }

        pipeline.process(rawBuffer, workBuffer, frameSize, bypassSettings)

        // In bypass mode with 0 gain and no filters, output should identically match input
        for (i in 0 until frameSize) {
            assertEquals("Bypass mode must preserve original samples", rawBuffer[i], workBuffer[i])
        }
    }
}
