package com.example

import com.example.audioengine.AudioPipeline
import com.example.audioengine.AudioSink
import com.example.noisesuppression.NoiseSuppressorDsp
import com.example.noisesuppression.RnnoiseModel
import com.example.settings.ProcessingSettings
import com.example.voiceenhancement.VoiceEnhancerDsp
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.sin

class ExampleUnitTest {

    @Test
    fun testRnnoiseModelProcessesBufferWithoutArtifacts() {
        val model = RnnoiseModel(numBands = 22)
        val frameSize = 480
        val buffer = ShortArray(frameSize)

        // Generate synthetic speech-like signal (1kHz sine wave with noise)
        for (i in 0 until frameSize) {
            val signal = (sin(2.0 * Math.PI * 1000.0 * i / 48000.0) * 10000.0).toInt()
            val noise = ((Math.random() - 0.5) * 2000.0).toInt()
            buffer[i] = (signal + noise).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }

        val vadProb = model.processFrame(buffer, frameSize, suppressionStrength = 0.85f, isVoicedExpected = true)

        assertTrue("VAD probability should be in [0.0, 1.0]", vadProb in 0.0f..1.0f)
        for (i in 0 until frameSize) {
            assertFalse("Buffer sample should not be NaN or corrupted", buffer[i].toInt().toFloat().isNaN())
        }
    }

    @Test
    fun testNoiseSuppressorDspAttenuatesNoise() {
        val suppressor = NoiseSuppressorDsp(sampleRate = 48000)
        val frameSize = 480
        val input = ShortArray(frameSize)
        val output = ShortArray(frameSize)

        // Pure stationary background noise
        for (i in 0 until frameSize) {
            input[i] = ((Math.random() - 0.5) * 4000.0).toInt().toShort()
        }

        var inRmsSum = 0.0
        for (sample in input) {
            inRmsSum += sample.toDouble() * sample.toDouble()
        }
        val inRms = kotlin.math.sqrt(inRmsSum / frameSize)

        suppressor.process(
            input = input,
            output = output,
            length = frameSize,
            suppressionLevel = 0.90f,
            voiceFocus = 0.80f,
            isVoiceActive = false,
            lowRumbleCut = true,
            backgroundNoiseRemoval = true,
            aiEnhancementEnabled = true,
            aiModelStrength = 0.85f,
            inputGainDb = 0.0f
        )

        var outRmsSum = 0.0
        for (sample in output) {
            outRmsSum += sample.toDouble() * sample.toDouble()
        }
        val outRms = kotlin.math.sqrt(outRmsSum / frameSize)

        assertTrue("Output RMS should be attenuated relative to input noise", outRms <= inRms)
    }

    @Test
    fun testVoiceEnhancerDspLimiterPreventsClipping() {
        val enhancer = VoiceEnhancerDsp(sampleRate = 48000)
        val frameSize = 480
        val buffer = ShortArray(frameSize)

        // Loud input that would otherwise clip
        for (i in 0 until frameSize) {
            buffer[i] = (sin(2.0 * Math.PI * 500.0 * i / 48000.0) * 32000.0).toInt().toShort()
        }

        enhancer.process(
            buffer = buffer,
            length = frameSize,
            voiceClarity = 1.0f,
            warmthDb = 6.0f,
            presenceDb = 9.0f,
            airDb = 6.0f,
            isAgcEnabled = true,
            outputGainDb = 12.0f,
            limiterThresholdDb = -0.5f
        )

        // Verify no sample exceeds Short bounds and limiter ceiling
        for (i in 0 until frameSize) {
            val sample = buffer[i]
            assertTrue("Sample within short bounds", sample in Short.MIN_VALUE..Short.MAX_VALUE)
        }
    }

    @Test
    fun testAudioPipelineEndToEnd() {
        val pipeline = AudioPipeline(sampleRate = 48000)
        val settings = ProcessingSettings(
            noiseSuppressionLevel = 0.85f,
            voiceClarity = 0.80f,
            aiEnhancementEnabled = true,
            aiModelStrength = 0.85f
        )

        val frameSize = 480
        val rawBuffer = ShortArray(frameSize)
        val workBuffer = ShortArray(frameSize)

        for (i in 0 until frameSize) {
            rawBuffer[i] = (sin(2.0 * Math.PI * 440.0 * i / 48000.0) * 8000.0).toInt().toShort()
        }

        val result = pipeline.process(rawBuffer, workBuffer, frameSize, settings)

        assertTrue("Raw RMS should be positive", result.rawRms > 0f)
        assertTrue("Enhanced RMS should be positive", result.enhRms > 0f)
        assertEquals("Spectrum should have 24 bins", 24, result.spectrum.size)
        assertEquals("Waveform should have 48 points", 48, result.waveform.size)
        assertFalse("Should not be clipping", result.isClipping)
    }
}
