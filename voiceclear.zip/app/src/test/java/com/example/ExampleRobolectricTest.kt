package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("VoiceClear", appName)
  }

  @Test
  fun `verify preset configurations`() {
    val gamingSettings = ProcessingSettings.forPreset(PresetType.GAMING)
    assertTrue(gamingSettings.noiseSuppressionLevel >= 0.8f)
    assertTrue(gamingSettings.lowLatencyMode)

    val naturalSettings = ProcessingSettings.forPreset(PresetType.NATURAL_VOICE)
    assertEquals(0.45f, naturalSettings.noiseSuppressionLevel, 0.01f)
  }
}

