package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.noisesuppression.SpectralNoiseSuppressor
import com.example.noisesuppression.StftTransformer
import com.example.settings.PresetType
import com.example.settings.ProcessingSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs
import kotlin.math.sin

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("VoiceClear", appName)
  }

  @Test
  fun `verify preset configurations`() {
    val gamingSettings = ProcessingSettings.forPreset(PresetType.GAMING)
    assertTrue(gamingSettings.noiseSuppressionLevel >= 0.8f)
    assertTrue(gamingSettings.lowLatencyMode)

    val cleanSettings = ProcessingSettings.forPreset(PresetType.CLEAN_VOICE)
    assertEquals(0.65f, cleanSettings.noiseSuppressionLevel, 0.05f)
  }

  @Test
  fun `verify STFT forward and inverse transformation roundtrip`() {
    val transformer = StftTransformer(512)
    val input = FloatArray(512)
    // Generate a 1 kHz sine tone at 48 kHz
    for (i in 0 until 512) {
      input[i] = sin(2.0 * Math.PI * 1000.0 * i / 48000.0).toFloat()
    }

    transformer.forwardFft(input, 0)
    val output = FloatArray(512)
    transformer.inverseFft(output, 0)

    var outEnergy = 0.0
    for (i in 0 until 512) {
      outEnergy += output[i] * output[i]
    }
    assertTrue("Output reconstructed energy must be positive", outEnergy > 0.0)
  }

  @Test
  fun `verify SpectralNoiseSuppressor filters audio cleanly`() {
    val suppressor = SpectralNoiseSuppressor(48000, 512, 256)
    val buffer = ShortArray(480)
    for (i in buffer.indices) {
      // Simulate speech + background noise
      val speech = sin(2.0 * Math.PI * 440.0 * i / 48000.0) * 10000.0
      val noise = (Math.random() - 0.5) * 4000.0
      buffer[i] = (speech + noise).toInt().toShort()
    }

    val vad = suppressor.process(buffer, buffer.size, 0.85f)
    // Ensure buffer remains finite and bounded
    for (sample in buffer) {
      assertTrue(sample in -32768..32767)
    }
    assertTrue(vad >= 0f)
  }
}


